--
-- PostgreSQL database dump
--

\restrict tSPxoXsmBYC1alAReylyajV1SOh4GEN8iI2lxz9gRx8BthHEBBk3dLOdwlxIH8a

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: claim_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.claim_status AS ENUM (
    'ABERTO',
    'EM_ANALISE',
    'ENCERRADO'
);


--
-- Name: claim_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.claim_type AS ENUM (
    'COLISAO',
    'ROUBO',
    'FURTO',
    'AVARIA',
    'OUTRO'
);


--
-- Name: driver_license_category; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.driver_license_category AS ENUM (
    'A',
    'B',
    'C',
    'D',
    'E'
);


--
-- Name: fine_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.fine_status AS ENUM (
    'PENDENTE',
    'PAGA',
    'RECURSO'
);


--
-- Name: fuel_supply_order_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.fuel_supply_order_status AS ENUM (
    'OPEN',
    'EXPIRED',
    'COMPLETED',
    'CANCELLED'
);


--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role AS ENUM (
    'ADMIN',
    'PADRAO',
    'PRODUCAO',
    'POSTO'
);


--
-- Name: vehicle_ownership_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vehicle_ownership_type AS ENUM (
    'PROPRIO',
    'LOCADO',
    'CEDIDO'
);


--
-- Name: vehicle_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vehicle_status AS ENUM (
    'ATIVO',
    'MANUTENCAO',
    'INATIVO'
);


--
-- Name: vehicle_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vehicle_type AS ENUM (
    'SEDAN',
    'HATCH',
    'PICAPE',
    'SUV',
    'PERUA_SW',
    'VAN',
    'MICRO_ONIBUS',
    'ONIBUS',
    'CAMINHAO',
    'MOTOCICLETA',
    'MAQUINA'
);


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(180) NOT NULL,
    message text NOT NULL,
    event_type character varying(80) NOT NULL,
    severity character varying(20) DEFAULT 'INFO'::character varying NOT NULL,
    payload jsonb,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_user_id uuid,
    actor_name character varying(150) NOT NULL,
    actor_email character varying(255),
    actor_role character varying(30),
    action character varying(30) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    entity_label character varying(255) NOT NULL,
    details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.claims (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    data_ocorrencia timestamp with time zone NOT NULL,
    tipo public.claim_type NOT NULL,
    descricao text NOT NULL,
    local character varying(200) NOT NULL,
    boletim_ocorrencia character varying(50),
    valor_estimado numeric(12,2),
    status public.claim_status DEFAULT 'ABERTO'::public.claim_status NOT NULL,
    justificativa_encerramento text,
    anexos jsonb,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_claims_valor_estimado_non_negative CHECK ((valor_estimado >= (0)::numeric))
);


--
-- Name: drivers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drivers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nome_completo character varying(150) NOT NULL,
    documento character varying(20) NOT NULL,
    contato character varying(50),
    email public.citext,
    cnh_categoria public.driver_license_category NOT NULL,
    cnh_validade date,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    ticket_number character varying(50) NOT NULL,
    infraction_date date NOT NULL,
    due_date date,
    amount numeric(12,2) NOT NULL,
    description text NOT NULL,
    location character varying(200),
    status public.fine_status DEFAULT 'PENDENTE'::public.fine_status NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_fines_amount_non_negative CHECK ((amount >= (0)::numeric))
);


--
-- Name: fleet_analytics_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fleet_analytics_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    vehicle_type character varying(40) NOT NULL,
    scope character varying(30) DEFAULT 'VEHICLE'::character varying NOT NULL,
    total_km double precision DEFAULT 0 NOT NULL,
    total_liters double precision DEFAULT 0 NOT NULL,
    fuel_cost numeric(12,2) DEFAULT 0 NOT NULL,
    maintenance_cost numeric(12,2) DEFAULT 0 NOT NULL,
    fines_cost numeric(12,2) DEFAULT 0 NOT NULL,
    consumption_l_100km double precision,
    tco_cost_per_km double precision,
    driver_risk_score double precision,
    anomalies_count integer DEFAULT 0 NOT NULL,
    category_average_consumption double precision,
    category_average_tco double precision,
    market_benchmark_tco double precision,
    extra_payload jsonb,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fuel_station_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fuel_station_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    fuel_station_id uuid NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fuel_stations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fuel_stations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(180) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    cnpj character varying(18),
    address character varying(255) NOT NULL
);


--
-- Name: fuel_supplies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fuel_supplies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    organization_id uuid,
    supplied_at timestamp with time zone DEFAULT now() NOT NULL,
    odometer_km double precision NOT NULL,
    liters double precision NOT NULL,
    total_amount numeric(12,2),
    fuel_station character varying(180),
    notes text,
    consumption_km_l double precision,
    is_consumption_anomaly boolean DEFAULT false NOT NULL,
    anomaly_details text,
    receipt_path character varying(255) NOT NULL,
    receipt_mime_type character varying(100) NOT NULL,
    receipt_size_bytes integer NOT NULL,
    receipt_uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    fuel_station_id uuid,
    CONSTRAINT ck_fuel_supplies_amount_non_negative CHECK (((total_amount IS NULL) OR (total_amount >= (0)::numeric))),
    CONSTRAINT ck_fuel_supplies_liters_positive CHECK ((liters > (0)::double precision)),
    CONSTRAINT ck_fuel_supplies_odometer_positive CHECK ((odometer_km > (0)::double precision))
);


--
-- Name: fuel_supply_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fuel_supply_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    organization_id uuid,
    fuel_station_id uuid,
    status public.fuel_supply_order_status DEFAULT 'OPEN'::public.fuel_supply_order_status NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '48:00:00'::interval) NOT NULL,
    created_by_user_id uuid NOT NULL,
    confirmed_by_user_id uuid,
    requested_liters numeric(10,3),
    max_amount numeric(12,2),
    notes text,
    confirmed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    validation_code character varying(24) NOT NULL,
    CONSTRAINT ck_fuel_supply_orders_max_amount_non_negative CHECK (((max_amount IS NULL) OR (max_amount >= (0)::numeric))),
    CONSTRAINT ck_fuel_supply_orders_requested_liters_positive CHECK (((requested_liters IS NULL) OR (requested_liters > (0)::numeric)))
);


--
-- Name: location_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    department character varying(255) NOT NULL,
    start_date timestamp with time zone DEFAULT now() NOT NULL,
    end_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    allocation_id uuid,
    justification character varying(500)
);


--
-- Name: maintenance_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone,
    service_description text NOT NULL,
    parts_replaced text,
    total_cost numeric(12,2) NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_total_cost_non_negative CHECK ((total_cost >= (0)::numeric))
);


--
-- Name: master_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_allocations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    department_id uuid NOT NULL,
    name character varying(150) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_departments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(150) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(150) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(150) NOT NULL,
    email public.citext NOT NULL,
    password_hash character varying(255) NOT NULL,
    role public.user_role DEFAULT 'PADRAO'::public.user_role NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    must_change_password boolean DEFAULT false NOT NULL
);


--
-- Name: vehicle_possession; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_possession (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_name character varying(150) NOT NULL,
    driver_document character varying(20),
    driver_contact character varying(50),
    start_date timestamp with time zone DEFAULT now() NOT NULL,
    end_date timestamp with time zone,
    observation text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    photo_path character varying(255),
    photo_mime_type character varying(100),
    photo_size_bytes integer,
    photo_captured_at timestamp with time zone,
    capture_latitude double precision,
    capture_longitude double precision,
    capture_accuracy_meters double precision,
    document_path character varying(255),
    document_name character varying(255),
    document_mime_type character varying(120),
    document_size_bytes integer,
    document_uploaded_at timestamp with time zone,
    driver_id uuid,
    start_odometer_km double precision,
    end_odometer_km double precision,
    return_document_path character varying(255),
    return_document_name character varying(255),
    return_document_mime_type character varying(120),
    return_document_size_bytes integer,
    return_document_uploaded_at timestamp with time zone
);


--
-- Name: vehicle_possession_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_possession_photos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    possession_id uuid NOT NULL,
    photo_path character varying(255) NOT NULL,
    photo_mime_type character varying(100) NOT NULL,
    photo_size_bytes integer NOT NULL,
    photo_captured_at timestamp with time zone,
    capture_latitude double precision,
    capture_longitude double precision,
    capture_accuracy_meters double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plate character varying(20) NOT NULL,
    brand character varying(50) NOT NULL,
    model character varying(50) NOT NULL,
    status public.vehicle_status DEFAULT 'ATIVO'::public.vehicle_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    chassis_number character varying(50),
    ownership_type public.vehicle_ownership_type DEFAULT 'PROPRIO'::public.vehicle_ownership_type NOT NULL,
    vehicle_type public.vehicle_type DEFAULT 'SEDAN'::public.vehicle_type NOT NULL
);


--
-- Data for Name: admin_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_notifications (id, title, message, event_type, severity, payload, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0024_user_must_change_password
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor_user_id, actor_name, actor_email, actor_role, action, entity_type, entity_id, entity_label, details, created_at) FROM stdin;
9853c07f-8700-4e67-9ad3-1b7888857d53	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	CREATE	USER	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	jonatas.sousa@pm.teixeiradefreitas.ba.gov.br	{"name": "Jonatas da Silva Sousa", "role": "ADMIN", "email": "jonatas.sousa@pm.teixeiradefreitas.ba.gov.br"}	2026-04-09 15:51:27.86796-03
4fca3650-7f86-49bd-a177-3d241af3712b	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	USER	065b1e0b-527b-4b65-8a62-008851a22f96	naldorsantosfilho@gmail.com	{"after": {"name": "Arnaldo Rosa dos Santos Filho", "role": "ADMIN", "email": "naldorsantosfilho@gmail.com", "password_changed": true}, "before": {"name": "Arnaldo Rosa dos Santos Filho", "role": "ADMIN", "email": "arnaldo@frota.sirel.com.br"}}	2026-04-09 16:12:24.73918-03
2bf26fe8-7113-436f-8330-b01c6c427c33	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	25a32053-e488-4cfc-8584-deff13f3c926	ABC-1D23 - Joao Silva	{"event": "END_POSSESSION", "end_date": "2026-04-09T22:12:00+00:00", "observation": "Motorista designado para rota norte"}	2026-04-09 16:12:53.573145-03
1bc80d17-bfb1-4a2b-b23d-15817a283123	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas.sousa@pm.teixeiradefreitas.ba.gov.br	ADMIN	CREATE	USER	f2ba72df-6b24-41d5-9fa5-4d947672c8d7	carlos@h	{"name": "Carlos Henrique Cruz Honorato", "role": "PADRAO", "email": "carlos@h"}	2026-04-09 16:25:53.196853-03
715fb29a-bb80-4141-b029-5df08daf6ace	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	USER	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	jonatas@sousa	{"after": {"name": "Jonatas da Silva Sousa", "role": "ADMIN", "email": "jonatas@sousa", "password_changed": false}, "before": {"name": "Jonatas da Silva Sousa", "role": "ADMIN", "email": "jonatas.sousa@pm.teixeiradefreitas.ba.gov.br"}}	2026-04-09 16:37:31.621877-03
7df7e5a8-6a20-49b0-a0a8-d813bd53f144	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	USER	f2ba72df-6b24-41d5-9fa5-4d947672c8d7	carlos@h	{"after": {"name": "Carlos Henrique Cruz Honorato", "role": "PRODUCAO", "email": "carlos@h", "password_changed": false}, "before": {"name": "Carlos Henrique Cruz Honorato", "role": "PADRAO", "email": "carlos@h"}}	2026-04-09 16:37:50.448668-03
c7aa2845-6932-46a2-a456-c3d775b2e26c	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	POSSESSION	964bb112-ff1e-49ff-b133-021679ef8383	ABC-1D23 - Jonatas	{"start_date": "2026-04-10T15:07:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Testes", "driver_contact": "7312345678", "driver_document": "1234567890", "photo_mime_type": "image/jpeg", "photo_size_bytes": 242332, "photo_captured_at": "2026-04-10T12:07:55.653000+00:00", "capture_accuracy_meters": 11.880999565124512, "evidence_photo_attached": true}	2026-04-10 09:08:02.95233-03
ae5748d5-d7bc-4682-81ab-3e77c9ae559e	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	POSSESSION	30c39aae-142e-47c7-95b1-0b0cdf7a3af5	ABC-1D23 - Carlos	{"start_date": "2026-04-10T15:19:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Teste 02", "driver_contact": "7312345678", "driver_document": "1234567890", "photo_mime_type": "image/jpeg", "photo_size_bytes": 128052, "photo_captured_at": "2026-04-10T12:20:01.486000+00:00", "capture_accuracy_meters": 11.47700023651123, "evidence_photo_attached": true}	2026-04-10 09:20:07.322326-03
d0121a61-14f3-45d1-b923-f453a47662c3	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	POSSESSION	effade1b-30a9-4bb2-8070-fa2dfb4a1eeb	ABC-1D23 - Jonatas	{"event": "END_POSSESSION", "end_date": "2026-04-10T15:29:00+00:00", "observation": "teste 03"}	2026-04-10 09:29:33.193823-03
e0579395-a02e-4b64-b01f-74bd7cbdeba6	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	ORGANIZATION	9d68dcc7-a43b-4e27-9961-7929cf691b17	Secretaria de Infraestrutura e Serviços Urbanos	{"after": {"name": "Secretaria de Infraestrutura e Serviços Urbanos"}, "before": {"name": "Secretaria de Infraestrutura"}}	2026-04-10 14:41:14.397968-03
aaf303c2-3887-477c-bb73-af4441ebee4a	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	90332997-e801-44ba-be90-c2fa126053ea	Secretaria de Educacao	{"name": "Secretaria de Educacao"}	2026-04-10 14:41:36.159933-03
21640068-d4d0-4b31-95c9-4f7264875606	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	ORGANIZATION	90332997-e801-44ba-be90-c2fa126053ea	Secretaria de Educação	{"after": {"name": "Secretaria de Educação"}, "before": {"name": "Secretaria de Educacao"}}	2026-04-10 14:41:45.602737-03
3bd4e249-ae75-402f-a5fa-8c2957707ce7	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	ORGANIZATION	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Secretaria de Administração	{"after": {"name": "Secretaria de Administração"}, "before": {"name": "Secretaria de Administracao"}}	2026-04-10 14:41:52.177801-03
3bf7d60d-9cf7-45eb-a48b-99cd89f029fa	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	ORGANIZATION	891b49ea-abf4-4501-9ef6-23fb78c42d25	Secretaria de Saúde	{"after": {"name": "Secretaria de Saúde"}, "before": {"name": "Secretaria de Saude"}}	2026-04-10 14:41:59.519107-03
4882e942-a453-4931-8c74-31a8679cef8f	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	e6a79f0d-d2bf-4e00-bc6d-9294a5b0da7e	Controladoria Geral do Município	{"name": "Controladoria Geral do Município"}	2026-04-10 14:42:38.708471-03
f37d8b29-7635-4bd5-90b8-cd34fc962038	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	471860e8-fe57-4181-bb14-cf3098787905	Gabiente do Prefeito	{"name": "Gabiente do Prefeito"}	2026-04-10 14:42:45.400331-03
48323c9d-2f05-4ca9-8cec-bd161da90903	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	4fdeb45a-dca4-4dcf-93d0-08e24663e09a	Procuradoria Geral do Município	{"name": "Procuradoria Geral do Município"}	2026-04-10 14:43:01.690231-03
463deda4-9629-4a85-a416-e80e7c4b4ae4	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	dbae7e55-4e04-4c38-9128-a88c98b12160	Secretaria de Agricultura Pecuária e Abastecimento	{"name": "Secretaria de Agricultura Pecuária e Abastecimento"}	2026-04-10 14:43:19.225392-03
b4cf4f0f-ce53-4928-ae40-1f296619de6e	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	12375ce0-6f93-43b7-97df-787218d6ff37	Secretaria de Cultura e Turismo	{"name": "Secretaria de Cultura e Turismo"}	2026-04-10 14:43:37.811732-03
b0931fb1-5e30-47af-8dec-01dd2557e1e0	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	72c067bf-d9f7-4f8d-b8c0-ce45d1713025	Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia	{"name": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia"}	2026-04-10 14:44:01.635346-03
c4fc57fa-480c-46cd-b5fd-29af7f70cd45	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	c191b61f-81f7-45ef-825f-fe6a50de9be1	Secretaria de Esporte e Lazer	{"name": "Secretaria de Esporte e Lazer"}	2026-04-10 14:44:16.800864-03
75611c90-22ce-49ee-9f40-92dbc9ef55a4	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	f6dc3ca5-886b-4667-b0ca-536c4a0bfe97	Secretaria de Finanças	{"name": "Secretaria de Finanças"}	2026-04-10 14:44:25.083012-03
586aaf95-217a-4045-83b4-41e478f501d1	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	3b697c38-9278-4b7a-a653-ff985f47a2a6	Secretaria de Habitação	{"name": "Secretaria de Habitação"}	2026-04-10 14:44:44.853436-03
dd877d25-95b4-4864-b4e2-77ca709d521b	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	98a656ae-7517-408c-a997-454a7f7007d2	Secretaria de Meio Ambiente	{"name": "Secretaria de Meio Ambiente"}	2026-04-10 14:45:01.698856-03
1f3d2f06-8172-4be4-92be-5f5f297ea9d2	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	555db8bb-6f86-437e-bb3b-a047a826ac34	Secretaria de Projetos Estratégicos e Gerenciamento de Convênios	{"name": "Secretaria de Projetos Estratégicos e Gerenciamento de Convênios"}	2026-04-10 15:07:33.484142-03
d5b4c923-45ad-4a12-b27b-9c2a7b60fd0c	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	6acb9d5d-599a-4e3e-9f67-932c561cbacb	Secretaria de Promoção Social	{"name": "Secretaria de Promoção Social"}	2026-04-10 15:08:53.789257-03
51a161a1-63eb-4d79-8d4a-9ee8e269914f	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	02708937-9e4d-4387-851b-7a49957405e2	Secretaria de Segurança e Transporte	{"name": "Secretaria de Segurança e Transporte"}	2026-04-10 15:09:14.627433-03
d86a1620-8c99-43cb-a417-af07ef3d844c	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	DEPARTMENT	8f8b0bde-a014-47f9-a2b7-de616bcca58d	Departamento Administrativo	{"after": {"name": "Departamento Administrativo", "organization": "Secretaria de Administração"}, "before": {"name": "Gestao Administrativa", "organization": "Secretaria de Administração"}}	2026-04-10 16:57:52.211385-03
e4c55ab9-0cd7-4c5f-a0d0-f0dded9d4b1d	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	DEPARTMENT	9c5a3de4-107e-444f-a840-d7d2a528190f	Departamento Administrativo	{"after": {"name": "Departamento Administrativo", "organization": "Secretaria de Saúde"}, "before": {"name": "Transporte", "organization": "Secretaria de Saúde"}}	2026-04-10 16:58:21.905167-03
b6cfe597-360d-4cb3-bddf-27e5452c4faf	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	DEPARTMENT	dd141042-2a72-4d8e-b8f1-69eb11d83532	Departamento Administrativo	{"after": {"name": "Departamento Administrativo", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}, "before": {"name": "Oficina", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}}	2026-04-10 16:58:10.893833-03
c9274352-e75b-4c23-8618-e44f212da74e	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	VEHICLE	829c4a2b-db47-4541-bffe-c2443a2ffbdd	ABC-1D23	{"after": {"brand": "Ford", "model": "Ka", "plate": "ABC-1D23", "status": "ATIVO", "location": "Secretaria de Saúde - Departamento Administrativo - Patio Municipal", "chassis_number": "9BFZH55L0G1234567", "ownership_type": "PROPRIO"}, "before": {"brand": "Ford", "model": "Ka", "plate": "ABC-1D23", "status": "ATIVO", "location": "Secretaria de Administração - Departamento Administrativo - Garagem Central", "chassis_number": "9BFZH55L0G1234567", "ownership_type": "PROPRIO"}}	2026-04-10 17:05:40.513084-03
062dfc59-b65d-426e-a087-720328cecf77	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	CREATE	POSSESSION	359f97fa-26dd-40a2-9ac3-a42839d861e9	ABC-1D23 - Teste Documento	{"start_date": "2026-04-10T21:12:09.901595+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Teste com documento anexado", "driver_contact": "73999999999", "driver_document": "12345678900", "photo_mime_type": "image/png", "photo_size_bytes": 43867, "photo_captured_at": "2026-04-10T18:30:00+00:00", "signed_document_name": "termo-assinado.pdf", "capture_accuracy_meters": 12.0, "evidence_photo_attached": true, "signed_document_attached": true, "signed_document_mime_type": "application/pdf", "signed_document_size_bytes": 44}	2026-04-10 18:12:09.893927-03
f900c0f5-b571-4dd2-8164-14d8f2d9c309	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	CREATE	USER	08d425de-0052-42b1-95ab-b3178cde1e30	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	{"name": "WANDERSON SOUSA LIMAS", "role": "PRODUCAO", "email": "wanderson.limas@pm.teixeiradefreitas.ba.gov.br"}	2026-04-10 18:15:06.747474-03
362b3ca4-1807-4986-8bf7-b71a2ff45144	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	effade1b-30a9-4bb2-8070-fa2dfb4a1eeb	ABC-1D23 - Jonatas	{"after": {"end_date": "2026-04-10T15:29:00+00:00", "start_date": "2026-04-10T15:21:00+00:00", "driver_name": "Jonatas", "observation": "teste 03 | validacao-admin", "driver_contact": "7312345678", "driver_document": "1234567890"}, "event": "ADMIN_EDIT", "before": {"end_date": "2026-04-10T15:29:00+00:00", "start_date": "2026-04-10T15:21:00+00:00", "driver_name": "Jonatas", "observation": "teste 03", "driver_contact": "7312345678", "driver_document": "1234567890"}, "reason": "Validacao controlada da edicao administrativa"}	2026-04-10 18:54:08.949449-03
425cf7ca-9297-4af7-a5ab-bc7a2556e10b	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	effade1b-30a9-4bb2-8070-fa2dfb4a1eeb	ABC-1D23 - Jonatas	{"after": {"end_date": "2026-04-10T15:29:00+00:00", "start_date": "2026-04-10T15:21:00+00:00", "driver_name": "Jonatas", "observation": "teste 03", "driver_contact": "7312345678", "driver_document": "1234567890"}, "event": "ADMIN_EDIT", "before": {"end_date": "2026-04-10T15:29:00+00:00", "start_date": "2026-04-10T15:21:00+00:00", "driver_name": "Jonatas", "observation": "teste 03 | validacao-admin", "driver_contact": "7312345678", "driver_document": "1234567890"}, "reason": "Reversao da validacao administrativa"}	2026-04-10 18:54:09.155279-03
33175dfe-56a3-425b-85f9-08ed766d1d2a	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	CREATE	POSSESSION	e21d8e4d-a35a-48b8-8275-c7a8b269fd93	ABC-1D23 - Teste Multipla Evidencia	{"start_date": "2026-04-10T22:40:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Registro temporario de validacao automatizada.", "photo_count": 2, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10", "signed_document_name": null, "capture_accuracy_meters": [8.4, 7.1], "signed_document_attached": false, "signed_document_mime_type": null, "signed_document_size_bytes": null}	2026-04-10 19:36:56.47926-03
82d9af47-0a9c-4e11-9b44-c171bcf2d6a2	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	e21d8e4d-a35a-48b8-8275-c7a8b269fd93	ABC-1D23 - Teste Multipla Evidencia	{"after": {"end_date": null, "start_date": "2026-04-10T22:40:00+00:00", "driver_name": "Teste Multipla Evidencia", "observation": "Registro temporario de validacao automatizada com complemento admin.", "photo_count": 3, "document_name": "termo.pdf", "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "event": "ADMIN_EDIT", "before": {"end_date": null, "start_date": "2026-04-10T22:40:00+00:00", "driver_name": "Teste Multipla Evidencia", "observation": "Registro temporario de validacao automatizada.", "photo_count": 2, "document_name": null, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "reason": "Inclusao de documento e foto complementar para validar o fluxo novo.", "added_photo_count": 1, "document_replaced": true}	2026-04-10 19:36:56.700976-03
e137d7ff-816c-425e-b766-55f7dd481c14	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	CREATE	POSSESSION	9fe27b13-d763-4794-a7fd-f24e3d0d3228	ABC-1D23 - Teste Debug Fotos	{"start_date": "2026-04-10T22:50:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Registro temporario debug.", "photo_count": 2, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10", "signed_document_name": null, "capture_accuracy_meters": [8.4, 7.1], "signed_document_attached": false, "signed_document_mime_type": null, "signed_document_size_bytes": null}	2026-04-10 19:37:58.561549-03
daadb0cb-0115-496e-acf2-740eab6228d0	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	9fe27b13-d763-4794-a7fd-f24e3d0d3228	ABC-1D23 - Teste Debug Fotos	{"after": {"end_date": null, "start_date": "2026-04-10T22:50:00+00:00", "driver_name": "Teste Debug Fotos", "observation": "Registro temporario debug com foto extra.", "photo_count": 3, "document_name": null, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "event": "ADMIN_EDIT", "before": {"end_date": null, "start_date": "2026-04-10T22:50:00+00:00", "driver_name": "Teste Debug Fotos", "observation": "Registro temporario debug.", "photo_count": 2, "document_name": null, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "reason": "Debug de inclusao de foto extra.", "added_photo_count": 1, "document_replaced": false}	2026-04-10 19:37:58.747386-03
fa43b32d-f634-46ac-a75f-484f13a35b95	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	CREATE	POSSESSION	dd076146-c2b5-44fc-b3ed-35e5651e9c42	ABC-1D23 - Teste Multipla Evidencia	{"start_date": "2026-04-10T22:40:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Registro temporario de validacao automatizada.", "photo_count": 2, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10", "signed_document_name": null, "capture_accuracy_meters": [8.4, 7.1], "signed_document_attached": false, "signed_document_mime_type": null, "signed_document_size_bytes": null}	2026-04-10 19:42:02.958933-03
0b98ed15-7e6c-44b0-8a41-3bc91781f6c6	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	dd076146-c2b5-44fc-b3ed-35e5651e9c42	ABC-1D23 - Teste Multipla Evidencia	{"after": {"end_date": null, "start_date": "2026-04-10T22:40:00+00:00", "driver_name": "Teste Multipla Evidencia", "observation": "Registro temporario de validacao automatizada com complemento admin.", "photo_count": 3, "document_name": "termo.pdf", "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "event": "ADMIN_EDIT", "before": {"end_date": null, "start_date": "2026-04-10T22:40:00+00:00", "driver_name": "Teste Multipla Evidencia", "observation": "Registro temporario de validacao automatizada.", "photo_count": 2, "document_name": null, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "reason": "Inclusao de documento e foto complementar para validar o fluxo novo.", "added_photo_count": 1, "document_replaced": true}	2026-04-10 19:42:03.181509-03
3d5cf70f-d070-46c8-af07-912a6f7e1838	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	ORGANIZATION	50f5a088-91ef-4275-9c2f-c801e1a52445	Secretaria de Administracao	{"name": "Secretaria de Administracao"}	2026-04-10 20:52:34.902725-03
06e48263-4aff-4f2d-b93a-d5375ab1b137	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	ORGANIZATION	1cee06c5-4607-439f-8818-905b0188293c	Secretaria de Infraestrutura	{"name": "Secretaria de Infraestrutura"}	2026-04-10 20:52:52.255929-03
7d4cc717-b803-41ab-afa2-30e0aec99f03	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	ORGANIZATION	f35cb195-2742-486b-9ea9-cd2e020b00b9	Secretaria de Saude	{"name": "Secretaria de Saude"}	2026-04-10 20:53:04.216107-03
9f4e64e0-304f-4812-9320-f3af595c8247	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	VEHICLE	829c4a2b-db47-4541-bffe-c2443a2ffbdd	ABC-1D23	{"after": {"brand": "Ford", "model": "Ka", "plate": "ABC-1D23", "status": "ATIVO", "location": "Secretaria de Saúde - Departamento Administrativo - Patio Municipal", "chassis_number": "9BFZH55L0G1234567", "ownership_type": "CEDIDO"}, "before": {"brand": "Ford", "model": "Ka", "plate": "ABC-1D23", "status": "ATIVO", "location": "Secretaria de Saúde - Departamento Administrativo - Patio Municipal", "chassis_number": "9BFZH55L0G1234567", "ownership_type": "PROPRIO"}}	2026-04-11 08:33:32.760206-03
53b2b3c4-3ff2-463a-8e0a-7705dc649120	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	VEHICLE	9e484fae-5740-42fa-a72b-4a4e28c54665	DEF-4E56	{"brand": "Chevrolet", "model": "Onix", "status": "MANUTENCAO", "location": "Secretaria de Infraestrutura e Serviços Urbanos - Departamento Administrativo - Oficina Central", "chassis_number": "9BWZZZ377VT004251", "current_driver": null, "ownership_type": "PROPRIO"}	2026-04-13 08:57:55.273893-03
bdec56b6-b930-4688-a62f-3a9be3d0caa6	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	VEHICLE	81846f2c-bc53-4c92-9286-89e2c961583c	GHI-7F89	{"brand": "Toyota", "model": "Corolla", "status": "INATIVO", "location": "Secretaria de Saúde - Departamento Administrativo - Patio Municipal", "chassis_number": "8AWZZZ6K2VA012345", "current_driver": null, "ownership_type": "PROPRIO"}	2026-04-13 08:57:57.702438-03
cab43a16-aaa3-4f31-997a-484f399fda4f	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	VEHICLE	829c4a2b-db47-4541-bffe-c2443a2ffbdd	ABC-1D23	{"brand": "Ford", "model": "Ka", "status": "ATIVO", "location": "Secretaria de Saúde - Departamento Administrativo - Patio Municipal", "chassis_number": "9BFZH55L0G1234567", "current_driver": null, "ownership_type": "CEDIDO"}	2026-04-13 08:57:59.885126-03
b3b596cf-1c2a-4b7f-b304-9a0b1f24d660	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	DRIVER	b4b082f2-acb0-4f50-8365-3c48e35f6dad	Carlos Souza	{"documento": "456.123.789-55", "soft_delete": true, "linked_records": 0}	2026-04-13 08:58:10.318839-03
4db229de-1e06-4a44-91c8-d1a3ad807b26	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	DRIVER	5eb82eb3-3485-459e-8d93-679403f0867f	Joao Silva	{"documento": "123.456.789-00", "soft_delete": true, "linked_records": 0}	2026-04-13 08:58:12.613418-03
1b533785-4c36-401e-8c00-5e3f7e115978	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	DRIVER	9acc4e58-e084-4089-9ec2-8dd99977870e	Maria Oliveira	{"documento": "987.654.321-00", "soft_delete": true, "linked_records": 0}	2026-04-13 08:58:14.389156-03
6811ac17-3b03-4df3-b740-f23b01871e75	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	CREATE	USER	9025070c-12e2-410f-8bb6-ae75fa3ae64e	davisr@pm.teixeiradefreitas.ba.gov.br	{"name": "DAVI SANTANA REGO", "role": "PRODUCAO", "email": "davisr@pm.teixeiradefreitas.ba.gov.br"}	2026-04-13 08:59:01.344115-03
5428c378-f71e-420f-a280-b38ea6c2d1fe	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	USER	065b1e0b-527b-4b65-8a62-008851a22f96	naldorsantosfilho@gmail.com	{"after": {"name": "ARNALDO ROSA DOS SANTOS FILHO", "role": "ADMIN", "email": "naldorsantosfilho@gmail.com", "password_changed": false}, "before": {"name": "Arnaldo Rosa dos Santos Filho", "role": "ADMIN", "email": "naldorsantosfilho@gmail.com"}}	2026-04-13 10:12:02.307678-03
7fc7aa45-8f4d-4be0-af1c-ff308f745581	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	USER	08d425de-0052-42b1-95ab-b3178cde1e30	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	{"after": {"name": "WANDERSON SOUSA LIMAS", "role": "ADMIN", "email": "wanderson.limas@pm.teixeiradefreitas.ba.gov.br", "password_changed": false}, "before": {"name": "WANDERSON SOUSA LIMAS", "role": "PRODUCAO", "email": "wanderson.limas@pm.teixeiradefreitas.ba.gov.br"}}	2026-04-13 11:45:32.125092-03
7973150e-4f7c-4dd9-8ea1-af7c8571834a	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	DELETE	USER	f2ba72df-6b24-41d5-9fa5-4d947672c8d7	carlos@h	{"name": "Carlos Henrique Cruz Honorato", "role": "PRODUCAO"}	2026-04-13 15:59:49.256513-03
fb7230c6-87a4-4af0-b5f2-74cf8dce7db8	\N	Carlos Henrique Cruz Honorato	carlos@h	PRODUCAO	CREATE	POSSESSION	effade1b-30a9-4bb2-8070-fa2dfb4a1eeb	ABC-1D23 - Jonatas	{"start_date": "2026-04-10T15:21:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "teste 03", "driver_contact": "7312345678", "driver_document": "1234567890", "photo_mime_type": "image/jpeg", "photo_size_bytes": 19434, "photo_captured_at": "2026-04-10T12:21:51.160000+00:00", "capture_accuracy_meters": 178.0, "evidence_photo_attached": true}	2026-04-10 09:22:04.630277-03
94794388-5ebe-4b06-a1ef-0f57b8e7927b	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	USER	50fcc408-b540-480a-872e-0f42650871a1	producao@frota.local	{"after": {"name": "Usuario de Producao", "role": "PRODUCAO", "email": "producao@frota.local", "password_changed": true}, "before": {"name": "Usuario de Producao", "role": "PRODUCAO", "email": "producao@frota.local"}}	2026-04-13 16:43:09.67634-03
5bb604d1-5554-4182-a23e-86f45d973e2b	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	ORGANIZATION	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Secretaria de Administração	{"after": {"name": "Secretaria de Administração"}, "before": {"name": "Secretaria de Administração"}}	2026-04-15 20:46:53.365084-03
f8ce96d7-a7e8-426d-8f18-0041c56e4802	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	08c87c40-c5b3-4531-a561-2480d3d65c02	Gabinete do Secretário	{"name": "Gabinete do Secretário", "organization": "Secretaria de Administração"}	2026-04-15 20:48:27.51184-03
81074bcc-d977-4d2d-8cac-5e1d37d6f313	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	9b013e25-2dfb-4276-80ff-73c36923f68f	SESMT	{"name": "SESMT", "organization": "Secretaria de Administração"}	2026-04-15 20:48:42.565904-03
70558585-e1b7-46f5-afdd-c83148653bd1	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	3eac36c0-5ac6-43b7-bafc-2ce55213d70f	Almoxarifado Central	{"name": "Almoxarifado Central", "organization": "Secretaria de Administração"}	2026-04-15 20:48:54.869736-03
4d5c86bf-f089-4898-b2fc-511de8e16d05	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	8ff4e2f2-d4d9-4239-b5a4-2939c8db97f4	Patrimônio e Arquivos em Geral	{"name": "Patrimônio e Arquivos em Geral", "organization": "Secretaria de Administração"}	2026-04-15 20:49:18.680366-03
5eef81b2-08c4-4ad6-ae1d-c240d0090c93	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	6963629c-862f-49f1-b514-d0069096d0f6	Departamento de TI	{"name": "Departamento de TI", "organization": "Secretaria de Administração"}	2026-04-15 20:49:46.021639-03
d231c148-895e-41fb-90cf-4c613fe3e2bf	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	d2399f27-137d-4b0b-bccf-4adc5da83c9a	Secretaria de Administração - SESMT - SESMT	{"name": "SESMT", "department": "SESMT", "organization": "Secretaria de Administração"}	2026-04-15 20:59:11.378042-03
5879e277-e36f-4a58-964b-4407fdb703b1	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	DELETE	DEPARTMENT	dd141042-2a72-4d8e-b8f1-69eb11d83532	Departamento Administrativo	{"name": "Departamento Administrativo", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}	2026-04-15 21:01:38.541815-03
33c523d7-7229-4d9d-87a5-c22a4fd341f0	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	VEHICLE	9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}	2026-04-15 21:02:19.626438-03
73432624-6ba4-433b-9d00-ebf9aa0aacba	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	1a87c196-04c6-4a3d-939d-9f074fc0ef36	Departamento de Recursos Humanos	{"name": "Departamento de Recursos Humanos", "organization": "Secretaria de Administração"}	2026-04-15 20:55:52.752009-03
4a173b2f-53c3-488c-89ce-f6682d152932	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	f9034b11-e997-4d93-9af6-e38076cbcd03	Secretaria de Administração - Departamento de Recursos Humanos - Departamento de Recursos Humanos	{"name": "Departamento de Recursos Humanos", "department": "Departamento de Recursos Humanos", "organization": "Secretaria de Administração"}	2026-04-15 21:00:06.884083-03
33e2fdab-aaa3-400e-9d05-f79fd0926b8b	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	DELETE	ALLOCATION	438d6cb1-f722-4af4-b84b-1dba56c56676	Secretaria de Infraestrutura e Serviços Urbanos - Departamento Administrativo - Oficina Central	{"name": "Oficina Central", "department": "Departamento Administrativo", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}	2026-04-15 21:00:32.304473-03
c6f3d743-dc34-4fb0-a6b7-31b60204c862	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	4febca10-87f3-4f62-8d59-d6bb472dd502	Secretaria de Administração - Departamento Administrativo - Departamento Administrativo	{"name": "Departamento Administrativo", "department": "Departamento Administrativo", "organization": "Secretaria de Administração"}	2026-04-15 21:01:05.756829-03
a23784a2-d86b-4ddc-b838-0a85edc9abe9	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	b90c8744-a5d2-4751-923b-b4498764b756	Secretaria de Administração - Almoxarifado Central - Almoxarifado Central	{"name": "Almoxarifado Central", "department": "Almoxarifado Central", "organization": "Secretaria de Administração"}	2026-04-15 21:01:25.309254-03
cff4b80b-965e-434f-9a61-333f321c280b	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	171ac1a6-9eac-474a-a93a-675611aa783f	Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário	{"name": "Gabinete do Secretário", "department": "Gabinete do Secretário", "organization": "Secretaria de Administração"}	2026-04-15 20:58:48.993092-03
60daf0c7-a655-469c-ac27-c935ee0cb815	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	4129b656-4329-4bdc-af3e-a107f0467cdd	Secretaria de Administração - Patrimônio e Arquivos em Geral - Patrimônio e Arquivos em Geral	{"name": "Patrimônio e Arquivos em Geral", "department": "Patrimônio e Arquivos em Geral", "organization": "Secretaria de Administração"}	2026-04-15 20:59:36.630497-03
9bf79d6b-9ba7-4308-a488-7adb4a696724	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	DELETE	DEPARTMENT	9c5a3de4-107e-444f-a840-d7d2a528190f	Departamento Administrativo	{"name": "Departamento Administrativo", "organization": "Secretaria de Saúde"}	2026-04-15 21:01:33.367656-03
d1d76f54-0c26-4ccf-9cc3-a81b1f9ebee8	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DRIVER	ffd5a632-b7af-4c27-a220-7a03ab17f563	ARNALDO ROSA DOS SANTOS FILHO	{"ativo": true, "email": "arnaldo@pm.teixeiradefreitas.ba.gov.br", "contato": "73999821745", "documento": "06668082521", "cnh_validade": "2034-04-10", "cnh_categoria": "B"}	2026-04-15 21:05:39.550156-03
0ceed2ef-3f9f-4180-bf5b-973ea8fea238	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	66824306-6e4d-4eb8-a3d4-b80010731ca7	Secretaria de Administração - Departamento de TI - Departamento de TI	{"name": "Departamento de TI", "department": "Departamento de TI", "organization": "Secretaria de Administração"}	2026-04-15 20:59:51.030476-03
7309871b-929c-4fee-bc80-ac7e86adc2bb	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	DELETE	ALLOCATION	165ff7ef-b982-4bd5-a1b6-04b1296fd2c7	Secretaria de Saúde - Departamento Administrativo - Patio Municipal	{"name": "Patio Municipal", "department": "Departamento Administrativo", "organization": "Secretaria de Saúde"}	2026-04-15 21:00:27.809277-03
24c16847-f847-42a7-928e-5342c303fd76	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	DELETE	ALLOCATION	ef65fded-e6e0-4b66-b24a-8faafc15068c	Secretaria de Administração - Departamento Administrativo - Garagem Central	{"name": "Garagem Central", "department": "Departamento Administrativo", "organization": "Secretaria de Administração"}	2026-04-15 21:00:42.908963-03
c8c5665d-fac3-4cad-849a-d33a714e8b05	08d425de-0052-42b1-95ab-b3178cde1e30	WANDERSON SOUSA LIMAS	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	ADMIN	CREATE	DEPARTMENT	abceb99f-7796-46df-9166-4d59699a581a	SDE - SEDE	{"name": "SDE - SEDE", "organization": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia"}	2026-04-16 08:40:12.620772-03
072597ce-3c6e-4c56-a6f5-e4a849d01c86	08d425de-0052-42b1-95ab-b3178cde1e30	WANDERSON SOUSA LIMAS	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	ADMIN	CREATE	ALLOCATION	3265a02e-4d56-4cb0-aa6f-4b1103ea3911	Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia - SDE - SEDE - SDE - SEDE	{"name": "SDE - SEDE", "department": "SDE - SEDE", "organization": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia"}	2026-04-16 08:41:42.739476-03
5cd9bb56-1cfb-4a1b-bf19-702adc07dfd0	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	USER	9025070c-12e2-410f-8bb6-ae75fa3ae64e	davisr@pm.teixeiradefreitas.ba.gov.br	{"after": {"name": "DAVI SANTANA REGO", "role": "PRODUCAO", "email": "davisr@pm.teixeiradefreitas.ba.gov.br", "password_changed": true}, "before": {"name": "DAVI SANTANA REGO", "role": "PRODUCAO", "email": "davisr@pm.teixeiradefreitas.ba.gov.br"}}	2026-04-16 10:34:26.757569-03
4ad6422e-b142-42c3-898d-4adba70f4a9d	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	DEPARTMENT	abceb99f-7796-46df-9166-4d59699a581a	Desenvolvimento Econômico - SDE - SEDE	{"after": {"name": "Desenvolvimento Econômico - SDE - SEDE", "organization": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia"}, "before": {"name": "SDE - SEDE", "organization": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia"}}	2026-04-16 11:15:45.185015-03
97e680e7-145d-4b74-bfe8-c1869d8c5d54	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	3b767a49-d988-4686-8351-ca04907e1be7	TOA5G32	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Departamento de TI - Departamento de TI", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R14TT033231", "ownership_type": "LOCADO"}	2026-04-16 11:22:51.468843-03
025e60ce-08c7-4ebe-b971-0b454cd57fd6	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	8a66db72-23cb-45ba-8716-0dc2f89cdf25	Infraestrutura - SEINFRA	{"name": "Infraestrutura - SEINFRA", "organization": "Secretaria de Administração"}	2026-04-16 11:25:44.447855-03
18e69e2a-ce5a-4e26-8f00-2f9b4bfacec8	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	2395d84a-550a-4aac-aaf4-3c5c3ca79314	Secretaria de Administração - Infraestrutura - SEINFRA - Infraestrutura - SEINFRA	{"name": "Infraestrutura - SEINFRA", "department": "Infraestrutura - SEINFRA", "organization": "Secretaria de Administração"}	2026-04-16 11:26:32.003626-03
d35c0c87-b127-4503-a3fd-8b37816d0770	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	ec714e4f-d968-4790-aabd-9390944ad035	Departamento de Frotas	{"name": "Departamento de Frotas", "organization": "Secretaria de Administração"}	2026-04-16 11:28:15.16876-03
26d18e27-db61-4e96-ac21-0ad0c5b9862b	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	979b0bff-f532-4a64-a3c2-ad4a119da580	Secretaria de Administração - Departamento de Frotas - Departamento de Frotas	{"name": "Departamento de Frotas", "department": "Departamento de Frotas", "organization": "Secretaria de Administração"}	2026-04-16 11:28:32.527935-03
25fd52b3-bb92-4aa3-ab59-27215aeadd5e	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	ef947a79-a1a0-42d5-977c-50cc43f016b6	TOA5G25	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Infraestrutura - SEINFRA - Infraestrutura - SEINFRA", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R13TT033575", "ownership_type": "LOCADO"}	2026-04-16 11:29:33.565033-03
75fc8c42-7578-4d29-a86d-e7a4f1f5983a	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	07c1894c-d8aa-45f7-95e4-a44162c608c6	TOA5F48	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Departamento de Frotas - Departamento de Frotas", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R17TT033370", "ownership_type": "LOCADO"}	2026-04-16 11:30:32.016056-03
78dcb898-9569-488d-952a-c63fed8885f0	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	51bf2f46-2ff2-4eca-8ea7-f2364a5b2378	Agricultura - SEAGRI	{"name": "Agricultura - SEAGRI", "organization": "Secretaria de Administração"}	2026-04-16 11:31:41.91221-03
a4c7bbe7-4576-426b-8cc8-b4d22a3d8e76	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	5f9aad8a-fd3f-42fe-8444-8e7432ac3d96	Secretaria de Administração - Agricultura - SEAGRI - Agricultura - SEAGRI	{"name": "Agricultura - SEAGRI", "department": "Agricultura - SEAGRI", "organization": "Secretaria de Administração"}	2026-04-16 11:31:52.023926-03
6b718ee1-156b-4f0c-84fb-0df92a25062a	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	51a8d922-0382-4242-99b0-841b0c8e386a	TOA5F57	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Agricultura - SEAGRI - Agricultura - SEAGRI", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R15TT033464", "ownership_type": "LOCADO"}	2026-04-16 11:32:29.841531-03
80115a10-c730-4039-8aa3-5134aa162712	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	DEPARTMENT	6e0b0f1b-2f83-412e-a128-3fa682ea1190	Gabinete da Secretaria	{"name": "Gabinete da Secretaria", "organization": "Secretaria de Agricultura Pecuária e Abastecimento"}	2026-04-20 11:16:38.748208-03
57ff6943-0d13-4d72-8e9e-df7927a69401	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ALLOCATION	c7e7ff44-4673-4095-aa5e-a50d75656201	Secretaria de Agricultura Pecuária e Abastecimento - Gabinete da Secretaria - Gabinete	{"name": "Gabinete", "department": "Gabinete da Secretaria", "organization": "Secretaria de Agricultura Pecuária e Abastecimento"}	2026-04-20 11:17:02.027361-03
5cff8858-488d-4df3-bf50-30b7cc3bacae	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	DEPARTMENT	51bf2f46-2ff2-4eca-8ea7-f2364a5b2378	Agricultura - SEAGRI	{"name": "Agricultura - SEAGRI", "organization": "Secretaria de Administração"}	2026-04-20 11:17:13.44236-03
96ec98d1-cf4e-42e8-8abb-2cf21892e669	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	DEPARTMENT	8e91b226-caf7-4965-91a1-37adca8d3f30	Gabinete da Secretaria	{"name": "Gabinete da Secretaria", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}	2026-04-20 11:17:37.554567-03
748182c5-a61c-445f-a0cb-4734f721619e	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ALLOCATION	e4771d43-f38c-448a-b777-0feb3ad63194	Secretaria de Infraestrutura e Serviços Urbanos - Gabinete da Secretaria - Gabinete	{"name": "Gabinete", "department": "Gabinete da Secretaria", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}	2026-04-20 11:17:48.96919-03
1cb218b4-c48e-4c05-9828-a18757d06f40	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	DEPARTMENT	8a66db72-23cb-45ba-8716-0dc2f89cdf25	Infraestrutura - SEINFRA	{"name": "Infraestrutura - SEINFRA", "organization": "Secretaria de Administração"}	2026-04-20 11:17:56.076836-03
5b7eebf1-adf3-4dc3-91f0-fd48d195ac3a	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	VEHICLE	51a8d922-0382-4242-99b0-841b0c8e386a	TOA5F57	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TOA5F57", "status": "ATIVO", "location": "Secretaria de Agricultura Pecuária e Abastecimento - Gabinete da Secretaria - Gabinete", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R15TT033464", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TOA5F57", "status": "ATIVO", "location": "Secretaria de Administração - Agricultura - SEAGRI - Agricultura - SEAGRI", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R15TT033464", "ownership_type": "LOCADO"}}	2026-04-20 11:18:53.931915-03
7b1ee018-0eb6-4a52-8eb0-ca5e9b6d9c55	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	VEHICLE	ef947a79-a1a0-42d5-977c-50cc43f016b6	TOA5G25	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TOA5G25", "status": "ATIVO", "location": "Secretaria de Infraestrutura e Serviços Urbanos - Gabinete da Secretaria - Gabinete", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R13TT033575", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TOA5G25", "status": "ATIVO", "location": "Secretaria de Administração - Infraestrutura - SEINFRA - Infraestrutura - SEINFRA", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R13TT033575", "ownership_type": "LOCADO"}}	2026-04-20 11:19:15.973684-03
ca91dd50-e188-4f4f-9533-f5e0a22bfd75	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ALLOCATION	7eb88421-435f-4919-9f66-c7e6b3191e64	Secretaria de Agricultura Pecuária e Abastecimento - Gabinete da Secretaria - SEDE	{"name": "SEDE", "department": "Gabinete da Secretaria", "organization": "Secretaria de Agricultura Pecuária e Abastecimento"}	2026-04-20 11:19:58.892797-03
d9ad12ec-98cd-4643-a26c-d84f11ff2935	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ALLOCATION	ca62c137-72ca-4cb8-9d2d-8cb57fd1a9f4	Secretaria de Infraestrutura e Serviços Urbanos - Gabinete da Secretaria - SEDE	{"name": "SEDE", "department": "Gabinete da Secretaria", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}	2026-04-20 11:20:17.915014-03
a467347a-c5b8-41bc-9485-d5cd2e9e915f	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	71e67d56-af08-4ef2-9077-c6b7ad79a099	Chefia de Governo	{"name": "Chefia de Governo", "organization": "Secretaria de Administração"}	2026-04-22 14:30:03.639504-03
e6d2b497-24e6-44dd-8079-5b506bd33d0d	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	c6c9136b-b07e-4256-a46b-f4d4bdcb7b48	Secretaria de Administração - Chefia de Governo - Chefia de Governo	{"name": "Chefia de Governo", "department": "Chefia de Governo", "organization": "Secretaria de Administração"}	2026-04-22 14:30:25.60732-03
633ca184-69f1-45ce-be0a-93972c75505c	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	0e9d959e-666d-4e9e-92ed-a15cff32db7a	TOA5G28	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Chefia de Governo - Chefia de Governo", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R19TT033208", "ownership_type": "LOCADO"}	2026-04-22 14:36:58.480425-03
95609a4b-c84d-4541-84ff-ca004e2e5024	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	405d91a7-fb9e-4789-9dc3-6f309431bfec	TOA5G11	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Chefia de Governo - Chefia de Governo", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R1XTT033573", "ownership_type": "LOCADO"}	2026-04-22 14:41:58.938149-03
264b5ef6-bdb6-45d3-8805-4af0edf03c3a	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	6857365a-5a63-49ab-a171-ddfb98863a9d	TOA5F65	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Chefia de Governo - Chefia de Governo", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R12TT033518", "ownership_type": "LOCADO"}	2026-04-22 14:46:31.860949-03
1edb8454-bb52-422d-9956-541cebecd8cd	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	TOA5G37	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia - Desenvolvimento Econômico - SDE - SEDE - SDE - SEDE", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R15TT033321", "ownership_type": "LOCADO"}	2026-04-23 14:54:05.450617-03
eb743fc8-4430-49dd-a3f5-eadc014c6b77	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	1adcb869-29ac-4973-8d65-93e1c76bac64	Educação	{"name": "Educação", "organization": "Secretaria de Educação"}	2026-04-23 15:34:39.098836-03
6472b40b-f7b9-4f5b-bb9b-abb0a7361e22	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	462c5c47-1e0a-47e4-b319-b5e58f829d3c	Secretaria de Educação - Educação - Educação	{"name": "Educação", "department": "Educação", "organization": "Secretaria de Educação"}	2026-04-23 15:34:49.546513-03
84759117-7ac4-4973-8ebf-690037ace153	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	f319cfe4-e444-4349-806a-6597a2a56534	Transporte Escolar	{"name": "Transporte Escolar", "organization": "Secretaria de Educação"}	2026-04-23 15:35:03.095258-03
06aa1ea0-433c-4464-b859-288d67120741	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	8866c574-cd7f-4374-99fb-32a6884b36a5	Secretaria de Educação - Transporte Escolar - Transporte Escolar	{"name": "Transporte Escolar", "department": "Transporte Escolar", "organization": "Secretaria de Educação"}	2026-04-23 15:35:17.167032-03
8e45f6e6-9e12-435b-9772-4a93bf0fa262	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	VEHICLE	9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "ATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "ATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}}	2026-04-23 17:11:45.155835-03
8baac8eb-2225-42e4-bae9-13721c353b54	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	VEHICLE	9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "INATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "ATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}}	2026-04-23 17:12:05.105672-03
6b1d5b9f-0757-42f7-ba9e-4235b65f09a1	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	VEHICLE	9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "INATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "INATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "reason": "Veículo devolvido à locadora."}	2026-04-23 18:05:30.074668-03
a01ad943-1825-4c3b-beaa-59055650cf93	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	9c952d6a-cc65-4519-ac6c-369c7c59005a	TOA5G36	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R13TT033611", "ownership_type": "LOCADO"}	2026-04-27 14:37:41.850423-03
db24634e-7fd1-47f5-960b-4fd12c23545b	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	VEHICLE	9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "INATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "INATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "reason": "VEÍCULO RESERVA DEVOLVIDO EM 23/04/2026, À EMPRESA LOCALIZA S/A, POR SER VEÍCULO RESERVA DO VEÍCULO SYK9F47, TAMBÉM DEVOLVIDO."}	2026-04-23 19:12:08.399553-03
8591d47f-2538-486e-8099-49080032584c	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	VEHICLE	8cfde2d0-1d84-4e04-b152-a22cd87dd69c	ABC-1D23	{"brand": "Ford", "model": "Ka", "status": "ATIVO", "location": "Secretaria de Administracao - Gestao Administrativa - Garagem Central", "vehicle_type": "SEDAN", "chassis_number": "9BFZH55L0G1234567", "current_driver": "Joao Silva", "ownership_type": "PROPRIO"}	2026-04-24 14:04:46.730657-03
7a965119-d6ac-4039-b21d-f01467f51e52	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	VEHICLE	eb9a600f-ec93-496f-80a6-0e81355e6739	DEF-4E56	{"brand": "Chevrolet", "model": "Onix", "status": "MANUTENCAO", "location": "Secretaria de Infraestrutura - Oficina - Oficina Central", "vehicle_type": "SEDAN", "chassis_number": "9BWZZZ377VT004251", "current_driver": null, "ownership_type": "LOCADO"}	2026-04-24 14:05:28.430726-03
fb7ab2ca-2e95-44f5-bfda-e5cde11f77ac	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	VEHICLE	56533289-c9ee-416e-a3c1-de9ad2c101c4	GHI-7F89	{"brand": "Toyota", "model": "Corolla", "status": "INATIVO", "location": "Secretaria de Saude - Transporte - Patio Municipal", "vehicle_type": "SEDAN", "chassis_number": "8AWZZZ6K2VA012345", "current_driver": null, "ownership_type": "CEDIDO"}	2026-04-24 14:05:32.784209-03
7dcf8a2a-b1aa-46bd-a72c-4b89327bbde7	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	ORDER_CREATED	FUEL_SUPPLY_ORDER	da18c0c6-e2f7-4b52-819a-fd42275504b0	TOA5G37 - da18c0c6-e2f7-4b52-819a-fd42275504b0	{"id": "da18c0c6-e2f7-4b52-819a-fd42275504b0", "notes": "Teste de fluxo", "status": "OPEN", "driver_id": "b4b082f2-acb0-4f50-8365-3c48e35f6dad", "created_at": "2026-04-24T21:08:13.514630+00:00", "expires_at": "2026-04-25T21:07:00+00:00", "max_amount": 350.0, "updated_at": "2026-04-24T21:08:13.514630+00:00", "vehicle_id": "487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd", "driver_name": "Carlos Souza", "confirmed_at": null, "vehicle_plate": "TOA5G37", "request_number": "AB-DA18C0C6", "created_by_name": "Jonatas da Silva Sousa", "fuel_station_id": "377dde01-11ff-49e2-98fa-f552c4d427b6", "organization_id": "4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d", "validation_code": "OA-34E6133A6CDD", "requested_liters": 45.0, "confirmed_by_name": null, "fuel_station_cnpj": "12.345.678/0001-90", "fuel_station_name": "Posto Centro", "organization_name": "Secretaria de Administração", "created_by_user_id": "2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d", "vehicle_description": "TOA5G37 - VOLKSWAGEN POLO TRACK MA", "confirmed_by_user_id": null, "fuel_station_address": "Avenida Principal, 1000 - Centro", "public_validation_path": "/validar/ordem-abastecimento/OA-34E6133A6CDD"}	2026-04-24 18:08:13.51463-03
b7c92ea9-53f7-45d2-9260-59d192ed679c	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ORGANIZATION	2a3832b2-77fd-4757-a132-ff35cbd197a8	Chefia de Governo	{"name": "Chefia de Governo"}	2026-04-27 11:34:30.445614-03
b9db0cc8-079c-482d-86a5-3036fac7fa7d	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	DEPARTMENT	71e67d56-af08-4ef2-9077-c6b7ad79a099	Chefia de Governo	{"after": {"name": "Chefia de Governo", "organization": "Chefia de Governo"}, "before": {"name": "Chefia de Governo", "organization": "Secretaria de Administração"}}	2026-04-27 11:34:42.781738-03
ddd84291-899c-4710-90e1-18db525e8133	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	2b59966f-e58e-4dc0-ac34-7c6cdb03f29a	Bloco Atenção Básica	{"name": "Bloco Atenção Básica", "organization": "Secretaria de Saude"}	2026-04-27 11:47:45.677623-03
54b88b6c-1c3f-4c8b-b69e-871a0b2b6698	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	3e59f30b-0446-41af-ba12-702fc322e840	Secretaria de Saude - Bloco Atenção Básica - Bloco Atenção Básica	{"name": "Bloco Atenção Básica", "department": "Bloco Atenção Básica", "organization": "Secretaria de Saude"}	2026-04-27 11:47:54.336374-03
ec44343d-6d2d-4602-a2ff-c5f4f427c700	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	69bc7c2a-182a-4086-aad7-76def6a2d313	Media e Alta Complexidade	{"name": "Media e Alta Complexidade", "organization": "Secretaria de Saude"}	2026-04-27 11:48:49.811591-03
f56665e5-3aaa-44e1-b218-cd9aa3994d6f	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	39f52581-7227-45d0-afb5-16bee7638a8e	Secretaria de Saude - Media e Alta Complexidade - Media e Alta Complexidade	{"name": "Media e Alta Complexidade", "department": "Media e Alta Complexidade", "organization": "Secretaria de Saude"}	2026-04-27 11:49:24.50607-03
80240d59-7dbe-4a88-86ab-2fb39c5890ad	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	DEPARTMENT	2b59966f-e58e-4dc0-ac34-7c6cdb03f29a	Bloco Atenção Básica	{"after": {"name": "Bloco Atenção Básica", "organization": "Secretaria de Saúde"}, "before": {"name": "Bloco Atenção Básica", "organization": "Secretaria de Saude"}}	2026-04-27 11:50:41.091633-03
0b1244b9-db43-4470-8332-f2b9010c3fff	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	DEPARTMENT	69bc7c2a-182a-4086-aad7-76def6a2d313	Media e Alta Complexidade	{"after": {"name": "Media e Alta Complexidade", "organization": "Secretaria de Saúde"}, "before": {"name": "Media e Alta Complexidade", "organization": "Secretaria de Saude"}}	2026-04-27 11:50:47.005996-03
46aeb489-34a1-4c99-a0ef-c651f88bb951	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	DEPARTMENT	562c0db6-c943-48b4-ba5c-812e6a622ab8	Transporte	{"after": {"name": "Transporte", "organization": "Secretaria de Saúde"}, "before": {"name": "Transporte", "organization": "Secretaria de Saude"}}	2026-04-27 11:50:51.830464-03
cbcf6267-77fb-40aa-b962-be7af12a3204	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	ORGANIZATION	74cb27a4-7d6e-4219-a9cc-75b0b0e34413	--	{"after": {"name": "--"}, "before": {"name": "Secretaria de Saude"}}	2026-04-27 11:52:22.499576-03
e1b71573-f797-4bc2-b8f8-85f815bea715	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	87ac1809-9f8c-4dc7-aef8-254629ec8f5c	Bolsa Familia	{"name": "Bolsa Familia", "organization": "Secretaria de Promoção Social"}	2026-04-27 11:55:58.06759-03
84b04da4-6462-4c6d-8357-854f82153616	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	{"name": "Bolsa Familia", "department": "Bolsa Familia", "organization": "Secretaria de Promoção Social"}	2026-04-27 11:56:05.546049-03
580a093e-99fd-4dfe-afba-0022125cd3f9	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	d3557c6f-d844-4d5a-8d8a-817c152191f8	Promoção Social	{"name": "Promoção Social", "organization": "Secretaria de Promoção Social"}	2026-04-27 11:56:24.433423-03
b3fd589e-1183-4e85-97bb-b51b1db314f6	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	8c94c02a-0dd1-4f6e-ba34-786c9c94bfae	Secretaria de Promoção Social - Promoção Social - Promoção Social	{"name": "Promoção Social", "department": "Promoção Social", "organization": "Secretaria de Promoção Social"}	2026-04-27 11:56:32.621721-03
0fadaa36-e74c-4f8c-85e0-3afa618b8e72	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	DEPARTMENT	562c0db6-c943-48b4-ba5c-812e6a622ab8	Transporte Saúde	{"after": {"name": "Transporte Saúde", "organization": "Secretaria de Saúde"}, "before": {"name": "Transporte", "organization": "Secretaria de Saúde"}}	2026-04-27 14:38:14.054064-03
aba5f344-09a8-4410-bdbe-bd53cd400084	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	76319288-44d8-4a0e-bde1-eaf71f7c78ff	RDN4B26	{"brand": "YAMAHA", "model": "XTZ150 CROSSER Z", "status": "ATIVO", "location": "Secretaria de Administração - Departamento Administrativo - Departamento Administrativo", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C6DG2580N0013160", "ownership_type": "PROPRIO"}	2026-04-27 16:14:10.108415-03
479c7d9b-871b-4bd0-8845-0b827842b09c	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	edbad937-d073-4cce-8cfd-eead6bbb3d57	Secretaria de Administração - Departamento Administrativo - SESMT	{"name": "SESMT", "department": "Departamento Administrativo", "organization": "Secretaria de Administração"}	2026-04-27 16:15:00.787766-03
ae7e71ca-c43e-4ade-a6d0-3e2c4d35fa75	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	TOA5F96	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R1XTT033539", "ownership_type": "LOCADO"}	2026-04-27 14:39:35.359975-03
fb74c532-861b-4b43-ad66-41231f4cd7f0	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	a3f66399-34eb-4733-aca8-5de0402965dd	TOA5F51	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R14TT033424", "ownership_type": "LOCADO"}	2026-04-27 14:57:51.552065-03
9c539b17-a2e9-4156-aa83-2da5fb21dfee	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	c27ae032-991d-4ab6-a015-8f424ca0961d	Gabinete do Prefeito	{"name": "Gabinete do Prefeito", "organization": "Gabinete do Prefeito"}	2026-04-27 15:03:07.567226-03
cf07aa10-2202-4a43-a0bc-7f76f31a8ab4	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	RPR8J49	{"brand": "FIAT", "model": "ARGO TREKKING", "status": "ATIVO", "location": "Secretaria de Administração - Departamento de Frotas - Departamento de Frotas", "vehicle_type": "HATCH", "chassis_number": "9BD358AGZPYM50057", "ownership_type": "PROPRIO"}	2026-04-27 16:07:40.862638-03
3ce9b6b0-d346-4163-aa81-ed645226baf6	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	ORGANIZATION	1d91b699-2c60-498c-a6e6-32c19ab2ed55	---	{"after": {"name": "---"}, "before": {"name": "Secretaria de Administracao"}}	2026-04-27 16:09:18.920124-03
a0960035-abef-4542-8c61-39983466b9cd	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	VEHICLE	76319288-44d8-4a0e-bde1-eaf71f7c78ff	RDN4B26	{"after": {"brand": "YAMAHA", "model": "XTZ150 CROSSER Z", "plate": "RDN4B26", "status": "ATIVO", "location": "Secretaria de Administração - Departamento Administrativo - SESMT", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C6DG2580N0013160", "ownership_type": "PROPRIO"}, "before": {"brand": "YAMAHA", "model": "XTZ150 CROSSER Z", "plate": "RDN4B26", "status": "ATIVO", "location": "Secretaria de Administração - Departamento Administrativo - Departamento Administrativo", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C6DG2580N0013160", "ownership_type": "PROPRIO"}, "reason": "O veículo está sendo utilizado pelo SESMT"}	2026-04-27 16:16:52.133461-03
a353532b-f5dc-487b-b418-29a1de111fe3	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	1f1ccd7a-6e77-4ebe-8978-721246a664a0	TOA5F86	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R17TT033529", "ownership_type": "LOCADO"}	2026-04-27 14:40:31.029674-03
dedc55d2-d67e-4b3d-8551-db482911d16f	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	92c9ea0b-a61e-40f9-bea2-0e22815ea371	TOA5F46	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R14TT033326", "ownership_type": "LOCADO"}	2026-04-27 15:01:04.30363-03
aa83570f-695d-445d-99cd-e6dae0692a5e	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	ORGANIZATION	471860e8-fe57-4181-bb14-cf3098787905	Gabinete do Prefeito	{"after": {"name": "Gabinete do Prefeito"}, "before": {"name": "Gabiente do Prefeito"}}	2026-04-27 15:02:51.633723-03
b9372fa3-c40d-46b5-aa38-16ca755caecc	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	29beb9b9-c610-459f-96de-75028ed0bd29	TOA5F53	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Gabinete do Prefeito - Gabinete do Prefeito - Gabinete do Prefeito", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R11TT033428", "ownership_type": "LOCADO"}	2026-04-27 15:08:13.692254-03
746b1646-2fbd-43e0-8d78-26403c5c7500	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	5383baa6-72ad-410b-b430-ec9def1fcc44	RPF9C78	{"brand": "RENAULT", "model": "KWID", "status": "ATIVO", "location": "Secretaria de Administração - Departamento Administrativo - Departamento Administrativo", "vehicle_type": "SEDAN", "chassis_number": "93YRBB004PJ249712", "ownership_type": "PROPRIO"}	2026-04-27 16:18:57.740704-03
c54b02d4-ea55-4d77-9d8f-b340c68c8ebc	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	7434a217-b23b-4696-99a7-30bb56ecbe87	TOA5F83	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R13TT033513", "ownership_type": "LOCADO"}	2026-04-27 14:41:22.213155-03
5723df67-c5ad-455f-bb0e-da37de319da3	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	935fdaee-e400-4be1-bd96-0e8955da50ff	Gabinete do Prefeito - Gabinete do Prefeito - Gabinete do Prefeito	{"name": "Gabinete do Prefeito", "department": "Gabinete do Prefeito", "organization": "Gabinete do Prefeito"}	2026-04-27 15:03:14.580663-03
db15e561-1d48-4ec3-af51-587d6e321d53	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	DEPARTMENT	0093febc-e750-466e-be19-be85945c2472	Gestão Administrativa	{"after": {"name": "Gestão Administrativa", "organization": "Secretaria de Administração"}, "before": {"name": "Gestao Administrativa", "organization": "Secretaria de Administracao"}}	2026-04-27 16:08:57.364883-03
a5e0edde-64a7-4a4b-89da-2ec72e7ae2d3	08d425de-0052-42b1-95ab-b3178cde1e30	WANDERSON SOUSA LIMAS	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	ADMIN	DELETE	ORGANIZATION	1d91b699-2c60-498c-a6e6-32c19ab2ed55	---	{"name": "---"}	2026-04-27 16:09:40.018568-03
caf86ae7-969a-4725-936c-4a3dbeb358c1	08d425de-0052-42b1-95ab-b3178cde1e30	WANDERSON SOUSA LIMAS	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	ADMIN	DELETE	ORGANIZATION	74cb27a4-7d6e-4219-a9cc-75b0b0e34413	--	{"name": "--"}	2026-04-27 16:09:40.175138-03
d88d50f1-369d-4331-b174-65a095f73f65	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	b6ac4e0b-b746-4351-90a7-45ed15fa0250	Secretaria de Administração - Departamento Administrativo - DAP	{"name": "DAP", "department": "Departamento Administrativo", "organization": "Secretaria de Administração"}	2026-04-27 16:15:08.794487-03
07bd71fc-82f8-45a0-a0b0-55806d003a26	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	456486fe-e416-4b20-9e94-b5b9f5bbc877	RDN2D20	{"brand": "YAMAHA", "model": "XTZ150 CROSSER Z", "status": "ATIVO", "location": "Secretaria de Administração - Departamento Administrativo - DAP", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C6DG2580N0013151", "ownership_type": "PROPRIO"}	2026-04-27 16:17:36.167767-03
28091aee-30b2-44ca-bd54-348946993b70	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	PLT9G24	{"brand": "RENAULT", "model": "SANDERO", "status": "ATIVO", "location": "Secretaria de Administração - Departamento Administrativo - Departamento Administrativo", "vehicle_type": "HATCH", "chassis_number": "93Y5SRF84LJ843409", "ownership_type": "PROPRIO"}	2026-04-27 16:31:37.176165-03
93f7c4d5-7675-4c59-b737-6b29a0ddfef1	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	USER	a28ad20a-f325-4b9b-a20f-ca74c5d848fd	madsonjs@gmail.com	{"name": "MADSON SILVA ARAUJO", "role": "ADMIN", "email": "madsonjs@gmail.com"}	2026-04-30 14:11:48.436785-03
119a869b-e4ac-4d69-a3fa-2d154be6e15b	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	VEHICLE	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	TOA5G07	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT033209", "ownership_type": "LOCADO"}	2026-05-02 10:55:05.271458-03
40b1ba90-d2e4-48c2-bd48-54f7c048bb50	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DRIVER	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	ITAMAR ALVES RODRIGUES	{"ativo": true, "email": "itamar@pm.teixeiradefreitas.ba.gov.br", "contato": "7399900-2142", "documento": "042.515.165-40", "cnh_validade": "2032-02-10", "cnh_categoria": "B"}	2026-05-02 10:58:19.569898-03
b208fe34-1281-4a73-a81d-fb76c8a56341	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	POSSESSION	b9e4468b-0f73-4726-a10e-d0825b630d07	TOA5G07 - ITAMAR ALVES RODRIGUES	{"start_date": "2026-05-02T14:10:00+00:00", "vehicle_id": "0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7", "observation": "VIAGEM À PORTO SEGURO-BA EM 02/05/2026.", "photo_count": 0, "driver_contact": "7399900-2142", "driver_document": "042.515.165-40", "kilometers_driven": null, "start_odometer_km": 1803.0, "signed_document_name": null, "capture_accuracy_meters": [], "signed_document_attached": false, "signed_document_mime_type": null, "signed_document_size_bytes": null}	2026-05-02 11:14:48.870979-03
3fd1abb6-43b2-4c44-8cbb-892c93c10379	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	POSSESSION	b9e4468b-0f73-4726-a10e-d0825b630d07	TOA5G07 - ITAMAR ALVES RODRIGUES	{"after": {"end_date": null, "driver_id": "9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a", "start_date": "2026-05-02T14:10:00+00:00", "driver_name": "ITAMAR ALVES RODRIGUES", "observation": "VIAGEM À PORTO SEGURO-BA EM 02/05/2026.", "photo_count": 0, "document_name": "CCO_000118.pdf", "driver_contact": "7399900-2142", "driver_document": "042.515.165-40", "end_odometer_km": null, "kilometers_driven": null, "start_odometer_km": 1803.0}, "event": "ADMIN_EDIT", "before": {"end_date": null, "driver_id": "9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a", "start_date": "2026-05-02T14:10:00+00:00", "driver_name": "ITAMAR ALVES RODRIGUES", "observation": "VIAGEM À PORTO SEGURO-BA EM 02/05/2026.", "photo_count": 0, "document_name": null, "driver_contact": "7399900-2142", "driver_document": "042.515.165-40", "end_odometer_km": null, "start_odometer_km": 1803.0}, "reason": "Documento TERMO DE EMPRÉSTIMO anexado.", "added_photo_count": 0, "document_replaced": true}	2026-05-02 11:46:38.374921-03
df71ad74-525b-46b7-81ea-9adf7df2327b	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	POSSESSION	b9e4468b-0f73-4726-a10e-d0825b630d07	TOA5G07 - ITAMAR ALVES RODRIGUES	{"event": "END_POSSESSION", "end_date": "2026-05-03T11:21:00+00:00", "observation": "VIAGEM À PORTO SEGURO-BA EM 02/05/2026. \\nVEÍCULO DEVOLVIDO EM 03/05/2021, SEM NENHUMA INTECORRÊNCIA.", "end_odometer_km": 2353.0, "kilometers_driven": 550.0}	2026-05-03 08:31:06.157322-03
cea99fc4-dcbc-4056-9089-c264dad47ec0	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	TGS2G58	{"brand": "VOLKSWAGEN", "model": "NEOBUS", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "953AD5TF4TR005350", "ownership_type": "PROPRIO"}	2026-05-04 16:37:39.628895-03
847a4e7d-62a3-4d00-a837-59b72dd113ea	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	86552253-01f8-43a2-adbc-cc6f93fbe211	TGR8A52	{"brand": "RENAULT", "model": "MASTER", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "MICRO_ONIBUS", "chassis_number": "93YF62009SJ064734", "ownership_type": "PROPRIO"}	2026-05-04 16:38:27.340487-03
02ca6792-47fd-49cb-9138-652ed68353e5	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	be0a71b5-1dda-4a7b-8432-dfeb79724b42	TEV3G61	{"brand": "FIAT", "model": "STRADA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "PICAPE", "chassis_number": "9BD281BKPSYH05662", "ownership_type": "PROPRIO"}	2026-05-04 16:43:17.498038-03
ad3a2715-1f06-4952-9498-00e605fd7e95	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	1786752f-e3ae-44e8-aaa7-f8592b61f280	SKS2D14	{"brand": "MERCEDES", "model": "JI MICRO", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "MICRO_ONIBUS", "chassis_number": "8AC907843SE256017", "ownership_type": "PROPRIO"}	2026-05-04 16:44:30.993613-03
c4dd9178-1d1e-41ca-ac7b-13da41e916d0	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	c95ce3e6-ddbd-4005-90a7-4a4347c26802	SKL0F32	{"brand": "AGRALE", "model": "MARRUA", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9BYMBCAKASC000104", "ownership_type": "PROPRIO"}	2026-05-04 16:46:55.780498-03
1fc4c4f5-7958-46bb-87b4-ec50f0f0dbeb	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	b029e585-6b32-47fa-96c0-de67a6970963	RPG5I35	{"brand": "MERCEDES", "model": "LO 916 ESC", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9BM979282PB268478", "ownership_type": "PROPRIO"}	2026-05-04 16:59:00.859806-03
62370b93-7aa6-4b9e-822d-f698252fec7a	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	5c661a09-3f3e-4fd5-a576-2b97177a9c90	RDQ7C68	{"brand": "MERCEDES", "model": "ACCELO", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9BM979076MB216818", "ownership_type": "PROPRIO"}	2026-05-05 15:43:50.223705-03
95123f02-4c21-41ea-bb55-7c93e185e113	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	c3129621-9e62-4c33-8c78-88472a981c2e	RPO5C57	{"brand": "FIAT", "model": "CRONOS", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "8AP359AFPPU260739", "ownership_type": "PROPRIO"}	2026-05-05 15:52:42.693588-03
de8d4c75-5c63-4932-939b-991597ffefd8	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	RPR9A34	{"brand": "FIAT", "model": "ARGO TREKKING", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BD358AGZPYM50464", "ownership_type": "PROPRIO"}	2026-05-04 16:49:02.492304-03
71416063-6d60-40b6-9be3-5a4bc028488a	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	9a6b1c3d-d9a9-4244-b08d-040d7debd465	RPD5C32	{"brand": "MERCEDES", "model": "LO 916 ESC", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9BM979277PB261556", "ownership_type": "PROPRIO"}	2026-05-05 15:38:14.123097-03
fcaef4f6-3cf9-4b2b-84b9-8a9d2c0ebe45	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	8cdf0237-d061-4f6b-9541-409c2bf795c0	RCW6D96	{"brand": "IVECO", "model": "10-190E", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "93ZK01BDZM8938939", "ownership_type": "PROPRIO"}	2026-05-05 15:47:53.124273-03
c209fc98-2955-4662-b7ae-4e1d7b97562e	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	79daeec7-8cd2-415d-9dff-8133a4644d4e	PLM5H74	{"brand": "FIAT", "model": "STRADA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "PICAPE", "chassis_number": "9BD57834FKY284368", "ownership_type": "PROPRIO"}	2026-05-05 15:54:24.30202-03
caf11cc1-5347-474e-871d-bd81eb7e2939	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	98747d4a-8ab2-4c37-9e33-d425b2ee711f	RPR0D77	{"brand": "FIAT", "model": "CRONOS", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "8AP359AFPPU236374", "ownership_type": "PROPRIO"}	2026-05-04 16:52:49.17403-03
7f844389-e2c4-4fe3-a5f2-e56ba650537b	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	2b827cd4-988f-435f-b869-5f2e8a31b8e4	RPD5D07	{"brand": "MERCEDES", "model": "LO 916 ESC", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9BM979277PB264347", "ownership_type": "PROPRIO"}	2026-05-05 15:37:26.118601-03
94fe2bd4-e9a9-46ea-b132-531b39175fe4	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	RCW9G31	{"brand": "IVECO", "model": "10-190E", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "93ZK01BDZM8938941", "ownership_type": "PROPRIO"}	2026-05-05 15:47:07.760079-03
395819f7-6ec1-4194-b13a-3707aff00c22	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	RPO1J48	{"brand": "MERCEDES", "model": "LO 916 ESC", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9BM979282PB286540", "ownership_type": "PROPRIO"}	2026-05-05 15:53:37.926822-03
e4540369-7284-49d7-9749-9152249919f8	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	631fc463-0e98-4eac-8c04-a3e79a400b13	RPP8G47	{"brand": "CHEVROLET", "model": "SPIN", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "9BGJP7520PB217662", "ownership_type": "PROPRIO"}	2026-05-04 16:56:51.405719-03
f949ef1b-b86a-46d8-9459-d2b2cec5a2e0	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	fb6a50e6-b181-4ef7-a769-36a388ea9c74	RPD2H45	{"brand": "MERCEDES", "model": "LO 916 ESC", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9BM979277PB266139", "ownership_type": "PROPRIO"}	2026-05-05 15:40:56.289894-03
511b7df6-8e7d-4bf4-95c9-9546a4ee49f2	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	7e7d9b74-4814-4296-af40-5c76dd905a56	RCV1A48	{"brand": "MARCOPOLO", "model": "VOLARE", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "93PB58M10MC063628", "ownership_type": "PROPRIO"}	2026-05-05 15:51:36.812135-03
12d26c21-e8f1-4481-b7aa-49600766557c	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	7109a9d3-6639-4814-a38f-a0aefc48b4de	RPM5J88	{"brand": "MERCEDES", "model": "LO 916 ESC", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9BM979282PB277325", "ownership_type": "PROPRIO"}	2026-05-04 16:58:04.889896-03
3424ee24-3b57-4ac7-9fc3-005300b7f863	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	c7eda8b7-bd55-4970-8997-64b16b606b6f	RPD4I26	{"brand": "MERCEDES", "model": "LO 916 ESC", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9BM979277PB264319", "ownership_type": "PROPRIO"}	2026-05-05 15:39:29.091115-03
a82fcc03-8b08-4cf3-b793-70f21c11fd48	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	1a474e84-42d7-4710-9b0c-7379c805041d	RCV3E37	{"brand": "MARCOPOLO", "model": "VOLARE", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "93PB58M10MC063635", "ownership_type": "PROPRIO"}	2026-05-05 15:50:44.761095-03
718f9bba-db88-4e63-b3c2-db5431746d56	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	b137d4b0-9960-43a4-a9f8-916136fa73ee	PLD3395	{"brand": "FIAT", "model": "ARGO", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BD358A1NJYH86840", "ownership_type": "PROPRIO"}	2026-05-06 14:48:22.931624-03
c941109a-909c-4038-aa45-c8526f905b41	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	ec382e7b-22e2-41ca-9797-958ddf8128a3	PKH8362	{"brand": "IVECO", "model": "CITYCLASS", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "93ZL68C01E8456872", "ownership_type": "PROPRIO"}	2026-05-06 14:50:31.747131-03
c968f202-557f-474c-8c54-ad1edf9a4c8f	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	c5e6bea5-1489-42f2-aa5c-0966007bcd9f	PJU8904	{"brand": "VOLKSWAGEN", "model": "8.160 DRC", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "CAMINHAO", "chassis_number": "9531M52P4GR600604", "ownership_type": "PROPRIO"}	2026-05-06 14:52:04.251572-03
3d04408d-24e6-488e-9f7b-eb6e8398dc50	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	bc17f68a-a40e-4bcc-b044-c6efd267ad19	PJU1358	{"brand": "VOLKSWAGEN", "model": "8.160 DRC", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "CAMINHAO", "chassis_number": "9531M52P2GR601346", "ownership_type": "PROPRIO"}	2026-05-06 14:53:13.813737-03
b2cbcdd9-9cde-4191-a32a-ab49d4813253	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	VEHICLE	c5e6bea5-1489-42f2-aa5c-0966007bcd9f	PJU8904	{"after": {"brand": "VOLKSWAGEN", "model": "8.160 DRC", "plate": "PJU8904", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "CAMINHAO", "chassis_number": "9531M52P4GR600604", "ownership_type": "PROPRIO"}, "before": {"brand": "VOLKSWAGEN", "model": "8.160 DRC", "plate": "PJU8904", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "CAMINHAO", "chassis_number": "9531M52P4GR600604", "ownership_type": "PROPRIO"}, "reason": "Cadastrado no departamento errado"}	2026-05-06 14:54:09.946852-03
e3d7ab53-3241-4af6-8b4f-4dfc55d30540	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	2bac086f-7650-4aed-a915-7c853a0e727a	PJS9422	{"brand": "FIAT", "model": "STRADA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "PICAPE", "chassis_number": "9BD57814UGB048539", "ownership_type": "PROPRIO"}	2026-05-06 14:55:56.300228-03
f887b950-ddef-41ae-8403-8c349c485fe8	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	8b48d4ef-cdad-4489-9af7-db977571ed88	PJS3914	{"brand": "FIAT", "model": "STRADA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "PICAPE", "chassis_number": "9BD57814UGB049318", "ownership_type": "PROPRIO"}	2026-05-06 14:57:10.39655-03
65fb346f-a920-4711-9024-ad7e9a1e3958	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	72b3a123-3335-476e-ade8-1cd2bf8e22d1	PJS3723	{"brand": "FIAT", "model": "PALIO", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BD17122ZG7574872", "ownership_type": "PROPRIO"}	2026-05-06 15:10:28.664392-03
6fc9b8da-3ae8-4dd1-8059-51cd91a9e13d	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	3b1d50ae-23f6-4a17-bf6a-f39752f95697	PJS3017	{"brand": "FIAT", "model": "STRADA WORKING", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "9BD57814UGB049302", "ownership_type": "PROPRIO"}	2026-05-06 15:15:04.138461-03
ff104943-42bf-478e-b010-30c48bf54a8b	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	VEHICLE	3b1d50ae-23f6-4a17-bf6a-f39752f95697	PJS3017	{"after": {"brand": "FIAT", "model": "STRADA", "plate": "PJS3017", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "PICAPE", "chassis_number": "9BD57814UGB049302", "ownership_type": "PROPRIO"}, "before": {"brand": "FIAT", "model": "STRADA WORKING", "plate": "PJS3017", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "9BD57814UGB049302", "ownership_type": "PROPRIO"}, "reason": "Correção da categoria"}	2026-05-06 15:15:51.027632-03
b99f1a6f-faad-474e-87ed-4d54ae945c5f	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	585dc2bb-c774-486a-8ad2-b12544d3d7d0	PJS1489	{"brand": "FIAT", "model": "PALIO FIRE", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "9BD17122ZG7574059", "ownership_type": "PROPRIO"}	2026-05-06 15:19:57.728511-03
710834a9-b5e5-4f95-993f-f0bc8b45c2f1	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	d758d9ab-084a-42e8-a474-f85ef8109ea6	PJS1032	{"brand": "FIAT", "model": "STRADA WORKING", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "9BD57814UGB048397", "ownership_type": "PROPRIO"}	2026-05-06 15:22:38.449086-03
fa8adbd9-27e9-4255-a66d-d081d1e36df3	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	62ed0519-240d-4611-9cb9-b8003be5b369	PJS0988	{"brand": "FIAT", "model": "PALIO FIRE", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BD17122ZG7574154", "ownership_type": "PROPRIO"}	2026-05-06 15:25:18.970814-03
f8e7b6b0-b137-4546-b58a-e9451f1e6e08	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	VEHICLE	d758d9ab-084a-42e8-a474-f85ef8109ea6	PJS1032	{"after": {"brand": "FIAT", "model": "STRADA", "plate": "PJS1032", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "PICAPE", "chassis_number": "9BD57814UGB048397", "ownership_type": "PROPRIO"}, "before": {"brand": "FIAT", "model": "STRADA WORKING", "plate": "PJS1032", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "9BD57814UGB048397", "ownership_type": "PROPRIO"}, "reason": "Categoria do veículo"}	2026-05-06 15:25:52.571443-03
e3f21a02-e704-4487-a39f-a22d4f2e87cd	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	25226f6b-6acc-4356-96f9-c3cd85b994b8	PJL9271	{"brand": "FIAT", "model": "PALIO FIRE WAY", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BD17144ZG7553966", "ownership_type": "PROPRIO"}	2026-05-06 15:28:07.536243-03
3f75f9aa-58a3-4d94-9a38-5801265bc5d5	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	4f6d1058-ebbd-4f81-96a0-ccdc19c9ed05	OZQ0183	{"brand": "VW", "model": "15.190 EOD E.HD ORE", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9532E82W3ER439427", "ownership_type": "PROPRIO"}	2026-05-06 15:38:57.510394-03
d50373fc-5113-40b7-8432-14424a1750e8	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	befb7af5-986b-4685-bbd8-de53b159bfef	PJL2213	{"brand": "FIAT", "model": "PALIO FIRE WAY", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BD17144ZG7553747", "ownership_type": "PROPRIO"}	2026-05-06 15:30:27.158505-03
925355e8-287b-416d-aa86-3a5d665aed44	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	a54306d3-6b90-4c2a-9844-bebce0a32854	OUZ7074	{"brand": "MARCOPOLO", "model": "VOLARE V8L EO", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "93PB54M10EC049348", "ownership_type": "PROPRIO"}	2026-05-06 15:40:36.742414-03
946c695e-d2ab-467f-97fb-4b4a8409662a	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	4b8d5b8c-53e5-4662-9725-12e633182843	PJC5306	{"brand": "M.BENZ", "model": "OF 1519 R.ORE", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9BM384069EB961259", "ownership_type": "PROPRIO"}	2026-05-06 15:33:34.928813-03
10c9d03d-85c0-4876-8487-4a91ca8f20dc	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	9d5d671d-9fd5-4fcd-a27a-c4d91704fbe6	OUZ5383	{"brand": "MARCOPOLO", "model": "VOLARE V8L EO", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "MICRO_ONIBUS", "chassis_number": "93PB55M1BEC049553", "ownership_type": "PROPRIO"}	2026-05-06 15:48:58.7455-03
ecfb74d3-ff04-410f-9a73-bf21c0b3117e	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	b166fa01-6228-45a8-87ba-4575978ee8cf	OZQ7807	{"brand": "VW", "model": "15.190 EOD E.HD ORE", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9532E82W4ER439422", "ownership_type": "PROPRIO"}	2026-05-06 15:36:18.675151-03
99318b2a-8b0f-4e15-bdfb-72e77792e81e	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	ec530224-b28d-4883-8109-093950bd2650	OZQ4838	{"brand": "VW", "model": "15.190 EOD E.HD ORE", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "9532E82W5ER439140", "ownership_type": "PROPRIO"}	2026-05-06 15:37:50.193294-03
419a4af0-97a0-4ea7-98cf-53761d706219	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	53afecc8-8b0c-4372-9dc4-86e87d4d7aee	OUZ1639	{"brand": "MARCOPOLO", "model": "VOLARE", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "93PB55M10EC049550", "ownership_type": "PROPRIO"}	2026-05-07 08:39:05.693902-03
67cf565d-1944-4708-a05d-7ab9c43cfd5d	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	c4bb98ae-b770-4303-80f2-6c969f85c205	OUX1811	{"brand": "MERCEDES", "model": "OF 1519 R.ORE", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "ONIBUS", "chassis_number": "9BM384069EB923057", "ownership_type": "PROPRIO"}	2026-05-07 08:49:34.884641-03
b832ee20-a6f2-44ec-9914-1cdb3864574b	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	3e5c4e1d-f72d-4146-bf05-78918e6093ee	NYJ9040	{"brand": "VOLSKWAGEN", "model": "KOMBI", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "MICRO_ONIBUS", "chassis_number": "9BWMF07XXBP012417", "ownership_type": "PROPRIO"}	2026-05-07 08:57:22.838143-03
da44343a-56c2-4c1e-ae5e-5358a41a670e	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	020650d7-65e4-4a3f-8086-b81627409e93	JSY6984	{"brand": "VOLSKWAGEN", "model": "8.150E DELIVERY", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "CAMINHAO", "chassis_number": "9531952P3AR018728", "ownership_type": "PROPRIO"}	2026-05-07 09:00:50.90818-03
a095c641-771d-4ddc-9a50-6a0e6b6e0d6c	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	VEHICLE	3e5c4e1d-f72d-4146-bf05-78918e6093ee	NYJ9040	{"after": {"brand": "VOLSKWAGEN", "model": "KOMBI", "plate": "NYJ9040", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "VAN", "chassis_number": "9BWMF07XXBP012417", "ownership_type": "PROPRIO"}, "before": {"brand": "VOLSKWAGEN", "model": "KOMBI", "plate": "NYJ9040", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "MICRO_ONIBUS", "chassis_number": "9BWMF07XXBP012417", "ownership_type": "PROPRIO"}, "reason": "Aplicação de categoria correta para o veículo."}	2026-05-07 09:02:13.678316-03
e0efb69d-cc54-41aa-9cfe-dcd48110f029	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	e5ce2035-52de-4439-b2ff-946b14b16fc9	JSX-8119	{"brand": "VOLSKWAGEN", "model": "9.150E CUMMINS", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "CAMINHAO", "chassis_number": "9533A62R1AR008500", "ownership_type": "PROPRIO"}	2026-05-07 09:27:19.174835-03
2bf0889b-34c6-4f6e-be69-c6e885e55e8a	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	USER	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	itamar@pm.teixeiradefreitas.ba.gov.br	{"name": "Itamar Alves Rodrigues", "role": "PRODUCAO", "email": "itamar@pm.teixeiradefreitas.ba.gov.br", "must_change_password": true}	2026-05-07 10:10:27.47169-03
53b08a14-a3cf-4fab-8a00-704c8c3fd2ce	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	USER	88657b27-be9c-434a-ad5d-ffc746a56ecd	cassioof@pm.teixeiradefreitas.ba.gov.br	{"name": "Cassio de Oliveira Farias", "role": "PRODUCAO", "email": "cassioof@pm.teixeiradefreitas.ba.gov.br", "must_change_password": true}	2026-05-07 10:11:40.666849-03
599bc479-522d-4e53-a296-3ed0e008d22e	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	USER	0ee24af6-449b-4560-a5ae-f5bfedf66620	paulom@edu.teixeiradefreitas.ba.gov.br	{"name": "Paulo Murilo Alvares dos Santos", "role": "PRODUCAO", "email": "paulom@edu.teixeiradefreitas.ba.gov.br", "must_change_password": true}	2026-05-07 10:12:26.698386-03
cc75dcea-7caf-4242-a481-7f467521a56e	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	52a0395e-da68-421f-885a-5a56cb279965	JSW8166	{"brand": "FIAT", "model": "UNO MILLE WAY ECON", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BD15844AA6398131", "ownership_type": "PROPRIO"}	2026-05-07 10:14:36.430233-03
df9834b1-664d-4782-9d97-ad805b5f05aa	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	b626cbb5-9afe-41ba-a091-1c51af0c347f	JQJ4844	{"brand": "FIAT", "model": "UNO MILLE FIRE FLEX", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BD15822764695692", "ownership_type": "PROPRIO"}	2026-05-07 10:20:08.861582-03
f87df7f0-244f-47d6-b61c-25aaeb26ca58	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	162ac9f5-14ed-4f2b-bdc5-356f108312ef	JOB-7263	{"brand": "MARCOPOLO", "model": "VOLARE LOTACAO", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "ONIBUS", "chassis_number": "93PB02A2M2C007175", "ownership_type": "PROPRIO"}	2026-05-07 10:22:10.133755-03
3846c58a-8089-46a9-bd29-dfa964539fbb	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	b01d4bc2-26b0-485a-ae91-e03f3de9af8e	TGZ5F58	{"brand": "IVECO", "model": "DAILY 55CS", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "CAMINHAO", "chassis_number": "93ZC653DZR8207554", "ownership_type": "PROPRIO"}	2026-05-07 10:24:49.924243-03
fa055a40-b241-4681-80c7-ed0456ccf1b7	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	02c1c1be-cb8a-4e8a-8e76-3d2be467d44f	THA7J98	{"brand": "CHEVROLET", "model": "ONIX 10TAT HB", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BGEA48H0SG252197", "ownership_type": "PROPRIO"}	2026-05-07 10:30:55.482217-03
2704ae6a-87e4-4523-8f59-d7900c7a9d5f	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	2d24caa9-0528-4a34-b542-fb139e4c25c8	TML-9I02	{"brand": "CHEVROLET", "model": "SPIN 1.8L AT LTZ", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "9BGJC7520TB160917", "ownership_type": "PROPRIO"}	2026-05-07 10:32:57.722534-03
a3717795-2fc0-4adc-8ddd-008ef53bfb56	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	847b4b9f-0737-4b1a-a917-4aed3f079beb	TMM2E05	{"brand": "VOLSKWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R19TP034383", "ownership_type": "PROPRIO"}	2026-05-07 10:37:19.286705-03
f1480dd7-eaa7-4525-a16d-ab1614803d08	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	5f48e555-5e61-47f4-afa1-aa7220e07d2f	JRV8415	{"brand": "VOLSKWAGEN", "model": "POLO SEDAN 1.6", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWDB09N89P018203", "ownership_type": "PROPRIO"}	2026-05-07 10:40:41.198821-03
eeff4f28-d74b-4956-a5c8-cdd961dfe321	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	bb065bfa-0fec-4912-866b-d8f83bc14808	TML4E34	{"brand": "CHEVROLET", "model": "SPIN 1.8L AT LTZ", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SUV", "chassis_number": "9BGJC7520TB160873", "ownership_type": "PROPRIO"}	2026-05-07 10:53:57.412157-03
daf4f2c0-6b66-4450-8cc5-fae0229773cf	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	VEHICLE	162ac9f5-14ed-4f2b-bdc5-356f108312ef	JOB-7263	{"after": {"brand": "MARCOPOLO", "model": "VOLARE LOTACAO", "plate": "JOB-7263", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "ONIBUS", "chassis_number": "93PB02A2M2C007175", "ownership_type": "PROPRIO"}, "before": {"brand": "MARCOPOLO", "model": "VOLARE LOTACAO", "plate": "JOB-7263", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "ONIBUS", "chassis_number": "93PB02A2M2C007175", "ownership_type": "PROPRIO"}, "reason": "Departamanto inserido de manira correta."}	2026-05-07 10:44:38.67247-03
1e99bfc4-5f11-4e34-ac1a-b12b18480d52	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	c21808fa-1f48-41df-b18d-56de492b6105	TMM4H63	{"brand": "VOLSKWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R19TP031029", "ownership_type": "PROPRIO"}	2026-05-07 10:58:45.36138-03
6d8a2648-abb0-4d4f-810e-7c3167418759	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	a83cd43f-d0cf-48a0-8338-a5dad123dbef	PKU2611	{"brand": "FIAT", "model": "PALIO", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "HATCH", "chassis_number": "01138901137", "ownership_type": "PROPRIO"}	2026-05-07 11:04:43.74397-03
aeb7a1b0-b076-4ae5-8f73-777390de7bfc	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	fa1c9c7d-97b2-44ae-9f81-e8512fbf629b	OZU0237	{"brand": "FIAT", "model": "DOBLO", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "PERUA_SW", "chassis_number": "01035410530", "ownership_type": "PROPRIO"}	2026-05-07 11:16:21.942509-03
e025bfee-de62-4fa1-910f-d82e767da16b	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	fc7d2025-da07-4d13-a50e-f4482ba86eb4	TMO1H35	{"brand": "FIAT", "model": "STRADA ENDURAN CS13", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "PICAPE", "chassis_number": "9BD281AJPTYBD8716", "ownership_type": "PROPRIO"}	2026-05-07 14:29:32.257959-03
13416e7c-2433-4824-8c5e-09a0434547cf	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	3e19e069-02fc-448a-8e8d-8773fea67f01	TMM8J29	{"brand": "VW", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R18TP034097", "ownership_type": "PROPRIO"}	2026-05-07 14:53:55.098133-03
e7842b19-6460-4808-b692-08bf753fc15e	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	d58ba718-3983-4611-b757-4a84748f3470	Secretaria de Promoção Social - CONSELHO TUTELAR - CONSELHO TUTELAR - PLANTÃO	{"name": "CONSELHO TUTELAR - PLANTÃO", "department": "CONSELHO TUTELAR", "organization": "Secretaria de Promoção Social"}	2026-05-07 14:57:48.596842-03
d46d2318-bee2-4c5a-9d97-0c8845c998c4	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	d8a0948e-0c69-4193-877e-d0d81c97afe0	TMM2E09	{"brand": "VW", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R11TP034281", "ownership_type": "PROPRIO"}	2026-05-07 15:11:42.1261-03
625da205-4202-47dc-b017-8f7b5eb2861c	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	2dbdd1ef-e0fe-4b96-ad04-e89dec4f7159	GTN8C65	{"brand": "CHEVROLET", "model": "SPIN", "status": "ATIVO", "location": "Secretaria de Promoção Social - LAR SAGRADA FAMILIA - ABRIGO - ABRIGO", "vehicle_type": "SUV", "chassis_number": "01387925013", "ownership_type": "LOCADO"}	2026-05-07 15:39:00.781396-03
28ebd9c1-e348-475a-9684-554cea5089ed	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	VEHICLE	2d24caa9-0528-4a34-b542-fb139e4c25c8	TML-9I02	{"after": {"brand": "CHEVROLET", "model": "SPIN 1.8L AT LTZ", "plate": "TML-9I02", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SUV", "chassis_number": "9BGJC7520TB160917", "ownership_type": "PROPRIO"}, "before": {"brand": "CHEVROLET", "model": "SPIN 1.8L AT LTZ", "plate": "TML-9I02", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "9BGJC7520TB160917", "ownership_type": "PROPRIO"}, "reason": "Posto na categoria correta (SUV)"}	2026-05-07 10:56:01.765299-03
32b2ac5f-5de6-477e-9e0a-755371275034	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	USER_PASSWORD	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	itamar@pm.teixeiradefreitas.ba.gov.br	{"password_changed": true, "must_change_password": false}	2026-05-07 10:56:53.804264-03
e9a5bd0d-e6eb-4095-9529-cde515331258	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	c2fe8306-0ba0-4919-b47e-2dda9615434d	SGP2G74	{"brand": "FIAT", "model": "TORO", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "PICAPE", "chassis_number": "01304931797", "ownership_type": "PROPRIO"}	2026-05-07 11:00:44.953278-03
57e674c3-d452-4771-820d-655bf9bf19e2	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	1d4d26b6-f2bc-46c7-91ef-ed40112872a5	PKU2414	{"brand": "FIAT", "model": "PALIO", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "HATCH", "chassis_number": "01138904365", "ownership_type": "PROPRIO"}	2026-05-07 11:06:18.078955-03
b76eb5ca-7b29-4cb0-a38c-893015fe7c6e	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	2372e253-f9c6-42fa-bacc-c72736c42297	TMM3E51	{"brand": "HONDA", "model": "CG 160 STAR", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "MOTOCICLETA", "chassis_number": "01472261019", "ownership_type": "PROPRIO"}	2026-05-07 14:22:34.385635-03
53fedff9-154c-41a7-b614-83a119fa5a2c	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	4e889a19-42d1-4e8b-a0a9-a839f24c09bd	RPD5A72	{"brand": "FIAT", "model": "CRONOS", "status": "ATIVO", "location": "Secretaria de Promoção Social - Promoção Social - Promoção Social", "vehicle_type": "SEDAN", "chassis_number": "01298574673", "ownership_type": "PROPRIO"}	2026-05-07 14:30:13.773283-03
d2ad8894-9a4e-4220-9235-0380140b61d1	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	7ab1872f-4613-4be0-bcb4-7c3689d4c803	TMM0F05	{"brand": "HONDA", "model": "CG 160 START", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C2KC2500TR211969", "ownership_type": "PROPRIO"}	2026-05-07 14:44:51.841081-03
c9ebefdf-15ac-4bda-a20f-2f6767dfcbb0	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	25fec697-0605-4fed-82a9-63179025d466	TMM5A42	{"brand": "HONDA", "model": "CG 160 START", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C2KC2500TR211940", "ownership_type": "PROPRIO"}	2026-05-07 14:47:17.915212-03
6f43b0d3-813b-4084-a494-3c253e2f7e64	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	dc999c35-28b0-47a8-97d4-5b37cd7289ff	TMM2E14	{"brand": "HONDA", "model": "CG 160 START", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C2KC2500TR116960", "ownership_type": "PROPRIO"}	2026-05-07 14:48:43.921457-03
c449eead-f99b-4f45-8540-80a69dce2a3e	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	77b0f1ab-874e-4ddf-b2b2-6c5873c8906f	TMN8D21	{"brand": "CHEV", "model": "ONIX 10TAT HB", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BGEA48H0TG161821", "ownership_type": "PROPRIO"}	2026-05-07 15:02:34.564282-03
8d0f59bf-cabc-4a66-b736-70a1c1abfdf3	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	9cf59762-4171-4c1e-b552-4d7655935e6e	TMM7C41	{"brand": "VW", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R19TP032939", "ownership_type": "PROPRIO"}	2026-05-07 15:24:36.689852-03
49484b7a-3ab0-4268-9430-0e645ef9c7fc	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	123dc9e7-8bb6-4fbe-a632-31a95b0e181f	TMM0G98	{"brand": "VW", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R13TP033469", "ownership_type": "PROPRIO"}	2026-05-07 15:26:25.76447-03
6a9f54f6-1982-47ff-b1ae-736627e4a2a6	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	dfaa49c3-e78e-426e-b24c-242ac7f3a741	TMM-3I71	{"brand": "VOLSKWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R15TP034932", "ownership_type": "PROPRIO"}	2026-05-07 11:01:02.396441-03
01e284a1-ea39-450e-b54f-cdc84a44403c	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	97f709fb-1dea-413e-8a76-8d0dbc556dab	TMM6B13	{"brand": "VOLSKWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R18TP034195", "ownership_type": "PROPRIO"}	2026-05-07 11:07:33.821582-03
488efcb5-ef77-4eed-a7f4-07feb0c0c5d0	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	46010cc1-0a0e-4bf7-8742-92d343ebff01	OZU1063	{"brand": "FIAT", "model": "DOBLO", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "PERUA_SW", "chassis_number": "01035712218", "ownership_type": "PROPRIO"}	2026-05-07 11:21:45.125117-03
f34add20-22f9-4394-9b27-8e72e4b4b64a	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	7dffee07-fbfc-4ecd-a7fc-f3b39f9aea4a	TMM7H97	{"brand": "HONDA", "model": "CG 160 STAR", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "MOTOCICLETA", "chassis_number": "01472065880", "ownership_type": "PROPRIO"}	2026-05-07 14:21:41.817632-03
f9b8f79a-a960-4411-9f8c-2e7d7f2a2cc3	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	d4594709-2edd-49c0-9ef5-793fa00d0679	OZU 7466	{"brand": "HONDA", "model": "125 FAN ES", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "MOTOCICLETA", "chassis_number": "01035525051", "ownership_type": "PROPRIO"}	2026-05-07 14:28:00.103196-03
cf44fc43-837d-4ffb-a208-8b0fb564436b	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	e5aa8a51-6018-4eb8-948d-e66a5bd2b8e3	TMN7C57	{"brand": "CHEV", "model": "ONIX 10TAT HB", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BGEA48H0TG105080", "ownership_type": "PROPRIO"}	2026-05-07 14:38:12.65109-03
a3f5ad6f-fc7e-4e0f-988c-032d9709d8fe	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	01fe46d0-c29b-4c8c-ae9b-fd85e5eeeedd	TMM0B49	{"brand": "HONDA", "model": "CG 160 START", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C2KC2500TR117406", "ownership_type": "PROPRIO"}	2026-05-07 14:40:13.113543-03
98059f74-fb2a-47b9-ba85-a140c10bc390	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	974b6e91-8c98-44d4-84b8-0d49ce8833a3	TMM9F25	{"brand": "HONDA", "model": "CG 160 START", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C2KC2500TR211971", "ownership_type": "PROPRIO"}	2026-05-07 14:41:41.25006-03
17b137be-9016-443a-956f-0d4e7ebfc407	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	de1135a4-f534-40e7-b153-004e3f212742	TMM6I23	{"brand": "HONDA", "model": "CG 160 START", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C2KC2500TR211982", "ownership_type": "PROPRIO"}	2026-05-07 14:43:30.425049-03
9e22f59a-2e54-4683-bdc2-e94a53df31f6	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	44888801-13c0-4a70-8f0c-540b316ee675	TMM8I99	{"brand": "HONDA", "model": "CG 160 START", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C2KC2500TR116579", "ownership_type": "PROPRIO"}	2026-05-07 14:51:37.811235-03
47005522-30e6-47af-869d-294cddeba995	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	50072ae4-d280-4b9e-b2d1-b22090b6d2c5	TMM8I03	{"brand": "VW", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R13TP033245", "ownership_type": "PROPRIO"}	2026-05-07 15:16:34.342833-03
191d4b3c-218f-459f-8431-bc1102ae4877	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	097e3b6a-3a8d-45ff-91f4-999830e5da56	GTN8C49	{"brand": "CHEV", "model": "SPIN 18L AT PREMIER", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "9BGJP7520SB109004", "ownership_type": "PROPRIO"}	2026-05-07 15:27:59.269238-03
ce2db334-015d-4db5-b74b-cf7d2208ade6	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	87ccee58-1d57-44aa-8ed1-ac8b14aa15f4	PLE5284	{"brand": "CITROEN", "model": "AIRCROSD", "status": "ATIVO", "location": "Secretaria de Promoção Social - CONSELHO TUTELAR - CONSELHO TUTELAR - PLANTÃO", "vehicle_type": "SUV", "chassis_number": "01162005960", "ownership_type": "PROPRIO"}	2026-05-07 15:33:57.802027-03
034951bd-407d-4087-9cd0-8664a65410cd	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	6d4b0667-a7b5-4e90-9b2e-9fed98054048	TMQ8A63	{"brand": "RENAULT", "model": "MASTER TVAN", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "VAN", "chassis_number": "93YF62S00TJ512101", "ownership_type": "PROPRIO"}	2026-05-07 15:35:15.001318-03
0cd7934b-9f88-45c3-9134-502841e4b13d	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	5d9efb45-1c11-4cad-94d2-473f0f96ef10	Secretaria de Promoção Social - LAR SAGRADA FAMILIA - ABRIGO - ABRIGO	{"name": "ABRIGO", "department": "LAR SAGRADA FAMILIA - ABRIGO", "organization": "Secretaria de Promoção Social"}	2026-05-07 15:35:26.878402-03
d1c14896-8177-475d-aa94-91155e781957	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	9dde0e5f-b30d-4ea0-be4e-f962e56119e5	TMM-6A41	{"brand": "VOLSKWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R12TP034533", "ownership_type": "PROPRIO"}	2026-05-07 11:02:43.9266-03
51ab5733-a3b7-43d6-a21d-a9750a2f2d99	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	b676f18d-ad1f-4efd-a5c3-bcc49d3a67fc	PKU3846	{"brand": "FIAT", "model": "PALIO", "status": "ATIVO", "location": "Secretaria de Promoção Social - Promoção Social - Promoção Social", "vehicle_type": "HATCH", "chassis_number": "01138899035", "ownership_type": "PROPRIO"}	2026-05-07 11:07:43.658968-03
76e177ce-a972-4652-8c6b-77de9a13b2cd	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	VEHICLE	d0801dc5-3768-4cf8-86e8-555e47f382ad	PKU5629	{"after": {"brand": "FIAT", "model": "PALIO", "plate": "PKU5629", "status": "MANUTENCAO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "HATCH", "chassis_number": "01138904926", "ownership_type": "PROPRIO"}, "before": {"brand": "FIAT", "model": "PALIO", "plate": "PKU5629", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "HATCH", "chassis_number": "01138904926", "ownership_type": "PROPRIO"}, "reason": "Veiculo se encontra na oficina sem condições de uso"}	2026-05-07 11:22:36.066023-03
89598422-ccc3-44f8-b486-300e42b663a1	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	67549dd2-6f5f-4060-95d5-3e27cfb31d5e	OZU6658	{"brand": "FIAT", "model": "SIENA", "status": "ATIVO", "location": "Secretaria de Promoção Social - Promoção Social - Promoção Social", "vehicle_type": "SEDAN", "chassis_number": "01034595714", "ownership_type": "PROPRIO"}	2026-05-07 11:30:57.690671-03
acc45bd0-2895-44dd-874e-5a66d0597c52	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	7b3e5178-fdf9-41a8-ac1d-02f32e2c54f9	THF9F74	{"brand": "FIAT", "model": "STRADA", "status": "ATIVO", "location": "Secretaria de Promoção Social - Promoção Social - Promoção Social", "vehicle_type": "PICAPE", "chassis_number": "01455667908", "ownership_type": "PROPRIO"}	2026-05-07 11:34:38.806085-03
c1e675d2-b951-43f0-80c7-a45caf7859b2	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	c5251949-6a19-4d2c-9a83-0c6fe7baf1f8	TMM3G09	{"brand": "HONDA", "model": "CG 160 STAR", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "MOTOCICLETA", "chassis_number": "01471530458", "ownership_type": "PROPRIO"}	2026-05-07 11:42:31.0588-03
201d617c-1253-4054-9473-17df5bc9207c	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	dcdad9e1-ae16-47d3-90a2-364df75fd6fa	TMM7A65	{"brand": "HONDA", "model": "CG 160 STAR", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "MOTOCICLETA", "chassis_number": "01472259855", "ownership_type": "PROPRIO"}	2026-05-07 14:23:16.54674-03
7f8203fa-65c9-4062-96f4-83cc4871156b	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	d16fe3df-dd43-4615-8dfc-04353dc30558	OZU 7622	{"brand": "HONDA", "model": "125 FAN ES", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "MOTOCICLETA", "chassis_number": "01035522826", "ownership_type": "PROPRIO"}	2026-05-07 14:28:47.906688-03
e58d741f-8b9c-464b-be7d-4f124223991f	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	4eeb8891-d468-4299-8052-6204c49f8ad2	TML7G73	{"brand": "CHEV", "model": "SPIN 1.8L AT LTZ", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "SEDAN", "chassis_number": "9BGJC7520TB160794", "ownership_type": "PROPRIO"}	2026-05-07 14:35:17.772998-03
5469c9b5-bc58-4e39-85e4-9481eb2e2325	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	fe1bc612-43dc-4d32-a369-14ed863ba554	TMM3F62	{"brand": "VW", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT022808", "ownership_type": "PROPRIO"}	2026-05-07 15:23:07.728787-03
3384eefd-a2f4-4079-b21c-91a1a1ed8a44	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	1cc10a16-c05a-49f1-aa9a-e41dc75a71ab	TMO3G39	{"brand": "FIAT", "model": "STRADA ENDURAN CS13", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "PICAPE", "chassis_number": "9BD281AJPTYBD9435", "ownership_type": "PROPRIO"}	2026-05-07 11:04:40.866851-03
16273e06-2f45-4086-8006-aeae1c6f5cce	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	d0801dc5-3768-4cf8-86e8-555e47f382ad	PKU5629	{"brand": "FIAT", "model": "PALIO", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "HATCH", "chassis_number": "01138904926", "ownership_type": "PROPRIO"}	2026-05-07 11:09:43.427932-03
0e48205d-69c8-4640-9d4c-a632f4eac08a	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	3249dd16-34ba-4066-9849-22418cb73ab8	TMQ9A59	{"brand": "RENAULT", "model": "MASTER TVAN", "status": "ATIVO", "location": "Secretaria de Educação - Transporte Escolar - Transporte Escolar", "vehicle_type": "MICRO_ONIBUS", "chassis_number": "93YF62S02TJ512102", "ownership_type": "PROPRIO"}	2026-05-07 14:22:12.879101-03
5da0bb28-20f6-454e-bd85-8de726f4a71a	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	82edf23e-e3e9-4cce-9fbf-73b8666d99a4	OZU 0307	{"brand": "HONDA", "model": "125 FAN ES", "status": "ATIVO", "location": "Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia", "vehicle_type": "MOTOCICLETA", "chassis_number": "01035531140", "ownership_type": "PROPRIO"}	2026-05-07 14:27:09.347825-03
1f89930a-14e8-453c-a97b-760b6c66b3c9	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	5b0cb3e0-428f-40af-8cc8-eb21d3838416	TMM6I18	{"brand": "HONDA", "model": "CG 160 START", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "MOTOCICLETA", "chassis_number": "9C2KC2500TR211698", "ownership_type": "PROPRIO"}	2026-05-07 14:31:35.022112-03
5165dbd9-d7f0-43c4-bc18-7ae4331c85a5	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	3d193177-14e7-416a-89d0-dba0b85734ec	CONSELHO TUTELAR	{"name": "CONSELHO TUTELAR", "organization": "Secretaria de Promoção Social"}	2026-05-07 14:53:02.613383-03
c5d9965c-60a1-406a-8e76-150840df7373	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	VEHICLE	4e889a19-42d1-4e8b-a0a9-a839f24c09bd	RPD5A72	{"after": {"brand": "FIAT", "model": "CRONOS", "plate": "RPD5A72", "status": "ATIVO", "location": "Secretaria de Promoção Social - CONSELHO TUTELAR - CONSELHO TUTELAR - PLANTÃO", "vehicle_type": "SEDAN", "chassis_number": "01298574673", "ownership_type": "PROPRIO"}, "before": {"brand": "FIAT", "model": "CRONOS", "plate": "RPD5A72", "status": "ATIVO", "location": "Secretaria de Promoção Social - Promoção Social - Promoção Social", "vehicle_type": "SEDAN", "chassis_number": "01298574673", "ownership_type": "PROPRIO"}, "reason": "USO OBRIGATORIO EM PLANTÃO"}	2026-05-07 14:58:30.878173-03
0847fccb-4c42-4d3f-92a4-97b7ad4162bf	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	b964d75c-afae-4fb2-a1c9-974c41c2d995	TMN3C56	{"brand": "CHEV", "model": "ONIX 10TAT HB", "status": "ATIVO", "location": "Secretaria de Educação - Educação - Educação", "vehicle_type": "HATCH", "chassis_number": "9BGEA48H0TG124830", "ownership_type": "PROPRIO"}	2026-05-07 15:00:44.140793-03
96dddcdb-4b2a-49f0-ad80-4c632d57adea	4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	849fdd73-12fa-4941-8db7-adbf32f5af06	LAR SAGRADA FAMILIA - ABRIGO	{"name": "LAR SAGRADA FAMILIA - ABRIGO", "organization": "Secretaria de Promoção Social"}	2026-05-07 15:35:18.440527-03
\.


--
-- Data for Name: claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.claims (id, vehicle_id, driver_id, data_ocorrencia, tipo, descricao, local, boletim_ocorrencia, valor_estimado, status, justificativa_encerramento, anexos, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drivers (id, nome_completo, documento, contato, email, cnh_categoria, cnh_validade, ativo, created_at, updated_at) FROM stdin;
b4b082f2-acb0-4f50-8365-3c48e35f6dad	Carlos Souza	456.123.789-55	(11) 97777-6666	\N	C	\N	f	2026-04-10 20:43:50.711053-03	2026-04-13 08:58:10.318839-03
5eb82eb3-3485-459e-8d93-679403f0867f	Joao Silva	123.456.789-00	(11) 99999-8888	joao.silva@pmtf.local	B	2027-05-15	f	2026-04-10 20:43:50.711053-03	2026-04-13 08:58:12.613418-03
9acc4e58-e084-4089-9ec2-8dd99977870e	Maria Oliveira	987.654.321-00	(11) 98888-7777	maria.oliveira@pmtf.local	D	2026-12-06	f	2026-04-10 20:43:50.711053-03	2026-04-13 08:58:14.389156-03
ffd5a632-b7af-4c27-a220-7a03ab17f563	ARNALDO ROSA DOS SANTOS FILHO	06668082521	73999821745	arnaldo@pm.teixeiradefreitas.ba.gov.br	B	2034-04-10	t	2026-04-15 21:05:39.550156-03	2026-04-15 21:05:39.550156-03
9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	ITAMAR ALVES RODRIGUES	042.515.165-40	7399900-2142	itamar@pm.teixeiradefreitas.ba.gov.br	B	2032-02-10	t	2026-05-02 10:58:19.569898-03	2026-05-02 10:58:19.569898-03
\.


--
-- Data for Name: fines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fines (id, vehicle_id, driver_id, ticket_number, infraction_date, due_date, amount, description, location, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fleet_analytics_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fleet_analytics_snapshots (id, period_start, period_end, vehicle_id, driver_id, vehicle_type, scope, total_km, total_liters, fuel_cost, maintenance_cost, fines_cost, consumption_l_100km, tco_cost_per_km, driver_risk_score, anomalies_count, category_average_consumption, category_average_tco, market_benchmark_tco, extra_payload, notes, created_at) FROM stdin;
75cf75be-45f9-4e77-9409-34da578b3377	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
1d7b2105-3530-40de-a581-3180d6bd77f1	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
0f34636e-8cfc-4c63-9c76-4044de0b0c8f	2026-03-16 21:00:00-03	2026-04-15 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-15 21:03:18.268927-03
bf2230ba-8106-488a-8601-e56d7f698592	2026-03-16 21:00:00-03	2026-04-15 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-15 21:03:18.276705-03
7ae1e8e4-1766-42c2-9bc2-0526379ee1f8	2026-03-16 21:00:00-03	2026-04-15 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-15 21:03:18.275994-03
44773278-4c1e-45fb-8248-27c9cf6ec537	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
08f90517-df68-4889-b97a-dc9b42627eaf	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
cca4e6d8-d39f-4a6c-91ba-8816894d4581	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
3863a3c1-370b-4d41-9520-f645b10a58ac	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
345352e0-d2a1-4af9-be9f-05b9c88129e5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
2809755d-1993-495a-a4b4-000bb1d1ebb4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
d29dc00b-563b-4f6d-96ee-e595b5305b54	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
92a2449d-feea-4cfa-80b5-9f26922a0a82	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
57afe9ea-9c06-4b17-877e-a9b9282324db	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
3bad69d0-7544-46ab-8597-a69930c5abbb	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
a6801ea1-d9b5-42bb-8ecf-087e6d9113a8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
9e90e7ca-c24c-4b05-8831-68dc69bd31a3	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
3652e44a-2c01-460d-a704-2d3ac8aa8a33	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
4dbf1551-f507-4912-be6d-4d7b5dda9b37	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
99ad4653-3dd3-42c2-bf78-fefcf136ca1d	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-07 10:29:05.363074-03
6d987cf3-88a1-4d98-9d54-06db3eb920e9	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-07 10:29:05.363074-03
649f6434-d90c-4560-b1c0-174789752555	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 14:08:15.865908-03
a71e31fe-c34a-4ed4-a3cc-6b3f74070c65	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 14:08:15.865908-03
539eed48-2136-4065-b3ef-d1da7f85bd8c	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.551807-03
52a525bb-d2a8-4b54-97b6-ef49ac7c038e	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.551807-03
621327ec-94ac-4d17-9508-ea8378dd207a	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.551807-03
87ea25bf-8249-4e41-987a-f24c752935e5	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.551807-03
dc9f3015-5500-4ba2-be0d-6f80a495c242	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.551807-03
ed2ec384-02bf-45bf-a87a-80914bd85ffa	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-17 18:39:17.551807-03
7bc9c1ba-b921-4592-8a47-a6509b06983c	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.550556-03
d82fb851-9d4b-4213-b9b7-72a71e7f9228	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.550556-03
7bfdf03e-7199-4db6-b605-c6d306fd4b6f	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.550556-03
11de2c16-3ed1-404d-b0bb-b73a88abd312	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.550556-03
e02fc08e-1efc-459a-b460-e2edf966b0e2	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.550556-03
8fe93182-101c-40e9-b6c4-e72a82be9b09	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-17 18:39:17.550556-03
3d69dc20-a241-4261-a8f8-c8d1418e8a6a	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 14:08:15.865908-03
e7fd27e3-93e0-42f5-ba5d-0c15e0abb9c1	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 14:08:15.865908-03
ee64b254-4111-4594-9d60-464ee89ead35	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 14:08:15.865908-03
b3633013-10cb-4376-bb9b-e6190bdce266	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 14:08:15.865908-03
5226cefc-9338-4ed0-9b58-76541fb45127	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 14:08:15.865908-03
e7b91a26-a075-4ae1-a5de-961bb698ed5b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.363074-03
53db020c-41b4-449a-bd7f-f6d7753c6061	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
597fe91d-dfd9-4592-8a1c-dc3a6c0f86f5	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
10be06da-c3b5-48f0-b32a-472692abf85d	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
3bb84374-5423-4a13-9326-d7f7a1a2e5c8	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
43204523-1889-4f44-89ca-d50d93447e46	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
f48c0ece-3a2c-4af8-9d23-9e05c8c40944	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
8c9b06de-7d6d-4691-bc98-e1e173a7548b	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
079c5c4e-1dfe-4f3a-8d46-ae7cca87edf3	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
bc23e3a6-f8e0-4fc4-a6c3-4d87c798a799	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
ce68857e-0bac-4410-b7cf-5495b5654820	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-22 15:03:42.710849-03
576ae612-c8d3-4284-aca4-7ac747838ae0	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
c89e8bf1-5a2f-44d3-a1a8-3028858b4a21	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
1a460d45-2bc3-44a2-bfc8-db0dec64233b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
0805625c-db81-4595-bd37-e960a3040057	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
fe56c028-58d5-47c3-8a4b-234597b27757	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
afceba72-75bb-437b-8ce0-c48459d69a46	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.360272-03
a02cbad8-dca1-4abf-b368-6b605c657923	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.360272-03
8f03a34f-c7f4-45ef-a12c-a03b191d6324	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.360272-03
bf1ef6c3-a1cc-4833-bce8-ac5bf78cf2e8	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.360272-03
9be532c4-3d6e-4053-915e-ae5f7ab61a57	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.360272-03
218836b4-bc20-46be-bba9-77247b25fec6	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-18 08:15:44.360272-03
c5081ee4-e1c5-4b55-96c0-7aa75450159b	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.449114-03
5140d914-282f-4f48-9814-5edfab534aea	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.449114-03
b6bbcbe6-fbbf-478c-9d50-2a937341070e	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.449114-03
84ec71b0-90fd-421c-a34d-64783f5d4c9c	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.449114-03
8670f7f7-fdc7-494f-8283-5096f82378d5	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.449114-03
b19c3d97-b917-4dbb-afa2-f28cfc136500	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-18 08:15:44.449114-03
ad50a3bc-dcce-48b4-9be6-4da0c1ca1071	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
6a486c33-6034-4870-83c8-cb2084eca34b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
df65fa2f-5c79-49df-8458-b998ddca8213	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.328923-03
4b960de6-a6b3-4446-9fee-a6f25e7d7657	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.328923-03
e34e007c-9b51-4715-b3c9-fc158d138467	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.328923-03
64c28f82-4437-46be-bde6-e1ed59930427	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.328923-03
d4497ffa-9a32-4f86-9976-481fd2b4a754	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.328923-03
0da3b9f4-a0f0-452b-9424-66d64a24b5a8	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:45.328923-03
1e5087c1-e31e-4e35-b29a-ffa10a6497a1	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.330249-03
60e4fc3a-7848-4a90-968b-6e93e1a3005f	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.33511-03
65e73118-2ed8-40d3-8da4-19e1bbac1ba3	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.330249-03
9900e3c9-f30a-4f5e-bb9a-2445f4702593	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.33511-03
98962d19-bd15-4f02-83c8-f7a5aeedade5	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.330249-03
64048029-18eb-477b-be69-fea7b65d6c0f	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.33511-03
2f9e86a2-9ee2-484c-bac7-2c35fec20f5d	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.330249-03
6e3e3c60-6e6c-46c6-8053-0cab4dc74c45	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.356158-03
c41897b0-8ab6-492d-81e2-d8d7a6854b30	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.356158-03
0dcd960e-4c97-4337-a05f-73e002be5fd0	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.356158-03
e414d7fb-1a47-4dbd-b590-91c3c96b25a5	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.356158-03
ce52e458-2ebf-4a19-aaec-4d84192a8d36	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.356158-03
7f4c2166-0a4c-4987-9212-c54f7614e211	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:53.356158-03
95f79b53-1233-4ae2-985a-a38e5977e889	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.358162-03
77398e54-48cd-49dc-9cdd-47a4647ed7e6	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.358162-03
4b301747-2eab-4b93-9453-fdc14e15d4a7	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.358162-03
e89319c9-6a49-493a-8b38-35a5447dc8f0	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.358162-03
13b345a8-b925-4910-a621-9abeb025297a	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.358162-03
8d9888fb-459e-41f7-95af-1862d6a56d1e	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:53.358162-03
032f2c51-21c7-4824-9f82-301c31fe9c19	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.832852-03
5c85f98b-5cc2-4a22-8e94-e501739fe5b7	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.832852-03
c683612b-29f0-4115-8e0d-b6dcb92980d7	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.832852-03
f2ef3d61-e0b4-4b66-980d-39efab262bc1	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.832852-03
2d775360-7a0b-46e0-a3da-590640dd65c1	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.832852-03
1c823c6a-e44d-40fa-b269-a2a3aee07a1d	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.33511-03
a0fbaea6-aafa-4e13-afa9-7eb8c2bf120e	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.33511-03
a9613afa-35d0-4575-8e2c-f7f5e7f22867	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:45.33511-03
b793ec9b-58c9-45c5-aa3a-66064517fcde	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.363609-03
b4b61147-15ab-4afe-a66a-c17d03fea65b	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.363609-03
26c6129f-8829-446a-9898-6b54fd3bdf1c	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.363609-03
6fc77d43-2c58-4fb8-af15-0125ea5fbe16	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.363609-03
5aa22a8d-8be1-4f75-89df-e3e19f123abf	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.363609-03
3bfcba77-5ae9-4828-b0fa-39f6fe37272d	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:53.363609-03
7bd6decd-ad32-46fe-b212-313deec33b38	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.83366-03
b2bef32b-134a-4e5a-8f9d-968fc3c3b264	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.83366-03
3809cdc5-6271-412d-b185-2c620fa1d7c3	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.83366-03
2ac273e2-6cf0-4615-90eb-04cc4e77f136	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.83366-03
ee0c41d9-1e0d-4914-8e7f-a2ebc3087700	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.83366-03
f00c4c06-915c-4ba7-aaba-bcd82a2d4bf3	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:56.83366-03
c4bc5378-d3ae-49a4-836c-e8e5d753dcab	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
fe2fdc30-1bda-4969-a43a-41efda719eb3	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 19:34:18.962055-03
f8634058-53d5-4d0e-90a6-dae2c4ee9a6f	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 19:34:18.962055-03
5ef21b07-3265-4f34-a4df-431dbeaa8f41	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 19:34:18.962055-03
8554b1b5-4b76-4279-aeb8-7db9b7133f4d	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 19:34:18.962055-03
2e52667d-e26f-4e37-b24c-b19014a02bdc	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 19:34:18.962055-03
7f689732-0358-4392-983f-59d5ea35c5ce	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 19:34:18.962055-03
cc57cbae-cdf4-4766-bc6d-4ac8712a535d	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 14:08:15.865908-03
1229888a-e4c9-4e3e-be44-906cb8edc2a4	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-24 14:08:15.865908-03
ed1638bc-611c-4fee-8957-817fe1a2fa30	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
574b88e3-c238-4cee-9a5b-df4b1b47a841	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
e902cfdd-8bd3-4976-8343-eefe459c1e47	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
3fc857dc-e3fa-4fb5-ad8c-037ebe43fa90	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
698f33de-b7f7-45bc-b5b3-251c4c1ebd02	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
0bb9ccf2-8b48-4930-ad10-9a31c4fa3a65	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
148af87c-59f2-4a2e-9bfe-c16c3d621241	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
afc5ac06-e224-42b1-99dd-a179aa953ab6	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
8aa084d7-2c62-4715-8746-72103bd96d1b	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
ecb893b2-4d4c-4d7b-a066-442b0e67f541	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
b7794b0a-95a3-432d-b230-791787a6fdac	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
d7ed9184-5eaf-48dd-9f51-c59ed7795485	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
6872de68-9051-4a16-8f0e-5548414b77eb	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
25599c6a-4a84-4ba4-8c6d-b5fc5a9bf2da	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
e8ad9ac5-3a6e-4dab-8c3e-5da8487757e9	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
87aa118b-05d4-466e-adf0-ad48885446a9	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
b5b8a7eb-45a3-4ad0-9f9f-20e754e597da	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-03 16:44:58.054457-03
66b438a4-3a87-483d-b000-f1f4bd58c5b2	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-03 16:44:58.054457-03
079ab520-c9fc-4fb1-be73-86d9103cdfa3	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-03 16:44:58.054457-03
77e5deaa-94c1-4ddb-81db-3b58c751a4aa	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
8278ebc9-aaa7-4f7e-9e70-2de9154791b6	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.054457-03
d175fbcb-0487-40e9-88dd-f206d1d055f1	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-03 16:44:58.054457-03
927420ab-350c-4f2f-baa5-f45304905fd7	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-03 16:44:58.054457-03
6861c8a3-c0a3-401c-92a8-b2716af4a711	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.330249-03
8cb5e3c7-6bdd-4351-9beb-e885b30195c8	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:45.330249-03
8d8eb23a-1bcd-4f7d-8e1e-5ea7f9d6f8e2	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.364468-03
0d8303ab-38fc-4d46-a3c8-6614d41ed8a6	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.364468-03
5c6721da-09b3-4025-9df5-1d085b97d85a	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.364468-03
e3f067ca-2f5f-413e-86a2-de14de8fcc82	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.364468-03
78f8b19d-51c4-4b05-9bb1-be0ae5ec2ba4	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.364468-03
9d9cae04-d4c2-4743-9519-d7a95265f68d	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:53.364468-03
14708080-175d-4eec-b14d-8ea26c6618a3	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.053019-03
c8c4cb43-22af-452d-8304-4c59c712a9c9	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.053019-03
d5537fb6-c69c-4acf-b7d1-8cfa6a3d12c0	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.053019-03
d113665f-14e8-4eb0-9ab2-2e8ebb595d8f	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.053019-03
b57aa901-aee5-46e2-aae7-ec25fe6b9b21	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.053019-03
9e0e6261-bf4c-4105-ab00-8c225bd39ff7	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:44:00.053019-03
35d41d37-853a-4ea9-9f50-862fdc053ea3	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
ec5c92a6-1bbe-493b-9d7a-d706c181255e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
ed796a15-2c62-4420-b0fb-9b01243e28ee	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
db0a1b71-2e65-4e44-8b18-3a49c77b5b75	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
2bb9f469-e0a1-48ce-8367-1c0c9853360d	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
d97a614d-019b-4860-a3fc-86050be13298	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
7df0dbea-c206-4459-a95b-82ddfa58b36f	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
23b5b2ed-f486-4492-8ca5-1f78bf632d25	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
7327527d-ac12-4bd4-b995-9957a95917b0	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
5efdddab-944e-423f-b2c2-01b11b54efe4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
48a01cdd-102f-4adb-af83-8fb99ac5dad8	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
77fe4e49-b691-419d-9dbf-7b23b47647bc	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-22 15:03:42.703458-03
a53cb6a8-09de-4b4d-ba3a-c63552697520	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
95e49dd9-7ea4-4a09-9b76-b301c8809f0a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
d02456a1-7c91-46af-b19b-cb60af64f4c1	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
d1b85806-376b-4417-afe1-d8bff396ac4f	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
bf20874b-ea7c-4c67-b47e-cbe852b6b58a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
0a80971d-75a7-4503-abf2-1f6eb315b4ae	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
ced1bb7c-90c1-4c52-b7ea-a1ba9d16f939	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
3bc2bbb2-e8a0-4f07-8803-b3ab1761bee8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
eda1b7bb-555b-4aec-8b78-e8f65305bf98	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
e0e5c6a4-da40-4576-a0e9-57832f4cc03c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
1af54198-72dc-450d-a389-323eba4bace3	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
b4813954-918e-4a98-9817-d5e368c8953e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
7ea3459c-10cf-45b4-84b7-bc6fe4100f9b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
4faa81dd-845c-4d82-9bb8-1399f610e106	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-07 10:29:05.35355-03
4ea0998d-5c65-4844-bfe4-70d8d038ed65	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
4f867c47-2a59-4193-921c-27c3a0febf3b	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
20b86b8d-9fe8-4680-b765-2770915b3438	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
26a583e5-fff6-4f74-b3cb-5da7e8441bb3	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
8d475db8-39a5-4a0b-a90b-bb989393497e	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
b9f50d3e-9fb9-4a7b-a0d9-f91626b62280	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
a02fb431-832d-49fd-9318-9a5d9179be52	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
432dea7c-3b46-41c7-bb00-53393ad76986	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
623c05af-9eb0-431f-be36-2d22539b5b26	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-23 20:00:39.93517-03
a9d541bd-7be2-4742-bc88-c30e6498a2b8	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:56.832852-03
e8755715-3c96-48d1-92ab-78e06eac0f1b	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.837451-03
4800e259-cfef-4171-936c-b92ed6475929	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.836152-03
2387b91f-7fa4-4903-b61a-f739526209d5	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.837451-03
1defc4fd-7838-430e-88d1-4ba9a60d3762	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.836152-03
5ab2badf-4fc0-43cb-98e3-11b6c20cfcb4	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.837451-03
5c9b060c-e579-48bc-986e-b32be75f70e4	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.836152-03
ae3dbd1e-8626-4bf6-87a5-85cc8e8790ec	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.837451-03
d3b16cc8-c088-41f0-a7e7-525248e57d89	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.836152-03
aab7e201-fb20-4d28-8978-13a12dfb568c	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.837451-03
906f2727-79a0-40c9-8cfe-48740f01d443	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.836152-03
2de5e3c4-3ece-495f-9cfd-59c291a73cae	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:56.837451-03
32ecf7f8-6b33-424c-8066-aa96283119f7	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:56.836152-03
20798e99-8a65-459d-a97f-a37b4a957412	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
040ca3b7-2a06-4e17-a8b4-170e30376b60	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
26699ed2-c1b0-49b2-9360-e8db9f3ed246	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.048624-03
ab0b6ced-de1f-4063-b404-29323df73954	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.048624-03
bec6164a-2a01-45c0-be9c-3f0cf8d6a38e	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.048624-03
25a1a95d-10e3-425b-9c87-f1e764560ee4	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.049576-03
d8d1e481-64b7-4e02-8203-31bde84bcd7e	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.048624-03
ef7d2fa4-7b9d-47aa-9ec7-f511422e04b0	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.049576-03
852010f7-8ad1-46f1-aa9c-f6ed82f0a357	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.048624-03
a99c6367-fa55-44ee-a670-849ce555fa39	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.049576-03
885cef2f-f12b-4063-8321-b6d80a626afe	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:44:00.048624-03
23608e5c-6109-4523-b591-3cbaa0226393	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.049576-03
bffdf0c4-15ff-4a8b-97b1-66cbf3292bf5	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.049576-03
878bf35b-3892-428a-8d4d-fc3c2e08ed10	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:44:00.049576-03
363a6bb9-bdaf-42a6-bce1-c2f143697045	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
3e46066c-8784-49f8-8137-7a261beafcd1	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
98a3977c-301f-4e23-9421-874661e0be09	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
3a639658-aa82-424e-b358-3697edaf9516	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
5d322f93-5bff-4757-8cd2-9099d522b678	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
47e6266a-1400-43c6-9521-b9e3f5d4d4fb	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
b31c14de-fb51-4579-92ac-70cde5081acb	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
cf442035-a48d-4dd6-b78c-006a9f7e78ba	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
2acf776c-cb41-478e-b171-064f27fc5c8c	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
a4bd5dbd-42ed-4752-80e7-175148135727	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
9ed86da6-5396-47f3-97fb-8aaa2a6fa963	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
e741d1aa-8a9d-402a-bfd9-248e9c4b7f5e	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
bd7ea761-4191-45c4-87e4-9706590208a3	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
0bd0c09c-aeb0-46ba-ba60-f7d9804a3218	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
ec749373-c831-46f9-938e-0e90bfce5fa7	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
fdf8cfac-2220-45f4-9100-38f63d74eca2	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
cae1753f-f305-4bc8-a3a4-cab9c799b7d5	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-29 16:15:50.792817-03
6e9be3e9-d3a3-47e2-8b90-84a7ad430b63	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-29 16:15:50.792817-03
ea30bf56-c89d-4c44-bad1-a5006f3a46b8	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-04-29 16:15:50.792817-03
c8063908-44b1-419a-9f75-0c31b058771a	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-29 16:15:50.792817-03
896c67a6-fd19-4fb9-b02c-b2e5ad45726f	2026-03-29 21:00:00-03	2026-04-28 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-29 16:15:50.792817-03
f3b4d4b6-90da-453d-96b9-2e209af3fc63	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
f3f2595a-a6e8-4d31-b0d8-16840659fc99	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
7bbd3a9d-d794-497f-868c-101404e4d828	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
aff6a359-f013-498f-9ffc-82e1c976c600	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
ce4f00c1-cbaa-496f-a5a5-be0ebb267832	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
06ab1e22-f6b5-4eb6-bacf-4e5f7c2fce85	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
1c04219e-1fdc-49fb-8080-f653cc9cf109	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
8f76f252-df0a-456f-b4aa-d3190ae20e31	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
b2317cf0-cfc2-4b97-8eba-b88c1aff495a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
8872e1cb-b6f1-4f3c-9cbc-8acaddf79db8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
ea971bdc-f7b0-45ab-80a9-25f4aefa1aaf	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
f6a05bc1-bf47-4bcb-8917-de02530caa80	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
c4f9c93b-27cc-4ab9-bdb7-a2bf359d4dad	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
8c0ad4fc-569a-4133-afcd-391e21d0e0d3	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
a4cf8bc4-be9c-46ea-ab2d-b966e32a96d7	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
5eebd565-9d89-4a51-a743-4736f904a8f6	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-07 10:29:05.357042-03
aa83732c-06d6-4eb7-9683-9d100b4a48d8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-07 10:29:05.357042-03
27a0b7ff-0eb7-4163-b0bb-e5b115a27b3e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.357042-03
3b214ddd-341c-436a-b13e-f231c3bf1e8c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
f5ebea4f-6cfa-4987-bb7f-ce9066f525ef	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
2b9fa2b0-f320-48f4-b443-7847af998830	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
9d381b9e-b489-4deb-8945-fcaf0cc32e7f	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
04eb69d9-5ffc-46a9-884d-8eb8a232be2e	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
462a2e3c-8bc7-4780-b787-4e8530990dae	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
8a528fb6-56e0-43df-a0a7-dc31c17a2bf9	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
20f34462-1c6d-465d-a572-de39b39e4285	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
2279a220-cf54-43da-b1d8-fec5fc978ccd	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
080ed6b0-0973-40bc-bf12-58c6d70eeb8b	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
90446044-6790-4c55-9ee2-ac410c25d9ab	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
c894a808-0822-4d25-acc6-399c45a25fa0	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
914e8397-e7dc-4e78-b7f0-6b942b88a1ca	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
8bededd3-ca7b-4213-a2ba-ed69dc8a9d0b	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
367b1fed-adf3-4f81-b5b4-c1eea19d7a3a	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
e4f2b0ba-7ca8-4f69-a4fe-fae16ea4e2a5	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
dad78c75-ba5e-4fbc-93cc-eae0f08affa7	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
4db8b2d3-41c4-4308-8a48-a8485610ab0c	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
73ded7d7-79f9-4457-baa1-a08287734d8d	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
4f786e01-846e-4036-b4b3-a325fdea5ba6	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-30 15:36:11.654513-03
225967f4-5c10-4cb1-aa09-fa7bfb87bce4	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-30 15:36:11.654513-03
c7f33ecc-0d32-44b1-a8c3-98fffc46964e	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-04-30 15:36:11.654513-03
9072ecfa-72b5-4686-8c88-9e4554aff424	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.357042-03
06f4dcd3-c0e2-40d8-9a53-d09432025c1f	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.357042-03
1e72f908-f969-4ff1-a02f-6b7495aa310e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.357042-03
c2106f3c-808f-4559-8c27-07107aad5390	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
87feb0ca-35a6-45f4-af59-a7799944d0df	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
75bf5ce2-59ba-4cbd-9efb-f1ccd30a6ff8	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
efe51941-0404-4028-afb9-3719259f9054	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
1441c053-a4bb-4742-92de-73ec82c65aae	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
3a9320f9-2b01-45e5-bab1-59114fd434d5	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
4fe940bf-52d5-4d18-afd3-169b652937e1	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
e357306c-a361-4dcb-b0a5-96c6be9bd68f	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
979d99c8-0828-4de5-91e2-eebbd0143d6e	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.654513-03
af7b4603-9a42-4ac5-b950-94d0fc929718	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-30 15:36:11.654513-03
a727ea74-362d-43fc-a50d-e637a1d7745c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
b228f586-b729-4a2e-bfbb-f6254adbd1da	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
b43dd97b-dda4-42c8-9a00-7e1334712bd4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
287b9a31-a8ee-4830-a280-e49e8de31123	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
372bd4fa-711c-4981-b4b7-cbbf122961c6	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
49c4733c-bb63-4c68-81cd-fb796ae9fc80	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
3d6d9ba1-8c9f-4e34-9780-6786267c90b2	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
87a21835-e706-4f6e-8ef6-de8e3067552e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
4b1297fd-ba4d-4215-993e-21246aa6375b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
3674156b-c735-4fb9-81dd-e29754db3774	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-07 10:29:05.358317-03
fd7e2c67-c28b-4fb3-8def-22ef2e5d836c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-07 10:29:05.358317-03
11734192-0ada-4d59-9da9-59c1ed7b8fbb	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.358317-03
3d780f1d-7a25-4288-b7e7-f7df61c3c721	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
99655c33-1d79-4d68-8dee-9ac56ddfcecf	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
6f54f5c5-c3f5-48e4-8430-068db0ffadbe	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
e67cae06-2422-4da6-a8c6-2addb1c6b36f	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.358317-03
314ccf04-6a7f-4ac4-b09a-4ace7d453240	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.358317-03
b0b915b4-e9cd-472c-9068-3c158d9807a7	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.358317-03
f24d83d1-b9c0-4a1a-ba3b-162217df5543	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
33142796-edf4-4e21-bea1-657f4dd70119	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
7c00c570-11e1-44b5-89c0-9e6d6276d6c6	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
9001dc6f-c3e5-4d6c-9193-598ac94bea46	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
d1c48de2-4afb-4eff-afce-c45e5055b7e5	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
58389f22-c1b6-4d25-b685-92fb80cf7395	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
da21892e-1757-4891-ba7e-4f6591a90b06	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
b5e71e79-4310-4c13-9b56-2a9ef0df567f	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
add044b8-2346-4f72-a9f5-1a8900faef00	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
c837a6c8-9e4b-4c8a-8c0f-350e002f1519	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
65c57b57-7331-4b0f-8e64-2d8067a78a86	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
5ecfd758-7c3d-4542-a001-690a423e3c9d	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
1a29acd3-85bb-437f-a7f8-528b439fe0c7	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
666cd879-3f17-4485-acea-7a84e6fcb07b	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
a9421786-864a-4df1-8ade-03e1ca7db29f	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
c8ead376-0b2b-4ed2-adb3-a24b94f2148c	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
82ac3972-4832-4328-98ae-0e9b4537d091	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
aaf8f099-9f89-4d53-ae7e-7684c4c1e408	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
c18171fe-f92d-451a-a1f4-caea0ab0e029	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
5e6bb9d2-2fa0-4e11-b499-18e2e218bb81	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
894ee31d-dd0e-425b-9b6f-0a4d47dc4a5f	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-28 16:03:20.962146-03
11445d31-c4ff-475f-b0c3-7c676290ced6	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-28 16:03:20.962146-03
2a7e5599-b28e-487a-b8eb-611eeb9ab637	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-04-28 16:03:20.962146-03
4effff66-a6d2-4dd8-b724-44b8bc2e7600	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-28 16:03:20.962146-03
aa2e6135-1818-406b-b3ee-17eafc0c3c11	2026-03-28 21:00:00-03	2026-04-27 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-28 16:03:20.962146-03
62d12a60-5eb8-4bd3-80a2-bf8398ae87a8	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
f36da68d-9309-493e-9437-b1375289969d	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
9957f70e-fb14-4681-b1d0-074f5dc50a81	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
51968f21-0eef-4143-b87c-0eb699fbf8c2	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
b890b600-d01e-4657-84b6-63294572a111	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.358317-03
33567b10-05db-4e17-a7aa-709dc439c6c2	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.358317-03
46cff6fc-7d02-41b9-bb6a-36097e792e3b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
261cacae-8c40-48d9-921b-abec70ea8ed2	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
178421a0-6fe6-4fda-918e-5310b940bc24	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
093d4e31-0ebe-473b-a3f1-7987fbf2b2ad	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
f1c62769-0d16-4d8e-910e-110448c9b7ce	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
05076d48-715e-408d-af61-2d34b2de6ae4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
caa5ca02-25d5-4cfc-9ae0-ed012cd826fc	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.363074-03
a89242e8-5804-4e22-82ea-3a4417b4418c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.363074-03
378079bb-6365-4fab-9835-cfcb377a9c37	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.363074-03
5dcab17a-9144-435e-a751-2fbbc8890d60	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
219c210e-4e20-4176-8cd7-e01a40f7a8c8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
ddc1c262-5641-4bf8-8d84-c456f0e1ae92	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.363074-03
be5bde22-f010-49dc-9151-4d5c605e564b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.363074-03
0a0a6561-7ece-4765-86b3-eb7410d53356	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
1a646aba-b56b-4602-a509-e20a1f448212	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
ff5df131-073e-4614-bb91-403cb6e3902d	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
7758321f-494a-438b-bbbe-3deb5bb9d024	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
ea81d454-add8-41b8-839b-c70bd4d9ecb8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
a3da2b1e-0d79-4d31-a523-f0cbc385d76a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
a4febe4d-950e-466e-995a-d927e48750ac	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
e9a4df8d-c222-4463-90df-4e38b9604209	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
26ae74b2-4172-4c16-898a-4ec520c24ed9	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
c478014d-79d8-4b8f-a683-22fb8d7381d5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
d896e7ce-1435-4b6c-93a7-c5ebbc4b598f	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
5a9fa4a3-b468-4492-855a-8f1e7ceb4262	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.363074-03
a4e7958f-034f-4834-ab77-f8604c0416cf	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
3dae3353-6ca3-48c7-97a6-7984f3e51198	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.363074-03
c2267d1d-f8ee-471f-85aa-7d8c14eaded8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b137d4b0-9960-43a4-a9f8-916136fa73ee	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
a5181b73-d638-44b8-b086-aaed1471b9ae	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ec382e7b-22e2-41ca-9797-958ddf8128a3	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
b0829686-b7cb-41ab-91ca-09ace29c3240	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
dc31a942-d70d-4a13-a6fa-0c2a3b8ad163	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
5e719bc3-9bfc-455d-a2c7-279d66b83a2a	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
d5ad28b3-c570-4ab2-8061-a742007881e4	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
180cc735-708b-4415-966a-1de11f1e3a7b	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
9ceecfba-5b06-40eb-aec7-fbe2a9d90f63	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
c3a06170-49ac-43e0-a324-ad5d26330068	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
f4a35c9a-bf87-4339-b2ce-b12c6f7e51ee	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
49204156-9816-493e-8e0d-a78e8410d637	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
2d04cb11-e73b-4d21-a1ca-e0c247d8b227	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
ebf89f16-6918-41c4-a269-af0a52619890	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
9ce28b84-ce00-4275-8030-e576bfc1a84f	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
e9b7ff07-9605-499c-8a65-2524184c7450	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
ddfab6ff-ca3e-4cc0-a336-6118008e042e	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
da96565c-b7dd-49ca-8e24-f95eb24c240a	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
c2f82695-f502-42ee-9090-7e6ebb19c5eb	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
f125fc17-c352-4be6-97d1-b8f1bb850e3d	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
4029648d-3531-4895-a44b-e197289d95fa	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-30 15:36:11.684522-03
5c44ee47-cd16-4329-851b-614726612612	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-30 15:36:11.684522-03
3a71b8c9-cd93-4bc8-9864-d5619bf773cf	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-04-30 15:36:11.684522-03
50a20ae2-7297-404e-9d62-25338804cf6e	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.684522-03
06761443-5858-432a-a3a1-3808e110e9b5	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-30 15:36:11.684522-03
c30a3fb9-0e58-40fc-91c5-2b260a330131	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
6aac6d64-3fe3-46a7-a314-10531a924b35	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
ca8a9a82-d939-4647-bf30-a519eb873325	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
739a4872-b98f-4ac8-b938-cf8781d93cf9	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
c4fb0949-24fc-40b3-8992-038c19cc0eac	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c5e6bea5-1489-42f2-aa5c-0966007bcd9f	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.363074-03
534ca865-c922-472c-8a98-ccbdf4c5cc63	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	bc17f68a-a40e-4bcc-b044-c6efd267ad19	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.363074-03
40875891-4e7c-4afa-bed7-b00c6f68054f	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
b1055e4c-471d-4931-90b4-27327958513a	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
65033896-4f45-4956-b582-7b1e0c7b7526	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
61e35702-ecc2-4803-bf1d-23a7189fa369	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
a2ca246e-1cf4-4284-b539-b2ddc1a44469	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
d08198ce-7cc8-4110-a927-497bbddae7fc	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
f6743a07-379d-4934-a4dc-2ecfe6893df2	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
2c864a10-f98f-487e-b564-87d2dfa4567a	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
225a0c91-655b-4cd1-9634-5745506d94b6	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
b88b62df-c7db-430b-9d4d-cd68f4678f49	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
1da2e6b2-cfc3-43b9-b3e9-ce896940088c	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
e4a49643-00be-4e47-a13d-73e7e37b5e2c	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
3b7fdf6c-cdba-492d-b04d-4263efe5f349	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
019d4338-f34d-452b-8c20-529162613e3f	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
37d069df-2adb-496a-8e61-e0ad44ad0dcc	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
d48df4d3-9028-48df-a241-dc64eaef4c4a	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
ec6df2d5-dc72-4086-a313-9f4413c7b7f4	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-27 17:45:52.790322-03
62e3f0e4-14fe-49b3-afdb-59f16b827233	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-27 17:45:52.790322-03
0b1d5682-7892-4944-bb71-f801de596c77	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-04-27 17:45:52.790322-03
158a344d-5f24-411d-8b49-a1e5731a9c93	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-27 17:45:52.790322-03
20f6dfa2-915c-40b1-a8c9-f823e4f91db9	2026-03-27 21:00:00-03	2026-04-26 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-27 17:45:52.790322-03
42e1796f-8709-44e7-93f3-5872863b3f8b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-07 10:29:05.35355-03
b8dc191d-12ea-4e54-b2a1-2d624807d6d5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.35355-03
94f6f181-9d62-4f78-aac9-66222e358a6b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
67c42efb-5365-43df-83b3-b13593e1d2ee	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
a300da86-70cf-46c5-b0a3-e06a2a9787be	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
fa2b23c1-918a-4d76-b88c-fc4ba34f1fb1	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.35355-03
cddc6d85-cbe0-46b2-a72c-3a33592e7939	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.35355-03
a4fb1e7a-b810-4e4a-aa49-35b52654a07c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.35355-03
08e385df-0969-45df-8fc8-afd71482be7c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
aab87c5e-7152-4c93-badd-85e9d91b45d9	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
e140ec76-27fe-4805-a592-735e1eb8c617	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.35355-03
5c0638aa-aa6c-4a9d-b90b-b40734ac1814	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.35355-03
8a60f974-2531-490b-b058-8f0bfdb7a90b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
e74fdc1d-0615-4a1a-ae5c-0e450c38b935	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
354f1145-caaa-4393-96f8-da956aa17faf	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
4e75347d-0397-43f4-ab72-75b3b12598ea	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
8b0ecceb-1daf-42ea-8adb-177cb21a9da6	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
dc049d32-2ebc-4edb-81df-072300ded261	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
624136cf-d4b5-42be-8795-71cc252a0e0a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
18efcd3d-6549-49e7-b023-2ce6c341d670	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
ccf349e4-8e32-4f22-85eb-f87cad23b9fc	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
8b44fee2-a815-4a35-8b82-cddb26e162e5	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
3785dc49-d111-40d8-82e2-e4c27eabb479	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
f35c7402-d794-4140-a855-de5acb1f5f0e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
614177d4-dc4a-41bb-a231-cfd94c7008d7	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
6f9b5270-f2ff-43fc-8088-1553597d1dbd	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
48a193eb-e577-4e12-9fc7-9f0a86c5fc74	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
9077fa5f-e089-4b26-b347-6aa34ca56cbd	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
86fa24b2-c68b-4534-99c3-f38f5392fe17	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
9e04ce37-df7a-4498-90ca-ec1bcae34add	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
add6066e-874d-47b1-8046-7ed39acd3758	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
8b2bb585-a782-4075-8894-af7641680764	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
c967e9af-1ef2-466f-944a-9e834c61aca5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
45323eee-e443-4240-b873-067705115848	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.357042-03
45062b15-bcd0-4ef2-aebf-421a2bb20c50	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.357042-03
6f6cdd7b-de92-466d-b9f1-1497fd13e01c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
f1328daa-48a8-45bc-968b-db0d155a041a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
fdcdca93-53d7-4359-a6db-258ab99917be	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
c5385c69-4143-4df2-bef2-8af15e7aa8f4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
df6ebea5-1acf-45b8-b8c9-b35f90fa27da	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
ac993154-60ef-470c-8052-b4025ca97aa3	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
4f58415c-5be0-4e55-824d-29c0217ffa78	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
cf1fc529-0694-42d2-99cd-ab977f039ef5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
1bd54409-46af-4d26-a1c0-cc7fe5fdee88	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
328a9da8-8fba-4f53-9177-48ffaa4b611a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
cd590c19-8096-4222-ad39-b96e1a90444e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
c24022aa-7b36-4e3d-89f1-e958538ada82	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.357042-03
ed4bb36f-e8eb-4ed0-a313-1592e92fcf83	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
1a99afbe-9d56-449b-9b55-e733b6e1f13f	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.357042-03
8da7c6ab-74c3-4748-960c-f36357f66356	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b137d4b0-9960-43a4-a9f8-916136fa73ee	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
eb41f410-7c40-402c-aa31-8faebda4bf7b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ec382e7b-22e2-41ca-9797-958ddf8128a3	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
326ed1db-752a-4503-924a-3d14187a582b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c5e6bea5-1489-42f2-aa5c-0966007bcd9f	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.357042-03
6108fc36-4171-4f6b-bd71-97a6da04e7d0	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
db59d2ee-c36a-42c6-887c-ee47aad3f319	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
29672fa3-66c0-4694-b4a9-92dc6c3566c7	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-05 20:11:47.192696-03
817113d5-d9a8-40f1-99bf-7c4357bab99c	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
75bb09f9-e078-440a-b69f-ce4ea0bd030f	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
eb02b831-adfc-4a21-81c9-ff2beb553646	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
c8693bb9-4e2c-4613-9b37-6f481de088f8	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
9f9f4b39-d15e-496f-b8c1-4ae470c680f4	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
a9f1b24f-22e3-4022-872f-ddfd070012f0	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
3b8d0f3a-366d-4b08-b9ba-1fb13969cfda	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
71d76186-94f6-4211-a635-eede4a2bfc91	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
b3ec7db7-5289-42f7-8bdb-9b1db01aa1c7	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
c05fc47b-d776-47f3-a1a4-0067ae6f699e	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
3560ab33-2721-4375-87ac-4e46245710ca	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
a4337eaa-f5fc-410f-8d96-ea5989c70918	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
84aecf2a-f022-46f4-b297-7af329156004	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
690f177c-a937-4807-ad98-3f410bdf648f	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
4e939277-4712-4fdd-bcda-0fc0b293d28c	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
593931d6-57a6-424c-bb46-dcfeca055d3d	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
b7e6a959-690b-4eb5-93af-09b94584df64	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-04 15:50:33.397608-03
c4c82860-77e3-405e-bb28-877a1a3b9a5c	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-04 15:50:33.397608-03
68d58b0c-817d-4d51-859e-9d65b43755eb	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-04 15:50:33.397608-03
e4af763c-6334-413b-a326-9cb83fbe78d9	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
b503e98e-f5d4-4123-a359-0ed454f446ea	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-04 15:50:33.397608-03
0bf6ddc3-dc74-4d58-b4d5-5971b48ae7ee	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-04 15:50:33.397608-03
3bbdadeb-c586-4a8c-94cc-96842b3fb903	2026-04-03 21:00:00-03	2026-05-03 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-04 15:50:33.397608-03
157536cf-51af-444d-b5ef-5c7e396cbeee	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-05 20:11:47.192696-03
370c528a-4f45-4a5a-b8ff-7ad1625b213a	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.192696-03
ff8bd6d4-10a0-4599-b6b6-96458bf029fc	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
6884dec2-3ca9-42b4-bd09-3c73b3d201c1	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
ce42f19a-ebe6-44ac-85ff-c0c68e7b5b1c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	bc17f68a-a40e-4bcc-b044-c6efd267ad19	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.357042-03
52ca3113-b95d-4277-86ce-007647f4433e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	2bac086f-7650-4aed-a915-7c853a0e727a	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.357042-03
0a6f271b-6be3-4342-a81a-6345eab9db77	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
d95e3b17-66f4-4fe7-ad1d-e201c990731e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
d3e631a4-a3f0-45cf-b965-3549c9524614	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
a666b815-172b-4209-a1bc-fba096480008	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
9340a022-4991-4227-ae4a-675a0e6722a8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
24534e29-c820-4d23-af47-a08d04a62f65	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
1dee5965-70c8-4267-a6fd-ab96519272f5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
f3145e0b-5e8e-46a3-ba1c-280ec54d1de2	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
08dae20f-6931-4e50-a883-e3ded0f13cd1	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.358317-03
f42ee3c7-82b7-450c-a0af-02f44348deaf	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
e655e3f3-0422-4d1a-9d32-b219145b7ec5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.358317-03
53766785-ec04-45ff-9c3f-9bb275c8b7d0	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b137d4b0-9960-43a4-a9f8-916136fa73ee	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
6bd54255-a2cd-4a2e-bbc9-010b26f70c0a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ec382e7b-22e2-41ca-9797-958ddf8128a3	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
1be28393-38f1-4de0-9623-b6cbc8834d41	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c5e6bea5-1489-42f2-aa5c-0966007bcd9f	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.358317-03
11d9388b-bdf8-49eb-af3b-324234e72685	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	bc17f68a-a40e-4bcc-b044-c6efd267ad19	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.358317-03
3a015d42-894c-486a-92fc-a760b85fbb2a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	2bac086f-7650-4aed-a915-7c853a0e727a	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.358317-03
0780b575-8391-41a7-abdc-96a28102ab50	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8b48d4ef-cdad-4489-9af7-db977571ed88	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.358317-03
b4ad786e-8206-4211-be8d-06eda0de66dd	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	72b3a123-3335-476e-ade8-1cd2bf8e22d1	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
06720476-ef65-4c79-bf20-f1ec3f0c9439	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3b1d50ae-23f6-4a17-bf6a-f39752f95697	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.358317-03
362da111-c8ce-48fc-a12d-4303cd94659f	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	585dc2bb-c774-486a-8ad2-b12544d3d7d0	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.358317-03
14c1e74b-ff8d-4117-a353-94b342387c56	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	62ed0519-240d-4611-9cb9-b8003be5b369	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
62acfa5c-2790-49df-ba30-8be3a933c726	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	d758d9ab-084a-42e8-a474-f85ef8109ea6	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.358317-03
8d439def-1410-4f7a-b189-0830b1173b14	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	25226f6b-6acc-4356-96f9-c3cd85b994b8	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
5068b9d2-a832-4457-9ca7-502396774375	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	befb7af5-986b-4685-bbd8-de53b159bfef	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
14ea5389-2593-45f0-87cb-3f79c54e7bac	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	4b8d5b8c-53e5-4662-9725-12e633182843	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
27626d5a-f41f-483f-9361-c9e0279017a8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b166fa01-6228-45a8-87ba-4575978ee8cf	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
4c58c7f2-9dd6-4897-b136-632dd553b765	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ec530224-b28d-4883-8109-093950bd2650	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
ce036dbb-0be6-4fb1-9c31-b594da4deb62	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	4f6d1058-ebbd-4f81-96a0-ccdc19c9ed05	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
d879099e-82be-4dc5-acee-838761f6c87a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	a54306d3-6b90-4c2a-9844-bebce0a32854	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
2571a64d-c1b2-448e-9335-b3d972417077	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9d5d671d-9fd5-4fcd-a27a-c4d91704fbe6	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.358317-03
f1504fd8-75ff-4497-9f5a-a0a1a9c5257c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	53afecc8-8b0c-4372-9dc4-86e87d4d7aee	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
c89253aa-0b6a-4c54-a772-180e53d17991	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c4bb98ae-b770-4303-80f2-6c969f85c205	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
51cc08eb-e722-426a-9fef-e32d2ddd59fb	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	020650d7-65e4-4a3f-8086-b81627409e93	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.358317-03
a506d34c-6364-4fc5-a623-42ec312d16ec	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3e5c4e1d-f72d-4146-bf05-78918e6093ee	\N	VAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.3	\N	\N	2026-05-07 10:29:05.358317-03
833d97d8-92bc-4bfe-9302-5d25f5ce1a00	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	e5ce2035-52de-4439-b2ff-946b14b16fc9	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.358317-03
1ef028d2-f38b-432a-adbb-c88f961af543	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	52a0395e-da68-421f-885a-5a56cb279965	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
61774432-5ec0-47c4-b608-6e8074fedfd4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b626cbb5-9afe-41ba-a091-1c51af0c347f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.358317-03
da3f966a-ab8e-4ef5-8fcd-a8e341891900	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	162ac9f5-14ed-4f2b-bdc5-356f108312ef	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.358317-03
c7aaa986-e399-4595-be7f-9512d451f3e2	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b01d4bc2-26b0-485a-ae91-e03f3de9af8e	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.358317-03
975b6096-da19-4d90-af2b-e449adb04a90	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-07 10:29:05.358317-03
69a979cc-f39a-4b04-bf83-92af18db2202	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	befb7af5-986b-4685-bbd8-de53b159bfef	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
7060d162-1f46-4955-97f9-d4465eb23ec0	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-07 10:29:05.358317-03
698f09d1-216e-4e4b-8198-4d42c7701e23	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	4b8d5b8c-53e5-4662-9725-12e633182843	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
1ced051c-44dd-4235-9568-4a558bd68d29	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b166fa01-6228-45a8-87ba-4575978ee8cf	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
d80bfd4b-dd2b-4160-8892-2c7689bfdf49	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ec530224-b28d-4883-8109-093950bd2650	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
8e6a14a6-b289-4061-b133-c8a3a166dac1	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
49cb8999-e679-451b-994a-c18c7aa087d9	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
343719f9-e5d6-4fed-b44e-05965e19e34b	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
3cdafdc3-71f1-4af0-b4fb-945932972534	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
2e014445-58a0-4736-af2a-9e9cf589615b	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
c87fbbe7-5e7b-483d-90b9-d8b16289d5a9	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
b8392cc2-ba6b-458d-a341-9cb3dfc43931	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
7051beee-8848-4a15-a2cf-478ab574c368	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
4a0bc0ea-bcb5-4d94-8fae-872b15a348ec	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
daca7b9a-2131-4b38-9e6e-77d40764d487	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
27f8b654-d144-44ed-ad5a-39041f696b5f	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
6b2b5798-faaa-4b33-8a4e-77c5bc9a5c9f	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
70ab06ff-b95b-4287-8387-901d3c55703a	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
acfeaa92-17c0-467c-9735-6e5446a49367	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
73f4bdf6-6c61-466e-a824-ef653d4cf97a	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
3a17ca56-7059-47f3-8ebc-3724b4661e67	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
5505e4a6-5140-4953-956c-08f997c9abf1	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-03 16:44:58.055336-03
697e716d-65c3-40d1-8c02-ade7575023eb	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-03 16:44:58.055336-03
f8677a9f-07ac-4f2a-bf19-2efbe392ef63	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-03 16:44:58.055336-03
83446a0e-9ac7-4d72-8351-5857f45d3b2a	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
fe01faed-9f53-4ba5-8279-b3a09071b935	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-03 16:44:58.055336-03
978606ed-8831-49ea-8443-b3f17c772b62	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-03 16:44:58.055336-03
668e7a6b-4ee8-437f-9d1b-63d953754dc3	2026-04-02 21:00:00-03	2026-05-02 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-03 16:44:58.055336-03
70088a41-2835-4b34-8d21-9984d07eca64	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
29a8a629-2ef5-4086-8581-a724fb404b2e	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
f9c493e5-6639-422a-9bda-1aed01d1570c	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
0c03c9af-73f4-4ac8-8b02-02f8048a0db4	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
c5accc61-e47c-48e0-9700-7ea88a5844f1	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
76b6bd0a-9a97-4111-8be6-617bb3a9524d	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
f43163c8-5713-43c7-9ce9-a04e734fa357	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
7bca7f65-277b-4ce1-9dcf-cd1f158b8258	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
1d5a973e-abe6-4563-ade8-05a47f02539e	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
4b786454-04bd-4ff6-ade6-1429641c251f	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-30 15:36:11.653645-03
b77c5847-4297-4d58-aba0-f91f532b7e6d	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-04-30 15:36:11.653645-03
50845d87-179d-455a-bcda-88932cd8fbf4	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-04-30 15:36:11.653645-03
1123f837-13ab-447d-aa26-0271e6e676dc	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-30 15:36:11.653645-03
6e9ce10f-d390-4dec-b3e7-d7e49307bba6	2026-03-30 21:00:00-03	2026-04-29 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-30 15:36:11.653645-03
a9d425b9-1b2d-4875-9f07-28262a30436c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
0406e060-04aa-4475-9080-76ab187a27c9	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
6f00ed39-b84c-4648-9d65-41b8b9b0cb6d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
db7a7244-b961-465e-b491-da72321d77f6	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
e5be3cb5-3589-4b39-bb8f-32ca7f67f238	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
a142fef1-aa84-42df-80b2-b7bc6a7eea9d	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
fe98fae8-cce9-41d4-9035-88fb69657956	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
7eb70310-1666-4a14-b11e-e20570e7efaf	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
53ffa3f1-f2a3-41b3-a8ec-73e3c727f960	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
eb927d2b-0697-4a78-b45d-81141130b40e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
b64dcefe-5040-4527-a955-0f56e926374b	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
edab9026-6eec-4d20-ab49-519f92a74a68	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
cb68f2f2-c5d5-406d-9d03-258349041426	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
6b2548ea-2fdd-43a4-bc76-1d728c01d9ce	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
51c766f0-91ee-46e0-a36c-5f719c7d34e2	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
7f7b0a3b-ec5b-4e89-aa4c-a8eb6efd8dad	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
d58a9346-1f22-4bd5-b47f-1b6658bfd1e6	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
16d50614-a4b5-4478-9aa7-852e439d1373	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
958e6da1-7107-4bc1-89f1-4095ac2a3fb3	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
25ec84d9-e32f-40b7-b05a-088658a6cb9a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
2fb758ec-b478-4c3c-9e1f-e3777015e2f7	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
705c93b0-06b4-47fc-bf25-28df12525d52	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
d387a352-f92e-4476-a634-7db4e20e57fc	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
b96203f6-2a54-4600-9486-d6094e8cb2c8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
ed5e0d9f-8c9a-4830-8880-6cc684acd9d7	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
dc761a2d-d89d-449d-999a-28fc0fddabde	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
50078fe5-e5bc-4bac-acba-6f8bf28ca438	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
4691d97b-58de-4b55-a9aa-8b91ef77f8fc	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
0b2fba9b-2c53-4df0-9892-fdebc97b8a35	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
13ed418f-689e-4167-9f79-9176ab3543a8	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
308c15e7-d674-446a-9936-c5c5e1bfb211	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
289e4406-5c27-4f74-a310-b1bbd01f2ba5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
5faa8d73-e83a-45c3-bd8a-f50b20cdeb30	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
5cf0143a-f2e0-45b5-9f27-d62181f7dc59	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-07 10:29:05.454462-03
e6d7a9a6-2644-4239-bbe8-f9d2a62c31e7	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-07 10:29:05.454462-03
a7a88bac-3b70-492e-b7fb-818123ab9b8f	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.454462-03
6c917250-739c-4ff0-8271-e8deaf5e821e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
ecea3d1b-5980-4817-85db-13a1d3867ce2	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
e93ce992-ffc9-43c4-bc7b-bd8e083f9d78	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
770c5f98-d300-4a36-8dc3-286c08df7648	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.454462-03
bd0b7f87-2f66-40e6-ac48-3d5e619802b2	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.454462-03
c577542e-a7af-4e27-b2b7-0aa84c4d252a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.454462-03
5faae058-f7ee-4c0d-808b-731984fcf017	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
545e99c9-0ac8-48d6-b752-73890205d3e7	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
28c7bec2-e8dc-428a-8515-c995e800dadf	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
77a95e22-89f5-4226-a4ca-7e5b88280ac7	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
01ca20ca-f34e-423d-aef5-efe13c16fc5a	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
c8334c0e-97a6-4bf3-9616-5cd0e3a24eee	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
1fa0ed45-4dbf-45e1-a1e3-d0b3fc6e82bc	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
a0b7bc9b-2bab-473c-bdff-d798d8e95bdb	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
9e35a9ae-c65f-4422-9556-4bad20e490ce	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
66017f9a-6cd3-4e1c-b979-74a6c698629f	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
44c0504f-bdcd-49d0-892f-373ad4e14f45	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
159ef527-539a-46d9-9f82-0c4d29c4277c	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
9c4c1ade-b688-498c-87b0-834d2f1fd7ac	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
b924b471-7bdb-46ba-8829-3d1226bff98f	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
80872576-372f-4f98-8a04-f1e438b2a5bb	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-06 09:26:25.2454-03
68bd56ee-f5d5-4b79-a64d-4c3f828367fc	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
7096d91f-6953-42fb-b2c8-42b6a9b9f3aa	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-06 09:26:25.293228-03
186e92c0-d1b8-4022-98c0-fd781278d53d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-06 09:26:25.2454-03
d5cbbf85-f9e2-4ca4-bb5c-ad0aab7aa393	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
c24da4ed-84db-4719-92c8-93a4f6d90bce	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-06 09:26:25.255514-03
f1d17402-4234-45de-b842-f2c59c53243a	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-06 09:26:25.293228-03
09bf822d-389d-46ae-b0e2-27cea8fe0207	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.2454-03
6e79f852-e544-4d80-ae16-10d4d3f502e9	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-06 09:26:25.255514-03
33a224c7-963f-4060-a8c9-c0cf81452e9d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
bb4d6ad6-fc4b-4d32-b5a8-b4740cdef693	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
db2939c3-fefb-4948-9322-37b1207c7fd3	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-05 20:11:47.192696-03
ff8bba49-aef5-4c57-8adb-f1a07d1b677f	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-05 20:11:47.192696-03
1e867f3f-29ee-4343-bc2d-c7d36d0a14ff	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-05 20:11:47.192696-03
46799624-5315-4a58-94d4-8d3dd1f390e9	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
e80fa856-a4a5-4527-adbf-98c11806f589	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.192696-03
b358f513-9b1f-4a9a-8b2c-5997e5b8a7cd	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.192696-03
74b64a8a-a059-4c49-9733-430f96cf97cf	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.454462-03
1a7b8f55-fd4a-471b-8a78-be885051f7df	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.454462-03
3d751191-4fb8-4476-864d-8bf5bcbe0d50	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	2bac086f-7650-4aed-a915-7c853a0e727a	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.363074-03
af00b852-4bf2-40d0-ae28-3694ff74c7c6	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8b48d4ef-cdad-4489-9af7-db977571ed88	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.363074-03
f7ca6ff2-a4ad-4a95-83f1-ab17d3bae4b9	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	72b3a123-3335-476e-ade8-1cd2bf8e22d1	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
945230ab-41eb-4d2f-bdd2-2404e9b2f4ff	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3b1d50ae-23f6-4a17-bf6a-f39752f95697	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.363074-03
b3ba542f-2de4-4656-8c85-cfe0ec3ffe21	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	585dc2bb-c774-486a-8ad2-b12544d3d7d0	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.363074-03
cff7fa84-a7ce-46ff-85d7-adb5090c3b28	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	62ed0519-240d-4611-9cb9-b8003be5b369	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
6a955d0a-9e78-4411-a5d3-8326cd97251a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	d758d9ab-084a-42e8-a474-f85ef8109ea6	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.363074-03
02979bb3-642d-41c5-91a6-e9d24d173e7b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	25226f6b-6acc-4356-96f9-c3cd85b994b8	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
b1df4cfb-ebcf-420a-ace6-17f51f858671	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	befb7af5-986b-4685-bbd8-de53b159bfef	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
f5dafc62-01a0-4848-ab4f-d4822a4c2c62	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	4b8d5b8c-53e5-4662-9725-12e633182843	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
39b7d7eb-9c07-4911-b73b-c87ca4d2e7c4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b166fa01-6228-45a8-87ba-4575978ee8cf	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
187beb09-84f8-4fb9-8d17-3ccf64d1af43	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ec530224-b28d-4883-8109-093950bd2650	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
b8a44634-c99d-4ec5-b206-744a8c90547a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	4f6d1058-ebbd-4f81-96a0-ccdc19c9ed05	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
c1de96bb-fb9c-45a3-a0c6-681c421ed398	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	a54306d3-6b90-4c2a-9844-bebce0a32854	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
8dcce2bb-d58a-4a82-85c0-7f8bb27d7ee6	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9d5d671d-9fd5-4fcd-a27a-c4d91704fbe6	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.363074-03
77a97486-e25c-4aa8-9bb2-a36f452a2e7a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	53afecc8-8b0c-4372-9dc4-86e87d4d7aee	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
688c11a7-5fcd-43a1-ab72-e552ebfd05e5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c4bb98ae-b770-4303-80f2-6c969f85c205	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
4a7bd945-17f3-45ca-8ada-375fad41d303	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	020650d7-65e4-4a3f-8086-b81627409e93	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.363074-03
4301acdf-bc7e-4fb2-a1ce-b6a12dfa7382	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3e5c4e1d-f72d-4146-bf05-78918e6093ee	\N	VAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.3	\N	\N	2026-05-07 10:29:05.363074-03
f0a7ef99-704a-4c38-82ed-2f05420507ec	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	e5ce2035-52de-4439-b2ff-946b14b16fc9	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.363074-03
b6634f1f-ff6f-40f7-9ae5-7515ac1ecc90	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	52a0395e-da68-421f-885a-5a56cb279965	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
b5b51b00-71fc-4a11-821d-0139d6dbdd3b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b626cbb5-9afe-41ba-a091-1c51af0c347f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.363074-03
ff8acd5a-d967-40f6-b94b-e268cbdf7a36	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	162ac9f5-14ed-4f2b-bdc5-356f108312ef	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.363074-03
c8e00301-3828-42de-8ab3-dc95a4a0b4af	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b01d4bc2-26b0-485a-ae91-e03f3de9af8e	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.363074-03
07106a99-0bed-4ab7-8677-6f5e272218ab	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-07 10:29:05.363074-03
dfa13c02-4466-4609-8600-f3ef3352c727	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-07 10:29:05.363074-03
320af094-49f3-4bba-800b-07748afa1a17	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	4f6d1058-ebbd-4f81-96a0-ccdc19c9ed05	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
e043b276-676b-4ac2-9483-af0913b51a8c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	a54306d3-6b90-4c2a-9844-bebce0a32854	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
c097adde-39f9-40e4-a585-e6ea6dd06b8b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9d5d671d-9fd5-4fcd-a27a-c4d91704fbe6	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.454462-03
4fb59c51-233d-4a3c-a6ee-c15033821d41	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	53afecc8-8b0c-4372-9dc4-86e87d4d7aee	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
5481b60e-82f4-4e8c-b068-5fdcf04d4237	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c4bb98ae-b770-4303-80f2-6c969f85c205	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
0af91645-0b02-414c-b2b8-9acd8b471f9e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	020650d7-65e4-4a3f-8086-b81627409e93	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.454462-03
5810d974-4727-4a1b-853c-c42066bb8077	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3e5c4e1d-f72d-4146-bf05-78918e6093ee	\N	VAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.3	\N	\N	2026-05-07 10:29:05.454462-03
cdd0a1c7-c7fe-4c31-b0f3-f70187766619	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	e5ce2035-52de-4439-b2ff-946b14b16fc9	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.454462-03
a44851fb-4748-4e68-ae28-8c2a6ca8e153	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	52a0395e-da68-421f-885a-5a56cb279965	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
7f44bf1e-cfe6-4e2a-8cd1-a150e18a477d	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b626cbb5-9afe-41ba-a091-1c51af0c347f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
baa347e5-e1be-46f2-baef-6d9d9db07c77	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	162ac9f5-14ed-4f2b-bdc5-356f108312ef	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
88b22a38-77d2-4b76-8a23-e5a54e6c4da5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b01d4bc2-26b0-485a-ae91-e03f3de9af8e	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.454462-03
db19f84b-6f51-412c-b01f-c52c71541666	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
33425f98-3931-4961-bab5-4769080221ad	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
34b0daaa-3909-4b46-981d-92d6ba08f98b	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
90006936-44be-4f7b-a724-a082bc792c58	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
7dbaefc9-eb47-4241-98c7-1a2574a6faa8	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-06 09:26:25.255514-03
13155133-2cd4-4981-9843-d451ed58b7ab	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-06 09:26:25.255514-03
4fdd7dc9-a131-4748-af42-a03bf964b0a6	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.255514-03
ea2c13bb-0ae8-46db-aa81-007f49438eb1	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
96ff402a-277f-4d99-834e-5f0c5569919e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
9e4aacc0-66d0-4951-a89d-6c232f1b267f	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
78b81451-c394-4ca3-8f45-4345e0a7ea33	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
88f0a737-e765-4761-bfb2-ae66748cfa8e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
93202b3f-dc6d-4745-b7ee-86a9d711287e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
4908c90d-a5da-4393-b626-8d6b03475414	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
8c31f3cc-78f1-436d-8176-a0ba74d595a8	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
ed0e84c2-d836-49e7-8bec-393fb7dc5251	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
7d2be03d-43d7-463d-b15e-00341d33ac42	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
35fc7d47-b7a4-4563-9c53-78101d3af903	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
73d42600-6046-4c84-9765-7f08c9e11a6a	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
3e6d0a9d-a80e-430b-8057-a86fbeb01046	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-05 20:11:47.173394-03
65f0bc09-761b-4503-bc4b-ea493303ba4e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-05 20:11:47.173394-03
d6d9f3dc-bbb6-4c6e-b838-32768d375ad7	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.173394-03
d5ce136a-145b-42a0-98f8-507318d28001	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
95fe0cd3-2d84-472c-9ee4-43ba9bc8907a	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
bfdd4068-f809-4fb1-8f8e-324c494d1f50	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
c86a829e-c7e3-4132-97eb-472176424aef	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-05 20:11:47.173394-03
2442fe46-2d3a-4d81-885c-d3e69c13389d	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-05 20:11:47.173394-03
1604e5b2-064c-436d-9159-d26426a81582	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-05 20:11:47.173394-03
fefd8a30-2ddf-48bc-9f81-20c7017c18cd	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
25a4f040-9bb4-4327-9784-eec760a54a87	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.173394-03
f72d0a74-ec2f-49db-8b57-a228cadbcc51	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.173394-03
b8bc8358-19a4-4dcd-829c-c0b97734177b	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.173394-03
15291b8a-3cdd-493c-97fd-ebb779571f69	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
e3f5ec7a-769f-4af6-a105-b5004d1a2096	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
c6e345f5-5196-4858-9a4a-be46b8ebd3a9	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
a5d00127-e902-4e91-8067-812086b14649	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
8b48a840-0c43-4c5e-9f74-638881f47413	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
16997cbc-d8a1-41cc-8459-de529cd59efc	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
ffc9526c-c359-4440-bc5d-6087bfe23cba	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
b841bdb8-7183-4f42-a65c-0c7238d0d126	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
70e5d9ac-711b-4f13-ad49-f67998c90d67	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
807ff3c7-8646-40b0-b6d5-3200c7c140e9	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
e4125978-e005-4b36-a75d-eef19a1f9b58	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
847a1159-f893-4424-a8d4-231ace20917b	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.173394-03
002ac03b-087d-4cd8-979e-d986c90b5fc2	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.173394-03
7b360647-9da2-4817-87c0-996777b6bd5e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-05 20:11:47.173394-03
d0ac3ce9-273a-499e-b6d9-9ace8db34313	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-05 20:11:47.173394-03
c9aced8f-abb5-4c79-97c6-8f985a9cdc15	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-05 20:11:47.173394-03
c301c407-f409-4ad2-86d0-290e6bf7d3cb	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.192696-03
82b68075-0360-4f64-aff4-1332fe5173f8	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
2e99e57f-03f4-4e96-bd25-4125ab259d2c	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
940a13f5-2b9a-49b8-b178-d8c9784bbb20	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
3569ac69-7ea4-4050-9f7e-c1dbd32a5be8	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
1828caa4-a7e0-4f62-b593-305336543304	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
a456e588-9af3-4f5a-a93a-7e00d1b960cb	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
b251e708-c5b9-4f7b-8041-62bcd379f1db	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
498b7a18-bad3-4211-9d53-151babce4b7c	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
5f85bfd8-1c5c-4905-9b54-6499f21d315b	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
780b9bb5-e0ef-4af7-8283-e2a41561faa8	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
d8742b5f-f9f9-4f7a-ab91-89530d7958e3	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
3f7095e2-5e38-4e1d-8c88-fee16ab4be63	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.192696-03
307b1442-834b-4a28-bb6b-b19661260bd5	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.192696-03
1ee32ad1-c8fe-4d30-8a9b-87505dc1284b	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-05 20:11:47.192696-03
cbf3e2f8-c913-4a9b-9d1b-9c82c2139cfb	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-05 20:11:47.192696-03
46f3d8fd-8462-4c49-a62a-72a08ca2ced3	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
85d8265e-a28e-47ae-a0c9-e01aa82fd36d	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
4f00ba1a-451a-4932-bd47-d83bf04fcaa1	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
5e1ba0d8-5beb-40e2-a3d5-4b3ce191d386	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
564668a3-def7-4180-8757-71149b13e00f	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
5077b6db-e557-4688-aeff-d7923e066306	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
68536977-b222-4e7b-9175-25c76bec4355	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
2b2b3db5-beb2-4360-b1cb-364dea5daa8f	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
317a5e1a-d4bb-4ea7-a74f-9d0c84133c2b	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
d054546b-4a07-4531-946e-12a02ebffe41	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
14c5e7de-8bc2-4114-95c1-927d02e7a882	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
84a6acd4-4724-4f62-8188-6459ac0e6a2d	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
0705a95f-8de3-47e4-9133-b8a0869b9fa8	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
4840a6f9-1b98-4861-9b34-8f6484a87188	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
7496d050-44e4-413a-ad38-5a121c55dcce	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
799d3de1-e4cb-46ae-8fb7-1313d2e0fe42	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-05 20:11:47.191021-03
b2c6f9d6-e29a-4e84-846d-976739f21d0e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-05 20:11:47.191021-03
48cd5d7f-dc12-4192-86c4-b7a993956f2d	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.191021-03
09af9971-6259-46da-b430-37807d7afa37	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
686f65ca-ec0c-4327-b743-5df633b67f36	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
71734f6b-4d29-42d6-8c97-6441ecb9a415	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
084ca05a-f2d5-4872-a384-f85555204174	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-05 20:11:47.191021-03
3ebfbf08-0142-4d1c-9042-a86abefb942f	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-05 20:11:47.191021-03
68155979-5530-445f-b634-1bbe9bf054b1	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-05 20:11:47.191021-03
1ce67f98-f959-4250-8e12-fabb7bb287ce	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
ad5f5f96-5102-44ce-88ef-e0d4504420c9	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.191021-03
e54b4abc-a139-4877-9a46-134aa4fff3db	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.191021-03
fbbf3cf9-a1df-472a-9045-a5ab6850f328	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.191021-03
7c02602c-9341-472d-b1df-95e6c10692ad	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
020c9008-068d-4638-8c2e-b5ccc01a9cb7	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
ed86bab8-8489-43d3-bf7d-c1b36a565c6d	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
43e0a48b-2f32-4048-8228-36dc26fb525a	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
f373b761-c902-4a0b-abda-2b21d4519740	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
7ccf17fc-d09b-4b2b-8254-a470d9eb7636	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
7c2a5d4f-0f0a-460a-91ac-876c77b596af	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
52895746-972f-4850-b3a4-fd4221c7befa	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
c4cfc171-312d-4474-9085-5b449de24845	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
ba5a7240-2c90-4853-ace8-29d9a00a743e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
4a489ab3-efa7-4981-b03b-b0c9effbd74f	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
a578c445-3a58-458a-a7e9-9fd1fbdae98e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.191021-03
6d60a754-a848-4f51-827f-ccf40f2383fb	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.191021-03
f3a4dde3-86ce-476c-ad80-6a0ffc5076d6	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-05 20:11:47.191021-03
1bef7a7c-b780-40dc-8c90-43e64af15b91	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-05 20:11:47.191021-03
86595a2c-283a-40c4-b374-b80d96583a72	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-05 20:11:47.191021-03
af051002-591a-45e7-a656-9a33081ce444	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-05 20:11:47.192696-03
a318b0af-5597-43e0-b418-69466fab35e3	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
8a5dcf29-ada3-4c79-9ba6-c0f10bf6bab5	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
380506fb-a061-4147-bc5c-6ea23f5d335a	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
55df65da-e51f-421b-9ff3-c79688c05c0c	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
d6972aa9-76a6-470f-a9d3-531f61fd4d37	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
e0064b24-0aa8-4446-a323-ea65d67a2d9d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
68abcf25-18ae-4dfc-ba5c-3fd93b8c2a0d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
f6765782-83d8-424b-9c8f-9011b9e1b69d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
f1be9005-7859-4c2a-bdec-71cd5684b8cc	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
130f6c7c-ead5-4a82-a14a-63726033d6bc	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
a7d6b550-4b8b-49df-b663-01ec24026015	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
2df3db74-2633-49ca-b3c4-f36a15fcc1ef	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
2797ec55-d3b3-43fa-a2ce-16a967acf5b8	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
cd0a1f0f-3cec-4bd6-bbed-af154673f1ff	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
d0711228-0ab6-4485-a3ef-baded6e9a086	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
31301f83-5768-4365-97e3-a1683a771cbc	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
b7730257-2a17-42c4-a3b4-afc59aea943e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
39f13e52-92e5-47c3-a758-116f21fd6066	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
d1e1d705-76e8-41dc-9332-3c9accec1cf9	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-05 20:11:47.210811-03
8c97f0f1-1425-4b4f-9fb0-7775486bcfbe	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-05 20:11:47.210811-03
7d7c2641-f4e2-4722-95a4-563c2301c6b7	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.210811-03
ec9eb9d0-16ae-4405-81ac-ad801c74509b	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
9b6b0958-74f1-4076-b17a-84c1b2a7407e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
8e53cb34-f30f-49a0-9e0a-d5a855343cdb	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
2da52df6-a06f-47d7-8fa2-a96fbe00f37c	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-05 20:11:47.210811-03
75861fce-a3fe-4771-b717-00fc60b8ce49	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-05 20:11:47.210811-03
0e169a0e-1a2c-4262-afaf-2c200613699f	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-05 20:11:47.210811-03
9bc9093f-6ef8-455d-8b59-8a0a2052f0b8	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
e3914819-43af-4576-a4ba-9d1b25609c31	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-05 20:11:47.210811-03
435fc0d2-adc0-421a-92d7-ee66883041c4	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.210811-03
5ffd810d-fc9e-478d-9fac-3332da5d01aa	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.210811-03
e0a4631c-c4af-4560-adf7-03efac83128a	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
9ad877a4-ac17-403f-8588-85d160625625	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
4168f6f3-b1b7-4560-a05e-7e5da8aee351	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
946c5b81-0b12-4eed-aa59-66f3bf6dddd8	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
777bc0d3-7d41-4e6a-ae33-73711e4d0c7f	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
4997cf18-8058-44f0-b22f-823997dfbc5d	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
5d03db1b-ff1d-4a90-b8f4-c326d7b0d59e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
d1d41d52-1b87-4ab9-a7e6-e4f100039202	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
42bca3a2-ae31-448d-a1be-82994e7bf3b9	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
97bd1159-1d81-4334-b541-d43c7bdd838e	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
f967cc1c-413e-4b0e-afd9-895738b5cbe0	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
23b06ca8-ba7a-4b9c-a95b-b66ab50f6efb	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-05 20:11:47.210811-03
c2867c83-c7cd-4141-9eed-d091a4df8a22	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-05 20:11:47.210811-03
dfd02bfe-a580-40d2-952e-af6f6101a6e8	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-05 20:11:47.210811-03
d774b15b-6d7a-4550-a7c4-fe6489663faf	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-05 20:11:47.210811-03
540cb812-f055-4301-87ae-92be73f81142	2026-04-04 21:00:00-03	2026-05-04 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-05 20:11:47.210811-03
4fa8e92a-7755-4032-8fd8-bb51861b119c	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
4a6e13c1-f0f2-4df2-bba6-99cc371676cb	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
4bc0fd40-9e32-46d6-ac29-e712353fcf5b	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
cffcf41c-fe73-47f8-8e93-602339870c24	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
e66e10e5-78b3-4dce-9c4d-c063655b91dd	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
9e7ac9e2-6370-4eae-afc0-904f39317c20	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
ccf2a9d0-eec3-4a81-8af9-7b4283837820	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
b7240fa3-8e73-4247-884c-2ca6fc1d1beb	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
ff9798ea-525f-4d83-83e1-84455e193f93	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
db18a2bf-567e-4107-9d44-56a22bfdcd60	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
78befc0a-1250-4311-832e-07f1d6960d88	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
aef93698-1205-45e6-9c2d-a22f453b6aa4	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
74c355d9-c240-445a-92e1-ba3e69a69122	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
b6f8f743-7510-4290-9790-8e6e63499c52	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.293228-03
b0dad2a4-90ee-45d8-80a7-ae40b061ea6b	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
842eeff3-2df6-4e14-ab0c-a907be495256	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
872f6d1b-b48b-4bc2-b8ce-4c903c61fbb4	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
8e00469b-6728-4798-b00a-0c1416b5b43f	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-06 09:26:25.293228-03
ae622ea5-dab7-4841-9d10-6eab171648b6	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-06 09:26:25.293228-03
477b32a6-700f-4ca1-9511-277969e1aaae	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-06 09:26:25.293228-03
ae44b7b9-b6f9-40af-8d73-0e7765cca8f4	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
15bfdd95-ee84-4f0e-a611-c3dab96c2cb1	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.293228-03
c37fdeba-2be5-4520-ae40-8e0edb141109	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.293228-03
efd5606b-0a1b-423c-8eb6-295563752d45	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.293228-03
84324642-4674-4a6e-85bb-ea39f59f48ec	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
05e32319-c596-48d3-9dae-ddf173c330b3	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
58b6b2cd-6e24-4711-8b5f-c53db4c9cf2a	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
9e4e05e4-143e-4df8-809e-10986b02e98b	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
58581f35-9933-4ba7-8f72-5d5ef7df7e5d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
1a88729d-b0ed-4454-ad05-b2e6918aeee0	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
6e6ad1b7-800d-4900-94ec-b399c946cf0e	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
936ba568-9702-48ff-8559-d04848ac7637	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
bd30260e-6062-4c3b-8c39-3905a4164d84	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
acdeae83-1814-451d-8f83-b8c06cd44ef5	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
0f23a714-79b7-4236-b8a7-4d93dc3c5d74	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
fed28328-d357-4ac4-843a-c5d88a728834	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.293228-03
d057ea25-4e1b-49d9-9c07-8043b99e90a1	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.293228-03
a2f29a2f-df0f-4412-9a88-9b0dcc37459f	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-06 09:26:25.293228-03
7e765778-0e12-42ea-9c93-ab433ebfb351	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-06 09:26:25.293228-03
6c352c62-0686-4b6a-8aa9-224a6d1e843a	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-06 09:26:25.293228-03
6855bffa-76d4-4f33-b2b8-9a4c3b0aa853	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
ccf209dc-5a4a-4071-bca0-a22e32e97e38	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
3328e7a0-7500-401b-bcbf-3b9b1d8d09a4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.35355-03
8594c437-7cdf-433f-b8dd-03b8e483b78e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
7398f281-7ba5-4144-a867-bd53c3d5f8b5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.35355-03
dc4d47d1-4f10-4f58-bb4a-7430ff3f1068	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b137d4b0-9960-43a4-a9f8-916136fa73ee	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
0cedcd0c-22af-4392-9358-1f11b7016d76	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ec382e7b-22e2-41ca-9797-958ddf8128a3	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
5f3e97ff-3153-4096-bd5d-be27b54bf7fe	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c5e6bea5-1489-42f2-aa5c-0966007bcd9f	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.35355-03
55a00641-6780-4c7a-8dbe-8dce46fb3ee0	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	bc17f68a-a40e-4bcc-b044-c6efd267ad19	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.35355-03
d6cfe5eb-173c-44c5-92b8-c745eba48acd	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	2bac086f-7650-4aed-a915-7c853a0e727a	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.35355-03
f89fa8da-24a7-405e-bc95-a78486686211	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8b48d4ef-cdad-4489-9af7-db977571ed88	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.35355-03
d9bf7206-2483-49c1-921d-0468e6c80a8c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	72b3a123-3335-476e-ade8-1cd2bf8e22d1	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
3aab830f-5a96-4e19-bf20-efc758778f4b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3b1d50ae-23f6-4a17-bf6a-f39752f95697	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.35355-03
23bcc738-d691-409d-9b9d-aec2152b7b64	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	585dc2bb-c774-486a-8ad2-b12544d3d7d0	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.35355-03
7e1c288b-d1d1-4d19-8563-d44586dae5d6	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	62ed0519-240d-4611-9cb9-b8003be5b369	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
74872977-6756-4870-bd61-571fc4d34759	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	d758d9ab-084a-42e8-a474-f85ef8109ea6	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.35355-03
af5c4d1b-5b65-4da7-875b-3c89aab26600	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	25226f6b-6acc-4356-96f9-c3cd85b994b8	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
d8f4464d-6b0b-4c3d-a1f7-19d5c80adac4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	befb7af5-986b-4685-bbd8-de53b159bfef	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
44902ff3-eec1-46b1-827c-1f7f452293f4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	4b8d5b8c-53e5-4662-9725-12e633182843	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
c9808331-79a5-4d2c-a1a5-c7debbc8b912	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b166fa01-6228-45a8-87ba-4575978ee8cf	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
3a800c6a-37c5-4ab8-b1eb-4445f7ad9142	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ec530224-b28d-4883-8109-093950bd2650	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
ad34b341-0e64-44d9-96a3-4e4cd4450c28	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	4f6d1058-ebbd-4f81-96a0-ccdc19c9ed05	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
24d3d6b1-281d-4822-ad92-7ffc9d65ac13	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	a54306d3-6b90-4c2a-9844-bebce0a32854	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
533490c0-795b-4e39-b1a4-e5045948c189	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9d5d671d-9fd5-4fcd-a27a-c4d91704fbe6	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.35355-03
42fd1dac-f375-47d3-8a96-cc1382282e9f	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	53afecc8-8b0c-4372-9dc4-86e87d4d7aee	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
3a94fee1-f9fe-4a14-a27e-e060a41125b9	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-06 09:26:25.255514-03
566c196f-85f3-416b-8ef5-cb623d5dc8bc	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
7efcaa49-f6c6-4c5c-8745-7c3d9e86fca2	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.255514-03
ba681765-c03d-415a-a0a4-26479871a1b7	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.255514-03
3a8381da-6bc3-4075-af25-00459d78fdd0	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.255514-03
805f39c6-e937-43b1-a30e-e84983eb9378	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
1b7767e0-4020-423f-8fdf-6eff0691f6f7	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
d3e1045c-d8c7-44ca-8788-06b5a6aa147d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
193b3c8a-19ac-4fac-a380-55935f8d981f	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
20f0ad23-2116-404f-98b6-b089f2b9b8ab	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
86ee803e-1a1a-4d55-9fd2-8b0494281aec	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
699eb36e-c04f-4a0f-9f05-b32a57079c09	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
b3f4e2d0-5567-4996-b647-df5df44a2771	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
2bd32b18-49d4-4af5-a817-92c009f108cd	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
2d91f368-e297-46be-b78b-f659d6b8881f	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
9c0ab624-0034-477f-90ad-696b1cf8398c	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
a1e12c1f-9378-4dfd-8ccd-190a1a9bb4d1	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.255514-03
47e66913-7b8b-4d24-bced-3c53059b4cf1	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.255514-03
e50c9cf8-628c-4f72-9e3f-83e74a7cf94d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-06 09:26:25.255514-03
03ae924b-b665-46c7-8619-d576107b1643	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-06 09:26:25.255514-03
f5da43bb-4ce0-485b-9dd7-98ccdf87bee5	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-06 09:26:25.255514-03
bfa08b9e-668a-4e39-a3e3-d529b6861e36	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8b48d4ef-cdad-4489-9af7-db977571ed88	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.357042-03
0588e45a-040a-4300-b431-aefbd4596ee4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	72b3a123-3335-476e-ade8-1cd2bf8e22d1	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
22f78d6d-1b79-4ef4-9a08-b879cd1151db	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3b1d50ae-23f6-4a17-bf6a-f39752f95697	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.357042-03
9f65c19b-f0ea-4831-a3b8-085b518b0c59	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	585dc2bb-c774-486a-8ad2-b12544d3d7d0	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.357042-03
54672e40-5df7-4b18-ab6e-4a050282b238	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	62ed0519-240d-4611-9cb9-b8003be5b369	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
e17a1cca-1d4c-428e-8048-570484d578df	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	d758d9ab-084a-42e8-a474-f85ef8109ea6	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.357042-03
5ee23033-b628-4153-8998-70c352320efc	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	25226f6b-6acc-4356-96f9-c3cd85b994b8	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
48d90521-6c72-4af0-9ccd-096525210690	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	befb7af5-986b-4685-bbd8-de53b159bfef	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
797a9725-f7cd-47bb-8af9-9a5d5f6b334a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	4b8d5b8c-53e5-4662-9725-12e633182843	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
6d94b382-d4d2-4f51-ad9c-6db28aeb3426	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b166fa01-6228-45a8-87ba-4575978ee8cf	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
1f8f05d4-fcfa-47ca-aad9-d9dc9040cf34	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ec530224-b28d-4883-8109-093950bd2650	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
25a21c72-ca8c-47b2-a0b8-a4993860904c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	4f6d1058-ebbd-4f81-96a0-ccdc19c9ed05	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
0523327b-e5c8-455a-83b8-020fa2b8f1e0	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	a54306d3-6b90-4c2a-9844-bebce0a32854	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
bddc965f-d275-481d-996b-9b0a9fc36bc6	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9d5d671d-9fd5-4fcd-a27a-c4d91704fbe6	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-07 10:29:05.357042-03
a95ea7a0-3247-4558-b4cb-415a975b0ae4	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	53afecc8-8b0c-4372-9dc4-86e87d4d7aee	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
d46af9f2-afa8-4bc3-add7-e4c25edddc15	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c4bb98ae-b770-4303-80f2-6c969f85c205	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
34aa7ac8-d03f-4e14-825e-152913602c10	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	020650d7-65e4-4a3f-8086-b81627409e93	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.357042-03
50f4844c-7cb8-4b78-b4f9-f17e55e35b10	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3e5c4e1d-f72d-4146-bf05-78918e6093ee	\N	VAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.3	\N	\N	2026-05-07 10:29:05.357042-03
2e97befb-f0d6-4d61-9f42-4a9451972c06	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	e5ce2035-52de-4439-b2ff-946b14b16fc9	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.357042-03
23901bb4-04e6-436f-98c6-1431bef9f1de	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	52a0395e-da68-421f-885a-5a56cb279965	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
f9eb69e0-6e33-4523-bc3e-6eae0cd4691c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b626cbb5-9afe-41ba-a091-1c51af0c347f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.357042-03
b3b64a39-481c-4eed-85f4-1528d9f4837a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	162ac9f5-14ed-4f2b-bdc5-356f108312ef	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.357042-03
34f2e13d-343f-402c-95ee-da06f5b29192	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b01d4bc2-26b0-485a-ae91-e03f3de9af8e	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.357042-03
a2c1a8fd-c50a-4701-92f5-8f457cebe7dc	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-07 10:29:05.357042-03
080912b8-5a96-4551-8374-6841ccf6894f	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-07 10:29:05.357042-03
8417ff56-a77c-4038-8e1f-496cdf96be02	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-07 10:29:05.454462-03
94d66e63-5635-43f1-945f-6c8cb2d9dd92	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-07 10:29:05.454462-03
0f750523-93f3-432d-9b7e-1bd86bf97459	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
d2a5bde8-9a95-4dea-8ab9-0edfb82bcb13	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
51c69044-eb62-4e97-a702-be989ad40d1c	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
c94f7687-2fff-45d1-a94b-502c3ab20fb2	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-06 09:26:25.2454-03
a7f1f75c-a79f-4824-bbed-58ae0b9a2523	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-06 09:26:25.2454-03
6d4482c7-4183-48bf-9388-57535e04842c	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-06 09:26:25.2454-03
c5e8c8db-72c9-4fbf-a702-d9cee2d8369d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
16171254-aa93-449d-8d32-9bef636add1e	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.2454-03
61adb277-9f9a-4f45-a2ef-57f8fea11b8c	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.2454-03
230fee01-a364-4ef9-8a77-345b73053e59	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.2454-03
5bbe996f-731c-4fba-9759-1815f3aa0ac6	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
904ea04a-1788-4907-b72b-47805d361a37	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
9cf4dd17-e9b8-47df-96f6-9aa9a3a933b1	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
f55a1c5f-0c05-4d00-869a-1460958391d6	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
b3541fd0-034a-4683-83f5-1083c2c5f119	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
c6c1c80d-5721-4a44-91f1-d13bebaeab39	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
a2c3aa1b-0a14-450f-93ad-e0b54675d081	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
592b43a2-c4c0-4157-a697-43c25acf76a4	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
a74652d7-2969-4de7-a7e7-4813b3706f6d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
0d461c3a-1567-4d84-b27b-a89eff12447c	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
b39d00be-56ef-48d2-a394-52093edc5295	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
56f2c10a-95b8-4a7c-bb7a-1cd6608be1e0	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.2454-03
95846dd7-767d-438d-8ddb-9e2329496f57	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.2454-03
80c371b6-740d-4256-a239-ba5c6db89e96	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-06 09:26:25.2454-03
53e5f1bc-644a-487d-96be-77ae597e5a41	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-06 09:26:25.2454-03
4b888302-87e3-450b-be1a-96075ac99a61	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-06 09:26:25.2454-03
8cac2eb7-d3d5-4eaf-8646-25ea3d467293	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
f9f35352-a1c6-4d73-bbd8-358969896581	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
8000c7e8-00ae-416e-8464-0f51e1aaad31	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
8ec29f3d-9dba-4cac-9910-26233cf39078	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
09628af3-0f57-48c7-a26e-f5d30a0d9a5b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
6bf402a2-1218-4890-955a-ae1e7d95e57d	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
6773104c-89f8-44a7-8700-e8ae72a0db0d	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
c6a2dda0-75d5-4168-a359-d470349af879	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
728f2a41-0a64-4900-a279-046f0df6eb71	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
23aef3b5-cdc2-4f9c-9ae3-2ca31e468363	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
c6c44340-a01d-4cd4-85f3-39b88b98c9ab	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
931e97f2-7e18-450a-8e17-61a15903415b	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.454462-03
3e020f42-a0f2-4663-aa25-9941ca4861d3	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
a780272d-ee18-4894-ae2e-7b0b0965f356	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.454462-03
b6fbbe6a-cc80-4f2c-9270-65e1384c5b66	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b137d4b0-9960-43a4-a9f8-916136fa73ee	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
cd9ebba1-6a2d-4570-a005-de2daea664bc	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	ec382e7b-22e2-41ca-9797-958ddf8128a3	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.454462-03
6d045f35-82aa-4503-9154-fc540d6d8b50	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c5e6bea5-1489-42f2-aa5c-0966007bcd9f	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.454462-03
a7d51ce1-a3a5-41e2-a7dd-f362fa7af8e5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	bc17f68a-a40e-4bcc-b044-c6efd267ad19	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.454462-03
3f2ddf00-7926-4a6f-b117-8bab737e3c17	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	2bac086f-7650-4aed-a915-7c853a0e727a	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.454462-03
4d6d3fb3-589c-449f-9252-5198c9e70a44	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	8b48d4ef-cdad-4489-9af7-db977571ed88	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.454462-03
6c33febc-cc06-4db9-ad7f-ca46d4e81edd	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	72b3a123-3335-476e-ade8-1cd2bf8e22d1	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
d1662b34-767e-49e8-8aec-705d308b68aa	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3b1d50ae-23f6-4a17-bf6a-f39752f95697	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.454462-03
3145785b-458d-4606-a842-0a989ad6fe1e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	585dc2bb-c774-486a-8ad2-b12544d3d7d0	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-07 10:29:05.454462-03
44d26f4c-7e9a-470f-8a24-1c3be7d94f14	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	62ed0519-240d-4611-9cb9-b8003be5b369	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
efae80bd-3c4e-45f9-b8b7-204ae9430d4e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	d758d9ab-084a-42e8-a474-f85ef8109ea6	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-07 10:29:05.454462-03
3312b3f7-e2c5-4946-b835-8a990145075d	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	25226f6b-6acc-4356-96f9-c3cd85b994b8	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.454462-03
5f593892-19d2-477c-8f28-8793ec2c5e72	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
6a68c27e-30f2-4605-93a8-a8875e8df9b6	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
3406193f-2753-4db7-badb-cfe2fc7685d7	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9c952d6a-cc65-4519-ac6c-369c7c59005a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
259b3b87-c50d-4847-ba4a-782ad7675021	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
a71240eb-268c-4885-a029-03bf903bd36c	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1f1ccd7a-6e77-4ebe-8978-721246a664a0	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
2b11da84-0f41-4100-9b84-6f2509945105	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7434a217-b23b-4696-99a7-30bb56ecbe87	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
e32718a8-ef32-4e62-ad7d-19871caa8fe6	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	a3f66399-34eb-4733-aca8-5de0402965dd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
660d64a2-16db-4ab3-aabc-9e92306d41be	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	92c9ea0b-a61e-40f9-bea2-0e22815ea371	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
6e433988-d6d1-470c-abbf-b2cfa719cd12	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	29beb9b9-c610-459f-96de-75028ed0bd29	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
534ae06e-5a74-4a9c-8304-5fc136c7f602	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
0abc6273-e78d-4a4b-9253-501ccf04ce18	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	76319288-44d8-4a0e-bde1-eaf71f7c78ff	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-06 09:26:25.297245-03
adfdd109-5295-46e2-ac16-aa4d27240eae	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	456486fe-e416-4b20-9e94-b5b9f5bbc877	\N	MOTOCICLETA	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	0.6	\N	\N	2026-05-06 09:26:25.297245-03
58b8642d-c2be-4d9d-b634-51727db909a5	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	5383baa6-72ad-410b-b430-ec9def1fcc44	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.297245-03
e0db0593-adbd-4bd9-bb91-f250a044bf27	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
ee4463fe-c617-411b-b925-954d84a9be1a	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
25a8e5fb-c2bb-439c-b3fb-fc75ae1d02ce	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
54e711b6-8c76-4193-b0ef-fb5315c96301	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	86552253-01f8-43a2-adbc-cc6f93fbe211	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-06 09:26:25.297245-03
e79c6da4-0118-48f0-b247-93a90350a939	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	be0a71b5-1dda-4a7b-8432-dfeb79724b42	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-06 09:26:25.297245-03
9cd8ca0b-e09c-4308-bc16-4fcbba0183d8	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1786752f-e3ae-44e8-aaa7-f8592b61f280	\N	MICRO_ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.8	\N	\N	2026-05-06 09:26:25.297245-03
34939161-4315-4f83-add5-6bf0c05ce1f3	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c95ce3e6-ddbd-4005-90a7-4a4347c26802	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
c8d7d6ba-501e-442d-b7a9-89a0a9a753df	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-06 09:26:25.297245-03
f07ef3cd-c1c3-47a5-ac55-4e4d511a6a9d	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	98747d4a-8ab2-4c37-9e33-d425b2ee711f	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.297245-03
911fb4c7-b02a-443c-924b-0e9d4ca776ee	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	631fc463-0e98-4eac-8c04-a3e79a400b13	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.297245-03
fcb621c7-c672-4471-88a6-e1afdc5a0520	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7109a9d3-6639-4814-a38f-a0aefc48b4de	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
936cdcb2-a3a4-49af-9d6f-ea12c5721b2b	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	b029e585-6b32-47fa-96c0-de67a6970963	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
2b867a2b-1297-42d4-ba99-c4ee6e7081b7	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	2b827cd4-988f-435f-b869-5f2e8a31b8e4	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
e7954989-d8eb-46ae-ae23-7a3d91c29110	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	9a6b1c3d-d9a9-4244-b08d-040d7debd465	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
d2f6c282-d6e9-4b98-a818-dffabec808de	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c7eda8b7-bd55-4970-8997-64b16b606b6f	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
14a270eb-407d-45a7-bfaa-447c94950150	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	fb6a50e6-b181-4ef7-a769-36a388ea9c74	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
0c5433fd-41d0-45dc-bc6f-326684666cb8	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	5c661a09-3f3e-4fd5-a576-2b97177a9c90	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
b10ff833-4f85-4798-b3a7-782743d9e8b9	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
7308a314-f44a-4ef1-ab74-444285380666	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8cdf0237-d061-4f6b-9541-409c2bf795c0	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
40cde562-cd90-4d69-8d55-a7531561c4eb	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	1a474e84-42d7-4710-9b0c-7379c805041d	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
02644ada-884e-4604-9ee6-a3409e553733	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	7e7d9b74-4814-4296-af40-5c76dd905a56	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
79fee6cb-20f0-43fd-8317-cf5d778e6f33	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	c3129621-9e62-4c33-8c78-88472a981c2e	\N	SEDAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-05-06 09:26:25.297245-03
c4a07be2-8e88-4b62-81c0-830e88bc5600	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-06 09:26:25.297245-03
13169738-4e4c-4a28-b255-34a87fe6406f	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	79daeec7-8cd2-415d-9dff-8133a4644d4e	\N	PICAPE	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.75	\N	\N	2026-05-06 09:26:25.297245-03
a9eec4aa-705f-43c7-8cc1-35405eb46071	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-06 09:26:25.297245-03
d6e04b35-0fdb-427a-ba60-18fbc16d8dc9	2026-04-05 21:00:00-03	2026-05-05 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-06 09:26:25.297245-03
e6b6ad34-50ae-4feb-a236-4f46f3c53c69	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	c4bb98ae-b770-4303-80f2-6c969f85c205	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
719821c9-d1e8-4310-8ca5-e8d005188f6e	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	020650d7-65e4-4a3f-8086-b81627409e93	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.35355-03
a3b2c730-b75f-48b6-9511-f6702f616dd0	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	3e5c4e1d-f72d-4146-bf05-78918e6093ee	\N	VAN	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	2.3	\N	\N	2026-05-07 10:29:05.35355-03
dcee8867-bc9a-4ac0-9fb8-8fbc17c36924	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	e5ce2035-52de-4439-b2ff-946b14b16fc9	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.35355-03
79622966-cb9d-4ff8-8031-0cd1f8444acd	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	52a0395e-da68-421f-885a-5a56cb279965	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
9b1fda5c-b9cf-4610-8739-9957c88f5acf	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b626cbb5-9afe-41ba-a091-1c51af0c347f	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-05-07 10:29:05.35355-03
86e2f69e-a775-4b2f-bcc4-e5965c8f7a06	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	162ac9f5-14ed-4f2b-bdc5-356f108312ef	\N	ONIBUS	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.2	\N	\N	2026-05-07 10:29:05.35355-03
bcaf29b2-cf3c-407b-897a-e45f72b0b46c	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	b01d4bc2-26b0-485a-ae91-e03f3de9af8e	\N	CAMINHAO	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	3.8	\N	\N	2026-05-07 10:29:05.35355-03
9b13e378-7e9f-48f9-8d9e-5c65936ca31a	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-05-07 10:29:05.35355-03
79b06dd0-d0a0-46bc-8049-6d48f01185b5	2026-04-06 21:00:00-03	2026-05-06 21:00:00-03	\N	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ITAMAR ALVES RODRIGUES	2026-05-07 10:29:05.35355-03
\.


--
-- Data for Name: fuel_station_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fuel_station_users (id, user_id, fuel_station_id, active, created_at, updated_at) FROM stdin;
3cd89051-6a6d-44fa-91fe-2311a35f5941	1692cea5-2f4e-4bff-9283-880e13767ed6	377dde01-11ff-49e2-98fa-f552c4d427b6	t	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
\.


--
-- Data for Name: fuel_stations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fuel_stations (id, name, active, created_at, updated_at, cnpj, address) FROM stdin;
377dde01-11ff-49e2-98fa-f552c4d427b6	Posto Centro	t	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03	12.345.678/0001-90	Avenida Principal, 1000 - Centro
\.


--
-- Data for Name: fuel_supplies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fuel_supplies (id, vehicle_id, driver_id, organization_id, supplied_at, odometer_km, liters, total_amount, fuel_station, notes, consumption_km_l, is_consumption_anomaly, anomaly_details, receipt_path, receipt_mime_type, receipt_size_bytes, receipt_uploaded_at, created_at, updated_at, fuel_station_id) FROM stdin;
\.


--
-- Data for Name: fuel_supply_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fuel_supply_orders (id, vehicle_id, driver_id, organization_id, fuel_station_id, status, expires_at, created_by_user_id, confirmed_by_user_id, requested_liters, max_amount, notes, confirmed_at, created_at, updated_at, validation_code) FROM stdin;
da18c0c6-e2f7-4b52-819a-fd42275504b0	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	b4b082f2-acb0-4f50-8365-3c48e35f6dad	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	377dde01-11ff-49e2-98fa-f552c4d427b6	EXPIRED	2026-04-25 18:07:00-03	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	\N	45.000	350.00	Teste de fluxo	\N	2026-04-24 18:08:13.51463-03	2026-04-27 08:20:23.913351-03	OA-34E6133A6CDD
\.


--
-- Data for Name: location_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location_history (id, vehicle_id, department, start_date, end_date, created_at, allocation_id, justification) FROM stdin;
5f707a38-50c2-4879-ad3b-3fa08b469738	9d93506e-947a-4f64-ba85-ed50f29af283	Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário	2026-04-15 21:02:19.626438-03	\N	2026-04-15 21:02:19.626438-03	171ac1a6-9eac-474a-a93a-675611aa783f	\N
e82752de-a623-4faa-ad1f-81f7cdfd1c79	3b767a49-d988-4686-8351-ca04907e1be7	Secretaria de Administração - Departamento de TI - Departamento de TI	2026-04-16 11:22:51.468843-03	\N	2026-04-16 11:22:51.468843-03	66824306-6e4d-4eb8-a3d4-b80010731ca7	\N
306e752a-bec7-497e-b785-e68883921f5e	07c1894c-d8aa-45f7-95e4-a44162c608c6	Secretaria de Administração - Departamento de Frotas - Departamento de Frotas	2026-04-16 11:30:32.016056-03	\N	2026-04-16 11:30:32.016056-03	979b0bff-f532-4a64-a3c2-ad4a119da580	\N
ba9c5791-2103-4edd-b607-bb955f654029	51a8d922-0382-4242-99b0-841b0c8e386a	Secretaria de Administração - Agricultura - SEAGRI - Agricultura - SEAGRI	2026-04-16 11:32:29.841531-03	2026-04-20 11:18:54.125232-03	2026-04-16 11:32:29.841531-03	\N	\N
459b0cbe-a765-4643-bb46-c36493eca2ce	51a8d922-0382-4242-99b0-841b0c8e386a	Secretaria de Agricultura Pecuária e Abastecimento - Gabinete da Secretaria - Gabinete	2026-04-20 11:18:53.931915-03	\N	2026-04-20 11:18:53.931915-03	c7e7ff44-4673-4095-aa5e-a50d75656201	\N
ecea2e85-011a-4978-a022-3c51bfd26500	ef947a79-a1a0-42d5-977c-50cc43f016b6	Secretaria de Administração - Infraestrutura - SEINFRA - Infraestrutura - SEINFRA	2026-04-16 11:29:33.565033-03	2026-04-20 11:19:15.980648-03	2026-04-16 11:29:33.565033-03	\N	\N
badc8837-5ddc-4e5e-b115-edf59934e64a	ef947a79-a1a0-42d5-977c-50cc43f016b6	Secretaria de Infraestrutura e Serviços Urbanos - Gabinete da Secretaria - Gabinete	2026-04-20 11:19:15.973684-03	\N	2026-04-20 11:19:15.973684-03	e4771d43-f38c-448a-b777-0feb3ad63194	\N
697a7720-73cb-44aa-9d6b-f44074fee3a8	0e9d959e-666d-4e9e-92ed-a15cff32db7a	Secretaria de Administração - Chefia de Governo - Chefia de Governo	2026-04-22 14:36:58.480425-03	\N	2026-04-22 14:36:58.480425-03	c6c9136b-b07e-4256-a46b-f4d4bdcb7b48	\N
5e43f0fa-fadf-4174-9b3c-cdf395ee71ee	405d91a7-fb9e-4789-9dc3-6f309431bfec	Secretaria de Administração - Chefia de Governo - Chefia de Governo	2026-04-22 14:41:58.938149-03	\N	2026-04-22 14:41:58.938149-03	c6c9136b-b07e-4256-a46b-f4d4bdcb7b48	\N
ad6a803d-5638-47b9-9806-47bcd6daa681	6857365a-5a63-49ab-a171-ddfb98863a9d	Secretaria de Administração - Chefia de Governo - Chefia de Governo	2026-04-22 14:46:31.860949-03	\N	2026-04-22 14:46:31.860949-03	c6c9136b-b07e-4256-a46b-f4d4bdcb7b48	\N
e8b5e6a5-61cc-4430-a3eb-b486bf1113ae	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia - Desenvolvimento Econômico - SDE - SEDE - SDE - SEDE	2026-04-23 14:54:05.450617-03	\N	2026-04-23 14:54:05.450617-03	3265a02e-4d56-4cb0-aa6f-4b1103ea3911	\N
29402b91-7be4-4673-bab5-ec171c3b6d77	9c952d6a-cc65-4519-ac6c-369c7c59005a	Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade	2026-04-27 14:37:41.850423-03	\N	2026-04-27 14:37:41.850423-03	39f52581-7227-45d0-afb5-16bee7638a8e	\N
74deca51-974b-407f-9cdd-1a53488c43ce	7afbd3c5-090f-4cbf-aa05-ba72db81e50f	Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade	2026-04-27 14:39:35.359975-03	\N	2026-04-27 14:39:35.359975-03	39f52581-7227-45d0-afb5-16bee7638a8e	\N
729288c2-a47c-4522-bf74-65073941303e	1f1ccd7a-6e77-4ebe-8978-721246a664a0	Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade	2026-04-27 14:40:31.029674-03	\N	2026-04-27 14:40:31.029674-03	39f52581-7227-45d0-afb5-16bee7638a8e	\N
0d7227fe-5968-4097-a65c-1ad3a4a2241b	7434a217-b23b-4696-99a7-30bb56ecbe87	Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade	2026-04-27 14:41:22.213155-03	\N	2026-04-27 14:41:22.213155-03	39f52581-7227-45d0-afb5-16bee7638a8e	\N
2e8d1098-a2ce-4ec8-bbb5-91fed0123217	a3f66399-34eb-4733-aca8-5de0402965dd	Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade	2026-04-27 14:57:51.552065-03	\N	2026-04-27 14:57:51.552065-03	39f52581-7227-45d0-afb5-16bee7638a8e	\N
f5691154-9e91-4e9d-acf1-83c5b88506f7	92c9ea0b-a61e-40f9-bea2-0e22815ea371	Secretaria de Saúde - Media e Alta Complexidade - Media e Alta Complexidade	2026-04-27 15:01:04.30363-03	\N	2026-04-27 15:01:04.30363-03	39f52581-7227-45d0-afb5-16bee7638a8e	\N
9be1e5b3-4406-485e-8fa6-3a89c6ff8eae	29beb9b9-c610-459f-96de-75028ed0bd29	Gabinete do Prefeito - Gabinete do Prefeito - Gabinete do Prefeito	2026-04-27 15:08:13.692254-03	\N	2026-04-27 15:08:13.692254-03	935fdaee-e400-4be1-bd96-0e8955da50ff	\N
0a69ea2f-2b85-4c6b-970a-6af54f5529d3	8d97e270-d55a-45d2-ab45-8b1f00d7b45d	Secretaria de Administração - Departamento de Frotas - Departamento de Frotas	2026-04-27 16:07:40.862638-03	\N	2026-04-27 16:07:40.862638-03	979b0bff-f532-4a64-a3c2-ad4a119da580	\N
0486ec44-81f0-4195-9690-d04c24b2afd5	76319288-44d8-4a0e-bde1-eaf71f7c78ff	Secretaria de Administração - Departamento Administrativo - Departamento Administrativo	2026-04-27 16:14:10.108415-03	2026-04-27 16:16:52.159121-03	2026-04-27 16:14:10.108415-03	4febca10-87f3-4f62-8d59-d6bb472dd502	\N
c7d82173-44f3-4b64-9d90-7cf9ee464b4c	76319288-44d8-4a0e-bde1-eaf71f7c78ff	Secretaria de Administração - Departamento Administrativo - SESMT	2026-04-27 16:16:52.133461-03	\N	2026-04-27 16:16:52.133461-03	edbad937-d073-4cce-8cfd-eead6bbb3d57	O veículo está sendo utilizado pelo SESMT
980183e6-8874-4e69-96cb-0b5f84951692	456486fe-e416-4b20-9e94-b5b9f5bbc877	Secretaria de Administração - Departamento Administrativo - DAP	2026-04-27 16:17:36.167767-03	\N	2026-04-27 16:17:36.167767-03	b6ac4e0b-b746-4351-90a7-45ed15fa0250	\N
390be4ca-5695-4bb3-bc5e-8cd9585978bb	5383baa6-72ad-410b-b430-ec9def1fcc44	Secretaria de Administração - Departamento Administrativo - Departamento Administrativo	2026-04-27 16:18:57.740704-03	\N	2026-04-27 16:18:57.740704-03	4febca10-87f3-4f62-8d59-d6bb472dd502	\N
8269b833-48dc-47f3-a09d-aaf5d35c5080	9a0ec055-a1ee-4fd4-99d5-5361b3843e01	Secretaria de Administração - Departamento Administrativo - Departamento Administrativo	2026-04-27 16:31:37.176165-03	\N	2026-04-27 16:31:37.176165-03	4febca10-87f3-4f62-8d59-d6bb472dd502	\N
84a6436f-7bad-431c-b624-23f44398ea73	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário	2026-05-02 10:55:05.271458-03	\N	2026-05-02 10:55:05.271458-03	171ac1a6-9eac-474a-a93a-675611aa783f	\N
43a3d191-4043-4f0d-993c-eee3027e24ad	9f48e3f5-ccc5-425b-909a-f9ee3c067b68	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-04 16:37:39.628895-03	\N	2026-05-04 16:37:39.628895-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
648d53b5-a12a-4a4d-b3b8-5f88a987abd9	86552253-01f8-43a2-adbc-cc6f93fbe211	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-04 16:38:27.340487-03	\N	2026-05-04 16:38:27.340487-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
2ecf8ac6-c692-4753-8225-13540098c48d	be0a71b5-1dda-4a7b-8432-dfeb79724b42	Secretaria de Educação - Educação - Educação	2026-05-04 16:43:17.498038-03	\N	2026-05-04 16:43:17.498038-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
66d8566f-5149-4ebf-9579-30f84e79912a	1786752f-e3ae-44e8-aaa7-f8592b61f280	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-04 16:44:30.993613-03	\N	2026-05-04 16:44:30.993613-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
0ebcf1d4-b8b1-44ba-b15d-51e87c75ecf4	c95ce3e6-ddbd-4005-90a7-4a4347c26802	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-04 16:46:55.780498-03	\N	2026-05-04 16:46:55.780498-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
f089408d-c11f-4999-bb4c-2704372a0019	64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	Secretaria de Educação - Educação - Educação	2026-05-04 16:49:02.492304-03	\N	2026-05-04 16:49:02.492304-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
616a9d80-5019-4d03-9ab0-c56fac5c968d	98747d4a-8ab2-4c37-9e33-d425b2ee711f	Secretaria de Educação - Educação - Educação	2026-05-04 16:52:49.17403-03	\N	2026-05-04 16:52:49.17403-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
2b65e587-61d4-4593-8a06-fc8bf8c03e6b	631fc463-0e98-4eac-8c04-a3e79a400b13	Secretaria de Educação - Educação - Educação	2026-05-04 16:56:51.405719-03	\N	2026-05-04 16:56:51.405719-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
2da49433-cdc4-4298-8b92-18d8b82c59ca	7109a9d3-6639-4814-a38f-a0aefc48b4de	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-04 16:58:04.889896-03	\N	2026-05-04 16:58:04.889896-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
f8a99f9c-d151-4540-9bc7-12e1158bea05	b029e585-6b32-47fa-96c0-de67a6970963	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-04 16:59:00.859806-03	\N	2026-05-04 16:59:00.859806-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
6a94c3cb-b10e-4ab8-a3fc-3d71fdf99626	2b827cd4-988f-435f-b869-5f2e8a31b8e4	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-05 15:37:26.118601-03	\N	2026-05-05 15:37:26.118601-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
729f0aed-ba8c-4489-85fc-c27d3305b680	9a6b1c3d-d9a9-4244-b08d-040d7debd465	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-05 15:38:14.123097-03	\N	2026-05-05 15:38:14.123097-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
83f2011d-a328-458d-a4fc-289047945688	c7eda8b7-bd55-4970-8997-64b16b606b6f	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-05 15:39:29.091115-03	\N	2026-05-05 15:39:29.091115-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
a55f36eb-c804-43a6-a374-995081ab3483	fb6a50e6-b181-4ef7-a769-36a388ea9c74	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-05 15:40:56.289894-03	\N	2026-05-05 15:40:56.289894-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
827f827d-fa41-424f-9abb-978388d15337	5c661a09-3f3e-4fd5-a576-2b97177a9c90	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-05 15:43:50.223705-03	\N	2026-05-05 15:43:50.223705-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
8cc08224-8a5c-4509-9552-796039910be9	37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-05 15:47:07.760079-03	\N	2026-05-05 15:47:07.760079-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
1e4e737a-d3d4-452e-8322-c7d0cd40b0e4	8cdf0237-d061-4f6b-9541-409c2bf795c0	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-05 15:47:53.124273-03	\N	2026-05-05 15:47:53.124273-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
2d3ab4da-a3cb-4d64-a86a-cf999add58f5	1a474e84-42d7-4710-9b0c-7379c805041d	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-05 15:50:44.761095-03	\N	2026-05-05 15:50:44.761095-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
52c5deb5-1559-486d-ac0c-d8c217c14ecc	7e7d9b74-4814-4296-af40-5c76dd905a56	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-05 15:51:36.812135-03	\N	2026-05-05 15:51:36.812135-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
bdba0558-484e-4b8d-96ee-8e4294025cfe	c3129621-9e62-4c33-8c78-88472a981c2e	Secretaria de Educação - Educação - Educação	2026-05-05 15:52:42.693588-03	\N	2026-05-05 15:52:42.693588-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
ddb33f96-46d0-4f0e-8cc9-adb2310a9f8d	8111498b-930e-4ec9-ad53-91e7b2f6e4a5	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-05 15:53:37.926822-03	\N	2026-05-05 15:53:37.926822-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
7d2673b4-2369-4b29-8a4a-1f189a2c7435	79daeec7-8cd2-415d-9dff-8133a4644d4e	Secretaria de Educação - Educação - Educação	2026-05-05 15:54:24.30202-03	\N	2026-05-05 15:54:24.30202-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
60fb7c79-f6d8-4440-b681-fd3298e46852	b137d4b0-9960-43a4-a9f8-916136fa73ee	Secretaria de Educação - Educação - Educação	2026-05-06 14:48:22.931624-03	\N	2026-05-06 14:48:22.931624-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
c0a8b713-069d-40e6-9008-0be2b7771a96	ec382e7b-22e2-41ca-9797-958ddf8128a3	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-06 14:50:31.747131-03	\N	2026-05-06 14:50:31.747131-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
daf8a0b2-fc0f-4e75-b5bf-95f0e929e810	bc17f68a-a40e-4bcc-b044-c6efd267ad19	Secretaria de Educação - Educação - Educação	2026-05-06 14:53:13.813737-03	\N	2026-05-06 14:53:13.813737-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
bc6f4dff-0088-4a92-befd-6c0097375e84	c5e6bea5-1489-42f2-aa5c-0966007bcd9f	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-06 14:52:04.251572-03	2026-05-06 14:54:09.952757-03	2026-05-06 14:52:04.251572-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
b1f41063-fd96-41b9-a414-e38a5121d83a	c5e6bea5-1489-42f2-aa5c-0966007bcd9f	Secretaria de Educação - Educação - Educação	2026-05-06 14:54:09.946852-03	\N	2026-05-06 14:54:09.946852-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	Cadastrado no departamento errado
59f4b4f1-94da-4c14-90d9-fa255197db31	2bac086f-7650-4aed-a915-7c853a0e727a	Secretaria de Educação - Educação - Educação	2026-05-06 14:55:56.300228-03	\N	2026-05-06 14:55:56.300228-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
60178d40-e7ee-4841-8d95-38bb13c2a6fd	72b3a123-3335-476e-ade8-1cd2bf8e22d1	Secretaria de Educação - Educação - Educação	2026-05-06 15:10:28.664392-03	\N	2026-05-06 15:10:28.664392-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
548d6d7b-ddf3-445e-8f75-1c80512548e8	3b1d50ae-23f6-4a17-bf6a-f39752f95697	Secretaria de Educação - Educação - Educação	2026-05-06 15:15:04.138461-03	\N	2026-05-06 15:15:04.138461-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
248720d1-a587-4078-86f1-da6a13ba095c	d758d9ab-084a-42e8-a474-f85ef8109ea6	Secretaria de Educação - Educação - Educação	2026-05-06 15:22:38.449086-03	\N	2026-05-06 15:22:38.449086-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
c1fd494d-dc1f-4b12-88a6-ee030dc46fda	62ed0519-240d-4611-9cb9-b8003be5b369	Secretaria de Educação - Educação - Educação	2026-05-06 15:25:18.970814-03	\N	2026-05-06 15:25:18.970814-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
944c8290-c607-441d-8ff1-05680fc05070	25226f6b-6acc-4356-96f9-c3cd85b994b8	Secretaria de Educação - Educação - Educação	2026-05-06 15:28:07.536243-03	\N	2026-05-06 15:28:07.536243-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
17cc567b-05dc-4d22-9d52-3169cf106a43	befb7af5-986b-4685-bbd8-de53b159bfef	Secretaria de Educação - Educação - Educação	2026-05-06 15:30:27.158505-03	\N	2026-05-06 15:30:27.158505-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
6ce52216-46f6-4014-aa14-f8189ed64e0e	4b8d5b8c-53e5-4662-9725-12e633182843	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-06 15:33:34.928813-03	\N	2026-05-06 15:33:34.928813-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
1e8d0073-c07f-481d-8a90-635083a704d8	b166fa01-6228-45a8-87ba-4575978ee8cf	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-06 15:36:18.675151-03	\N	2026-05-06 15:36:18.675151-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
0e2e1050-ed8b-4d0b-90b3-c3da56fe8cdb	4f6d1058-ebbd-4f81-96a0-ccdc19c9ed05	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-06 15:38:57.510394-03	\N	2026-05-06 15:38:57.510394-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
18dfa3d5-c78a-4d0f-99ac-ae2dda11d154	a54306d3-6b90-4c2a-9844-bebce0a32854	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-06 15:40:36.742414-03	\N	2026-05-06 15:40:36.742414-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
12a44bf1-0ff8-4d34-a02a-bd65a33aeaf1	9d5d671d-9fd5-4fcd-a27a-c4d91704fbe6	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-06 15:48:58.7455-03	\N	2026-05-06 15:48:58.7455-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
8c80084c-309d-4be3-89a8-b0aada2ac32c	8b48d4ef-cdad-4489-9af7-db977571ed88	Secretaria de Educação - Educação - Educação	2026-05-06 14:57:10.39655-03	\N	2026-05-06 14:57:10.39655-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
8a2b31df-028a-4482-94c8-89591f21720a	585dc2bb-c774-486a-8ad2-b12544d3d7d0	Secretaria de Educação - Educação - Educação	2026-05-06 15:19:57.728511-03	\N	2026-05-06 15:19:57.728511-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
15e6cc11-4074-4960-80ae-c44e7881cd32	ec530224-b28d-4883-8109-093950bd2650	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-06 15:37:50.193294-03	\N	2026-05-06 15:37:50.193294-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
22d5fb94-e1a9-4e2b-92a1-37144a7eb081	53afecc8-8b0c-4372-9dc4-86e87d4d7aee	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-07 08:39:05.693902-03	\N	2026-05-07 08:39:05.693902-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
afd6a1c8-c929-4bce-a9ac-49042c09b58c	c4bb98ae-b770-4303-80f2-6c969f85c205	Secretaria de Educação - Educação - Educação	2026-05-07 08:49:34.884641-03	\N	2026-05-07 08:49:34.884641-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
6b5e790f-dded-4d9d-bb75-a7269ecbe264	3e5c4e1d-f72d-4146-bf05-78918e6093ee	Secretaria de Educação - Educação - Educação	2026-05-07 08:57:22.838143-03	\N	2026-05-07 08:57:22.838143-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
a220d2ef-1e20-4bac-8384-7e5c8d20c30a	020650d7-65e4-4a3f-8086-b81627409e93	Secretaria de Educação - Educação - Educação	2026-05-07 09:00:50.90818-03	\N	2026-05-07 09:00:50.90818-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
471dc78d-f870-4a2d-8f3e-c95d4ec925e6	e5ce2035-52de-4439-b2ff-946b14b16fc9	Secretaria de Educação - Educação - Educação	2026-05-07 09:27:19.174835-03	\N	2026-05-07 09:27:19.174835-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
4f65941b-6d3e-426c-8674-f33e64db413c	52a0395e-da68-421f-885a-5a56cb279965	Secretaria de Educação - Educação - Educação	2026-05-07 10:14:36.430233-03	\N	2026-05-07 10:14:36.430233-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
7d46839b-6897-4399-99c7-09e1fa6edd44	b626cbb5-9afe-41ba-a091-1c51af0c347f	Secretaria de Educação - Educação - Educação	2026-05-07 10:20:08.861582-03	\N	2026-05-07 10:20:08.861582-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
017ca71d-1714-4b0e-a81f-71138b53b1e6	b01d4bc2-26b0-485a-ae91-e03f3de9af8e	Secretaria de Educação - Educação - Educação	2026-05-07 10:24:49.924243-03	\N	2026-05-07 10:24:49.924243-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
5b725d98-ce58-4795-bed8-325361c68762	02c1c1be-cb8a-4e8a-8e76-3d2be467d44f	Secretaria de Educação - Educação - Educação	2026-05-07 10:30:55.482217-03	\N	2026-05-07 10:30:55.482217-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
0974422c-bb5f-4180-bf41-e1d4cf549336	2d24caa9-0528-4a34-b542-fb139e4c25c8	Secretaria de Educação - Educação - Educação	2026-05-07 10:32:57.722534-03	\N	2026-05-07 10:32:57.722534-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
d88a3870-a551-448b-91c2-4f99e88d327d	847b4b9f-0737-4b1a-a917-4aed3f079beb	Secretaria de Educação - Educação - Educação	2026-05-07 10:37:19.286705-03	\N	2026-05-07 10:37:19.286705-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
4d9ddcb3-e370-4587-8994-b69c9c57d262	5f48e555-5e61-47f4-afa1-aa7220e07d2f	Secretaria de Educação - Educação - Educação	2026-05-07 10:40:41.198821-03	\N	2026-05-07 10:40:41.198821-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
6de14c0e-b8ac-4e0e-89e3-7468dfa4b59e	162ac9f5-14ed-4f2b-bdc5-356f108312ef	Secretaria de Educação - Educação - Educação	2026-05-07 10:22:10.133755-03	2026-05-07 10:44:38.679729-03	2026-05-07 10:22:10.133755-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
b8576b24-f6a5-4b6f-88cd-2684f42cdb59	162ac9f5-14ed-4f2b-bdc5-356f108312ef	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-07 10:44:38.67247-03	\N	2026-05-07 10:44:38.67247-03	8866c574-cd7f-4374-99fb-32a6884b36a5	Departamanto inserido de manira correta.
e2d30c72-feae-47ee-b262-c2ef40ecaf9b	bb065bfa-0fec-4912-866b-d8f83bc14808	Secretaria de Educação - Educação - Educação	2026-05-07 10:53:57.412157-03	\N	2026-05-07 10:53:57.412157-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
b98f6b16-3c54-4894-824b-dee70b01fb19	c21808fa-1f48-41df-b18d-56de492b6105	Secretaria de Educação - Educação - Educação	2026-05-07 10:58:45.36138-03	\N	2026-05-07 10:58:45.36138-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
a09a8eba-14b5-4dd6-9559-129e4c904e05	c2fe8306-0ba0-4919-b47e-2dda9615434d	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 11:00:44.953278-03	\N	2026-05-07 11:00:44.953278-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
2a9ba4c2-e1fe-4b28-9f66-93b776af5209	dfaa49c3-e78e-426e-b24c-242ac7f3a741	Secretaria de Educação - Educação - Educação	2026-05-07 11:01:02.396441-03	\N	2026-05-07 11:01:02.396441-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
35180357-5cda-47df-95e2-d6e520888a35	9dde0e5f-b30d-4ea0-be4e-f962e56119e5	Secretaria de Educação - Educação - Educação	2026-05-07 11:02:43.9266-03	\N	2026-05-07 11:02:43.9266-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
0eacee50-c6bb-4259-897e-6a6bfcbcda04	1cc10a16-c05a-49f1-aa9a-e41dc75a71ab	Secretaria de Educação - Educação - Educação	2026-05-07 11:04:40.866851-03	\N	2026-05-07 11:04:40.866851-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
37a11b44-188f-41b6-b5df-1d431c68014e	a83cd43f-d0cf-48a0-8338-a5dad123dbef	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 11:04:43.74397-03	\N	2026-05-07 11:04:43.74397-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
7cd2f614-2b41-41ca-a9cf-07da4f0be338	1d4d26b6-f2bc-46c7-91ef-ed40112872a5	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 11:06:18.078955-03	\N	2026-05-07 11:06:18.078955-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
f9e87bd6-af5f-4754-a777-b5a9067cbdc5	97f709fb-1dea-413e-8a76-8d0dbc556dab	Secretaria de Educação - Educação - Educação	2026-05-07 11:07:33.821582-03	\N	2026-05-07 11:07:33.821582-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
e3cfc74a-0b81-4cab-b5ca-0fd105c97c4a	b676f18d-ad1f-4efd-a5c3-bcc49d3a67fc	Secretaria de Promoção Social - Promoção Social - Promoção Social	2026-05-07 11:07:43.658968-03	\N	2026-05-07 11:07:43.658968-03	8c94c02a-0dd1-4f6e-ba34-786c9c94bfae	\N
65fe2449-07b2-4ddb-99f7-2419688021fc	d0801dc5-3768-4cf8-86e8-555e47f382ad	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 11:09:43.427932-03	\N	2026-05-07 11:09:43.427932-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
6bcdab3d-a2ab-488f-acd1-a6d2e23772f1	fa1c9c7d-97b2-44ae-9f81-e8512fbf629b	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 11:16:21.942509-03	\N	2026-05-07 11:16:21.942509-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
e0fe8206-fb1a-4a2f-968c-6c83cb0d9c87	46010cc1-0a0e-4bf7-8742-92d343ebff01	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 11:21:45.125117-03	\N	2026-05-07 11:21:45.125117-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
f7753075-9516-4c50-8e97-25d167b8c49d	67549dd2-6f5f-4060-95d5-3e27cfb31d5e	Secretaria de Promoção Social - Promoção Social - Promoção Social	2026-05-07 11:30:57.690671-03	\N	2026-05-07 11:30:57.690671-03	8c94c02a-0dd1-4f6e-ba34-786c9c94bfae	\N
154646d0-21ae-4b8a-ac49-b0f237636dbc	7b3e5178-fdf9-41a8-ac1d-02f32e2c54f9	Secretaria de Promoção Social - Promoção Social - Promoção Social	2026-05-07 11:34:38.806085-03	\N	2026-05-07 11:34:38.806085-03	8c94c02a-0dd1-4f6e-ba34-786c9c94bfae	\N
43984f53-6195-40ec-a5db-5bbc5268cfca	c5251949-6a19-4d2c-9a83-0c6fe7baf1f8	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 11:42:31.0588-03	\N	2026-05-07 11:42:31.0588-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
992122d6-48b4-48ca-8649-f981642acb6a	7dffee07-fbfc-4ecd-a7fc-f3b39f9aea4a	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 14:21:41.817632-03	\N	2026-05-07 14:21:41.817632-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
3bc165fc-da76-4979-8dee-826cf19a67c0	3249dd16-34ba-4066-9849-22418cb73ab8	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-07 14:22:12.879101-03	\N	2026-05-07 14:22:12.879101-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
c3e97d6c-a874-42dc-a0ee-7bdd651f40e0	2372e253-f9c6-42fa-bacc-c72736c42297	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 14:22:34.385635-03	\N	2026-05-07 14:22:34.385635-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
8b777d44-5c3e-4976-b924-839c4ff261fc	dcdad9e1-ae16-47d3-90a2-364df75fd6fa	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 14:23:16.54674-03	\N	2026-05-07 14:23:16.54674-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
0b889b91-95d6-455a-982f-7a3ab82719c0	82edf23e-e3e9-4cce-9fbf-73b8666d99a4	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 14:27:09.347825-03	\N	2026-05-07 14:27:09.347825-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
8dfdd469-73b5-4ac6-8664-adaa6c005777	d4594709-2edd-49c0-9ef5-793fa00d0679	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 14:28:00.103196-03	\N	2026-05-07 14:28:00.103196-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
b37e6141-30c8-41f8-8926-1e29e2cdf171	d16fe3df-dd43-4615-8dfc-04353dc30558	Secretaria de Promoção Social - Bolsa Familia - Bolsa Familia	2026-05-07 14:28:47.906688-03	\N	2026-05-07 14:28:47.906688-03	1fcb3ec9-e800-4436-a61c-fe099ad4c71f	\N
27f77f63-4568-45aa-b137-7dbc0ddd2b99	fc7d2025-da07-4d13-a50e-f4482ba86eb4	Secretaria de Educação - Educação - Educação	2026-05-07 14:29:32.257959-03	\N	2026-05-07 14:29:32.257959-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
7277ae4b-8ef1-4675-b1f6-439016560298	5b0cb3e0-428f-40af-8cc8-eb21d3838416	Secretaria de Educação - Educação - Educação	2026-05-07 14:31:35.022112-03	\N	2026-05-07 14:31:35.022112-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
116e0daf-7389-48a4-81ee-22ff576539e7	4eeb8891-d468-4299-8052-6204c49f8ad2	Secretaria de Educação - Educação - Educação	2026-05-07 14:35:17.772998-03	\N	2026-05-07 14:35:17.772998-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
9eb74e43-2cbb-4910-9cf9-dc1683f398af	e5aa8a51-6018-4eb8-948d-e66a5bd2b8e3	Secretaria de Educação - Educação - Educação	2026-05-07 14:38:12.65109-03	\N	2026-05-07 14:38:12.65109-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
165ab4ba-c129-4198-8e1e-422c21b78cc5	01fe46d0-c29b-4c8c-ae9b-fd85e5eeeedd	Secretaria de Educação - Educação - Educação	2026-05-07 14:40:13.113543-03	\N	2026-05-07 14:40:13.113543-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
28707406-210e-49a0-beac-5b245c74a655	974b6e91-8c98-44d4-84b8-0d49ce8833a3	Secretaria de Educação - Educação - Educação	2026-05-07 14:41:41.25006-03	\N	2026-05-07 14:41:41.25006-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
f7216107-c190-4239-a3ef-34a35148dd07	de1135a4-f534-40e7-b153-004e3f212742	Secretaria de Educação - Educação - Educação	2026-05-07 14:43:30.425049-03	\N	2026-05-07 14:43:30.425049-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
e73b7164-1335-479f-8ed1-72c9236031d6	7ab1872f-4613-4be0-bcb4-7c3689d4c803	Secretaria de Educação - Educação - Educação	2026-05-07 14:44:51.841081-03	\N	2026-05-07 14:44:51.841081-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
cdfdce19-7a98-4da9-a34e-31e4058ec9ce	25fec697-0605-4fed-82a9-63179025d466	Secretaria de Educação - Educação - Educação	2026-05-07 14:47:17.915212-03	\N	2026-05-07 14:47:17.915212-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
6b2a5b90-5e7a-4bd6-b0df-ff1d2ec0cfb6	dc999c35-28b0-47a8-97d4-5b37cd7289ff	Secretaria de Educação - Educação - Educação	2026-05-07 14:48:43.921457-03	\N	2026-05-07 14:48:43.921457-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
824a7456-12f8-4735-9996-37274c86079a	44888801-13c0-4a70-8f0c-540b316ee675	Secretaria de Educação - Educação - Educação	2026-05-07 14:51:37.811235-03	\N	2026-05-07 14:51:37.811235-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
11ca706f-aec0-47f6-819c-5630f0e9ad42	3e19e069-02fc-448a-8e8d-8773fea67f01	Secretaria de Educação - Educação - Educação	2026-05-07 14:53:55.098133-03	\N	2026-05-07 14:53:55.098133-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
9860dc3e-e456-44df-9252-d198726ead3e	77b0f1ab-874e-4ddf-b2b2-6c5873c8906f	Secretaria de Educação - Educação - Educação	2026-05-07 15:02:34.564282-03	\N	2026-05-07 15:02:34.564282-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
c5927ba6-cbdb-4e5a-bc7a-e4671120db5d	4e889a19-42d1-4e8b-a0a9-a839f24c09bd	Secretaria de Promoção Social - Promoção Social - Promoção Social	2026-05-07 14:30:13.773283-03	2026-05-07 14:58:30.881549-03	2026-05-07 14:30:13.773283-03	8c94c02a-0dd1-4f6e-ba34-786c9c94bfae	\N
c1d1fd7c-7c51-405e-ab76-295ebf7fa663	4e889a19-42d1-4e8b-a0a9-a839f24c09bd	Secretaria de Promoção Social - CONSELHO TUTELAR - CONSELHO TUTELAR - PLANTÃO	2026-05-07 14:58:30.878173-03	\N	2026-05-07 14:58:30.878173-03	d58ba718-3983-4611-b757-4a84748f3470	USO OBRIGATORIO EM PLANTÃO
84b55a18-fef2-4933-86c9-01fc69d307ff	b964d75c-afae-4fb2-a1c9-974c41c2d995	Secretaria de Educação - Educação - Educação	2026-05-07 15:00:44.140793-03	\N	2026-05-07 15:00:44.140793-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
52f6fb58-c8a4-4489-8f73-6994efa84494	d8a0948e-0c69-4193-877e-d0d81c97afe0	Secretaria de Educação - Educação - Educação	2026-05-07 15:11:42.1261-03	\N	2026-05-07 15:11:42.1261-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
2968bbfc-2c1b-4d54-b10b-bd7449cd8301	2dbdd1ef-e0fe-4b96-ad04-e89dec4f7159	Secretaria de Promoção Social - LAR SAGRADA FAMILIA - ABRIGO - ABRIGO	2026-05-07 15:39:00.781396-03	\N	2026-05-07 15:39:00.781396-03	5d9efb45-1c11-4cad-94d2-473f0f96ef10	\N
9dda172f-e1c6-42eb-9f0c-570307d6151e	50072ae4-d280-4b9e-b2d1-b22090b6d2c5	Secretaria de Educação - Educação - Educação	2026-05-07 15:16:34.342833-03	\N	2026-05-07 15:16:34.342833-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
23cb1e55-f5f3-4562-8651-dbb45cbcef56	097e3b6a-3a8d-45ff-91f4-999830e5da56	Secretaria de Educação - Educação - Educação	2026-05-07 15:27:59.269238-03	\N	2026-05-07 15:27:59.269238-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
cd7b81b7-e900-496a-b217-a232152c1c10	87ccee58-1d57-44aa-8ed1-ac8b14aa15f4	Secretaria de Promoção Social - CONSELHO TUTELAR - CONSELHO TUTELAR - PLANTÃO	2026-05-07 15:33:57.802027-03	\N	2026-05-07 15:33:57.802027-03	d58ba718-3983-4611-b757-4a84748f3470	\N
78674698-3ef8-4d23-adb8-faa821155dd0	6d4b0667-a7b5-4e90-9b2e-9fed98054048	Secretaria de Educação - Transporte Escolar - Transporte Escolar	2026-05-07 15:35:15.001318-03	\N	2026-05-07 15:35:15.001318-03	8866c574-cd7f-4374-99fb-32a6884b36a5	\N
7e47ac81-6029-430a-a337-862e147b4a64	fe1bc612-43dc-4d32-a369-14ed863ba554	Secretaria de Educação - Educação - Educação	2026-05-07 15:23:07.728787-03	\N	2026-05-07 15:23:07.728787-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
81acbf56-5dd8-4f19-b741-8ab13a998d0f	9cf59762-4171-4c1e-b552-4d7655935e6e	Secretaria de Educação - Educação - Educação	2026-05-07 15:24:36.689852-03	\N	2026-05-07 15:24:36.689852-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
f469d90c-1c4d-40ee-88be-46d62f18ea40	123dc9e7-8bb6-4fbe-a632-31a95b0e181f	Secretaria de Educação - Educação - Educação	2026-05-07 15:26:25.76447-03	\N	2026-05-07 15:26:25.76447-03	462c5c47-1e0a-47e4-b319-b5e58f829d3c	\N
\.


--
-- Data for Name: maintenance_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_records (id, vehicle_id, start_date, end_date, service_description, parts_replaced, total_cost, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: master_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_allocations (id, department_id, name, created_at, updated_at) FROM stdin;
171ac1a6-9eac-474a-a93a-675611aa783f	08c87c40-c5b3-4531-a561-2480d3d65c02	Gabinete do Secretário	2026-04-15 20:58:48.993092-03	2026-04-15 20:58:48.993092-03
d2399f27-137d-4b0b-bccf-4adc5da83c9a	9b013e25-2dfb-4276-80ff-73c36923f68f	SESMT	2026-04-15 20:59:11.378042-03	2026-04-15 20:59:11.378042-03
4129b656-4329-4bdc-af3e-a107f0467cdd	8ff4e2f2-d4d9-4239-b5a4-2939c8db97f4	Patrimônio e Arquivos em Geral	2026-04-15 20:59:36.630497-03	2026-04-15 20:59:36.630497-03
66824306-6e4d-4eb8-a3d4-b80010731ca7	6963629c-862f-49f1-b514-d0069096d0f6	Departamento de TI	2026-04-15 20:59:51.030476-03	2026-04-15 20:59:51.030476-03
f9034b11-e997-4d93-9af6-e38076cbcd03	1a87c196-04c6-4a3d-939d-9f074fc0ef36	Departamento de Recursos Humanos	2026-04-15 21:00:06.884083-03	2026-04-15 21:00:06.884083-03
4febca10-87f3-4f62-8d59-d6bb472dd502	8f8b0bde-a014-47f9-a2b7-de616bcca58d	Departamento Administrativo	2026-04-15 21:01:05.756829-03	2026-04-15 21:01:05.756829-03
b90c8744-a5d2-4751-923b-b4498764b756	3eac36c0-5ac6-43b7-bafc-2ce55213d70f	Almoxarifado Central	2026-04-15 21:01:25.309254-03	2026-04-15 21:01:25.309254-03
3265a02e-4d56-4cb0-aa6f-4b1103ea3911	abceb99f-7796-46df-9166-4d59699a581a	SDE - SEDE	2026-04-16 08:41:42.739476-03	2026-04-16 08:41:42.739476-03
979b0bff-f532-4a64-a3c2-ad4a119da580	ec714e4f-d968-4790-aabd-9390944ad035	Departamento de Frotas	2026-04-16 11:28:32.527935-03	2026-04-16 11:28:32.527935-03
c7e7ff44-4673-4095-aa5e-a50d75656201	6e0b0f1b-2f83-412e-a128-3fa682ea1190	Gabinete	2026-04-20 11:17:02.027361-03	2026-04-20 11:17:02.027361-03
e4771d43-f38c-448a-b777-0feb3ad63194	8e91b226-caf7-4965-91a1-37adca8d3f30	Gabinete	2026-04-20 11:17:48.96919-03	2026-04-20 11:17:48.96919-03
7eb88421-435f-4919-9f66-c7e6b3191e64	6e0b0f1b-2f83-412e-a128-3fa682ea1190	SEDE	2026-04-20 11:19:58.892797-03	2026-04-20 11:19:58.892797-03
ca62c137-72ca-4cb8-9d2d-8cb57fd1a9f4	8e91b226-caf7-4965-91a1-37adca8d3f30	SEDE	2026-04-20 11:20:17.915014-03	2026-04-20 11:20:17.915014-03
c6c9136b-b07e-4256-a46b-f4d4bdcb7b48	71e67d56-af08-4ef2-9077-c6b7ad79a099	Chefia de Governo	2026-04-22 14:30:25.60732-03	2026-04-22 14:30:25.60732-03
462c5c47-1e0a-47e4-b319-b5e58f829d3c	1adcb869-29ac-4973-8d65-93e1c76bac64	Educação	2026-04-23 15:34:49.546513-03	2026-04-23 15:34:49.546513-03
8866c574-cd7f-4374-99fb-32a6884b36a5	f319cfe4-e444-4349-806a-6597a2a56534	Transporte Escolar	2026-04-23 15:35:17.167032-03	2026-04-23 15:35:17.167032-03
981ea424-04bc-4a19-85d3-72d07750dbbc	0093febc-e750-466e-be19-be85945c2472	Garagem Central	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
138c2ed7-852c-4e67-8cbc-e70e66ed2ab5	2d368b1c-61eb-4a2b-88eb-20c879024c69	Oficina Central	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
a9f9b874-e66e-4bed-89b2-eedf7c40490c	562c0db6-c943-48b4-ba5c-812e6a622ab8	Patio Municipal	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
3e59f30b-0446-41af-ba12-702fc322e840	2b59966f-e58e-4dc0-ac34-7c6cdb03f29a	Bloco Atenção Básica	2026-04-27 11:47:54.336374-03	2026-04-27 11:47:54.336374-03
39f52581-7227-45d0-afb5-16bee7638a8e	69bc7c2a-182a-4086-aad7-76def6a2d313	Media e Alta Complexidade	2026-04-27 11:49:24.50607-03	2026-04-27 11:49:24.50607-03
1fcb3ec9-e800-4436-a61c-fe099ad4c71f	87ac1809-9f8c-4dc7-aef8-254629ec8f5c	Bolsa Familia	2026-04-27 11:56:05.546049-03	2026-04-27 11:56:05.546049-03
8c94c02a-0dd1-4f6e-ba34-786c9c94bfae	d3557c6f-d844-4d5a-8d8a-817c152191f8	Promoção Social	2026-04-27 11:56:32.621721-03	2026-04-27 11:56:32.621721-03
935fdaee-e400-4be1-bd96-0e8955da50ff	c27ae032-991d-4ab6-a015-8f424ca0961d	Gabinete do Prefeito	2026-04-27 15:03:14.580663-03	2026-04-27 15:03:14.580663-03
edbad937-d073-4cce-8cfd-eead6bbb3d57	8f8b0bde-a014-47f9-a2b7-de616bcca58d	SESMT	2026-04-27 16:15:00.787766-03	2026-04-27 16:15:00.787766-03
b6ac4e0b-b746-4351-90a7-45ed15fa0250	8f8b0bde-a014-47f9-a2b7-de616bcca58d	DAP	2026-04-27 16:15:08.794487-03	2026-04-27 16:15:08.794487-03
d58ba718-3983-4611-b757-4a84748f3470	3d193177-14e7-416a-89d0-dba0b85734ec	CONSELHO TUTELAR - PLANTÃO	2026-05-07 14:57:48.596842-03	2026-05-07 14:57:48.596842-03
5d9efb45-1c11-4cad-94d2-473f0f96ef10	849fdd73-12fa-4941-8db7-adbf32f5af06	ABRIGO	2026-05-07 15:35:26.878402-03	2026-05-07 15:35:26.878402-03
\.


--
-- Data for Name: master_departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_departments (id, organization_id, name, created_at, updated_at) FROM stdin;
8f8b0bde-a014-47f9-a2b7-de616bcca58d	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Departamento Administrativo	2026-04-10 13:45:38.76231-03	2026-04-10 16:57:52.211385-03
08c87c40-c5b3-4531-a561-2480d3d65c02	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Gabinete do Secretário	2026-04-15 20:48:27.51184-03	2026-04-15 20:48:27.51184-03
9b013e25-2dfb-4276-80ff-73c36923f68f	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	SESMT	2026-04-15 20:48:42.565904-03	2026-04-15 20:48:42.565904-03
3eac36c0-5ac6-43b7-bafc-2ce55213d70f	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Almoxarifado Central	2026-04-15 20:48:54.869736-03	2026-04-15 20:48:54.869736-03
8ff4e2f2-d4d9-4239-b5a4-2939c8db97f4	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Patrimônio e Arquivos em Geral	2026-04-15 20:49:18.680366-03	2026-04-15 20:49:18.680366-03
6963629c-862f-49f1-b514-d0069096d0f6	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Departamento de TI	2026-04-15 20:49:46.021639-03	2026-04-15 20:49:46.021639-03
1a87c196-04c6-4a3d-939d-9f074fc0ef36	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Departamento de Recursos Humanos	2026-04-15 20:55:52.752009-03	2026-04-15 20:55:52.752009-03
abceb99f-7796-46df-9166-4d59699a581a	72c067bf-d9f7-4f8d-b8c0-ce45d1713025	Desenvolvimento Econômico - SDE - SEDE	2026-04-16 08:40:12.620772-03	2026-04-16 11:15:45.185015-03
ec714e4f-d968-4790-aabd-9390944ad035	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Departamento de Frotas	2026-04-16 11:28:15.16876-03	2026-04-16 11:28:15.16876-03
6e0b0f1b-2f83-412e-a128-3fa682ea1190	dbae7e55-4e04-4c38-9128-a88c98b12160	Gabinete da Secretaria	2026-04-20 11:16:38.748208-03	2026-04-20 11:16:38.748208-03
8e91b226-caf7-4965-91a1-37adca8d3f30	9d68dcc7-a43b-4e27-9961-7929cf691b17	Gabinete da Secretaria	2026-04-20 11:17:37.554567-03	2026-04-20 11:17:37.554567-03
1adcb869-29ac-4973-8d65-93e1c76bac64	90332997-e801-44ba-be90-c2fa126053ea	Educação	2026-04-23 15:34:39.098836-03	2026-04-23 15:34:39.098836-03
f319cfe4-e444-4349-806a-6597a2a56534	90332997-e801-44ba-be90-c2fa126053ea	Transporte Escolar	2026-04-23 15:35:03.095258-03	2026-04-23 15:35:03.095258-03
2d368b1c-61eb-4a2b-88eb-20c879024c69	4b94a9c9-0535-476b-98eb-da99c2bbae5c	Oficina	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
71e67d56-af08-4ef2-9077-c6b7ad79a099	2a3832b2-77fd-4757-a132-ff35cbd197a8	Chefia de Governo	2026-04-22 14:30:03.639504-03	2026-04-27 11:34:42.781738-03
2b59966f-e58e-4dc0-ac34-7c6cdb03f29a	891b49ea-abf4-4501-9ef6-23fb78c42d25	Bloco Atenção Básica	2026-04-27 11:47:45.677623-03	2026-04-27 11:50:41.091633-03
69bc7c2a-182a-4086-aad7-76def6a2d313	891b49ea-abf4-4501-9ef6-23fb78c42d25	Media e Alta Complexidade	2026-04-27 11:48:49.811591-03	2026-04-27 11:50:47.005996-03
87ac1809-9f8c-4dc7-aef8-254629ec8f5c	6acb9d5d-599a-4e3e-9f67-932c561cbacb	Bolsa Familia	2026-04-27 11:55:58.06759-03	2026-04-27 11:55:58.06759-03
d3557c6f-d844-4d5a-8d8a-817c152191f8	6acb9d5d-599a-4e3e-9f67-932c561cbacb	Promoção Social	2026-04-27 11:56:24.433423-03	2026-04-27 11:56:24.433423-03
562c0db6-c943-48b4-ba5c-812e6a622ab8	891b49ea-abf4-4501-9ef6-23fb78c42d25	Transporte Saúde	2026-04-24 11:20:26.904725-03	2026-04-27 14:38:14.054064-03
c27ae032-991d-4ab6-a015-8f424ca0961d	471860e8-fe57-4181-bb14-cf3098787905	Gabinete do Prefeito	2026-04-27 15:03:07.567226-03	2026-04-27 15:03:07.567226-03
0093febc-e750-466e-be19-be85945c2472	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Gestão Administrativa	2026-04-24 11:20:26.904725-03	2026-04-27 16:08:57.364883-03
3d193177-14e7-416a-89d0-dba0b85734ec	6acb9d5d-599a-4e3e-9f67-932c561cbacb	CONSELHO TUTELAR	2026-05-07 14:53:02.613383-03	2026-05-07 14:53:02.613383-03
849fdd73-12fa-4941-8db7-adbf32f5af06	6acb9d5d-599a-4e3e-9f67-932c561cbacb	LAR SAGRADA FAMILIA - ABRIGO	2026-05-07 15:35:18.440527-03	2026-05-07 15:35:18.440527-03
\.


--
-- Data for Name: master_organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_organizations (id, name, created_at, updated_at) FROM stdin;
9d68dcc7-a43b-4e27-9961-7929cf691b17	Secretaria de Infraestrutura e Serviços Urbanos	2026-04-10 13:45:38.76231-03	2026-04-10 14:41:14.397968-03
90332997-e801-44ba-be90-c2fa126053ea	Secretaria de Educação	2026-04-10 14:41:36.159933-03	2026-04-10 14:41:45.602737-03
4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Secretaria de Administração	2026-04-10 13:45:38.76231-03	2026-04-10 14:41:52.177801-03
891b49ea-abf4-4501-9ef6-23fb78c42d25	Secretaria de Saúde	2026-04-10 13:45:38.76231-03	2026-04-10 14:41:59.519107-03
e6a79f0d-d2bf-4e00-bc6d-9294a5b0da7e	Controladoria Geral do Município	2026-04-10 14:42:38.708471-03	2026-04-10 14:42:38.708471-03
4fdeb45a-dca4-4dcf-93d0-08e24663e09a	Procuradoria Geral do Município	2026-04-10 14:43:01.690231-03	2026-04-10 14:43:01.690231-03
dbae7e55-4e04-4c38-9128-a88c98b12160	Secretaria de Agricultura Pecuária e Abastecimento	2026-04-10 14:43:19.225392-03	2026-04-10 14:43:19.225392-03
12375ce0-6f93-43b7-97df-787218d6ff37	Secretaria de Cultura e Turismo	2026-04-10 14:43:37.811732-03	2026-04-10 14:43:37.811732-03
72c067bf-d9f7-4f8d-b8c0-ce45d1713025	Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia	2026-04-10 14:44:01.635346-03	2026-04-10 14:44:01.635346-03
c191b61f-81f7-45ef-825f-fe6a50de9be1	Secretaria de Esporte e Lazer	2026-04-10 14:44:16.800864-03	2026-04-10 14:44:16.800864-03
f6dc3ca5-886b-4667-b0ca-536c4a0bfe97	Secretaria de Finanças	2026-04-10 14:44:25.083012-03	2026-04-10 14:44:25.083012-03
3b697c38-9278-4b7a-a653-ff985f47a2a6	Secretaria de Habitação	2026-04-10 14:44:44.853436-03	2026-04-10 14:44:44.853436-03
98a656ae-7517-408c-a997-454a7f7007d2	Secretaria de Meio Ambiente	2026-04-10 14:45:01.698856-03	2026-04-10 14:45:01.698856-03
555db8bb-6f86-437e-bb3b-a047a826ac34	Secretaria de Projetos Estratégicos e Gerenciamento de Convênios	2026-04-10 15:07:33.484142-03	2026-04-10 15:07:33.484142-03
6acb9d5d-599a-4e3e-9f67-932c561cbacb	Secretaria de Promoção Social	2026-04-10 15:08:53.789257-03	2026-04-10 15:08:53.789257-03
02708937-9e4d-4387-851b-7a49957405e2	Secretaria de Segurança e Transporte	2026-04-10 15:09:14.627433-03	2026-04-10 15:09:14.627433-03
4b94a9c9-0535-476b-98eb-da99c2bbae5c	Secretaria de Infraestrutura	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
2a3832b2-77fd-4757-a132-ff35cbd197a8	Chefia de Governo	2026-04-27 11:34:30.445614-03	2026-04-27 11:34:30.445614-03
471860e8-fe57-4181-bb14-cf3098787905	Gabinete do Prefeito	2026-04-10 14:42:45.400331-03	2026-04-27 15:02:51.633723-03
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, password_hash, role, created_at, updated_at, must_change_password) FROM stdin;
e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	$2b$12$dlweF7CXlWbVONjdgbuzN.iGDCxRLgZz9CI/81CHHU3AXYJy8nlbu	ADMIN	2026-04-07 09:49:57.38354-03	2026-04-07 09:49:57.38354-03	f
0af328cb-2b03-4abb-a363-666f82f826bd	Usuário Padrão	padrao@frota.local	$2b$12$lFBij5/aGvYva3rS2gEa8.rJhfZqRqyZTyUxIearPWvxDanQf42qq	PADRAO	2026-04-07 09:49:57.38354-03	2026-04-07 09:49:57.38354-03	f
2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	$2b$12$vZQOhZLjSNd8ixdiqsFZW.2beLDO.crYXUdE5ihEO47L57j5g1GGC	ADMIN	2026-04-09 15:51:27.86796-03	2026-04-09 16:37:31.621877-03	f
065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	$2b$12$hOqr7E7oKB.GSmO9Y/2uGeLgB5dywk64cuO9uiFPRfXBg3q4S1ckW	ADMIN	2026-04-09 11:59:41.218041-03	2026-04-13 10:12:02.307678-03	f
08d425de-0052-42b1-95ab-b3178cde1e30	WANDERSON SOUSA LIMAS	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	$2b$12$Z82Ah9eA4qFCn8t425vpnuICyhnwzgTAW/T55A7SDbhcg.T/gNhsu	ADMIN	2026-04-10 18:15:06.747474-03	2026-04-13 11:45:32.125092-03	f
50fcc408-b540-480a-872e-0f42650871a1	Usuario de Producao	producao@frota.local	$2b$12$ODkGPadZDKDwdECoFkxCxuXYHs7CX0Fz.JWv3uP9.qFLYc88JJdIa	PRODUCAO	2026-04-09 15:40:09.928335-03	2026-04-13 16:43:09.67634-03	f
9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	$2b$12$PSRLQBYWWJrTzjNJ1vjGTe0xbcASiF27zapOD0umXk2x04ins/Z/G	PRODUCAO	2026-04-13 08:59:01.344115-03	2026-04-16 10:34:26.757569-03	f
1692cea5-2f4e-4bff-9283-880e13767ed6	Operador de Posto	posto@frota.local	$2b$12$8nwvjVQQzuSn0Hs/LpbKsuePqbg9l3R8c.O2D5313DpUprpFOBjxi	POSTO	2026-04-24 11:20:26.904725-03	2026-04-24 11:21:34.386245-03	f
a28ad20a-f325-4b9b-a20f-ca74c5d848fd	MADSON SILVA ARAUJO	madsonjs@gmail.com	$2b$12$ZpLFklxSNCPQqARCqrGuxuCV4SMc8C9Jc5P.TEDUy6/J218siDTZK	ADMIN	2026-04-30 14:11:48.436785-03	2026-04-30 14:11:48.436785-03	f
88657b27-be9c-434a-ad5d-ffc746a56ecd	Cassio de Oliveira Farias	cassioof@pm.teixeiradefreitas.ba.gov.br	$2b$12$3JP83hRyjinEl8f9Thfeyug19QPIVlvniWG4For4ZKaPBh04RI9dC	PRODUCAO	2026-05-07 10:11:40.666849-03	2026-05-07 10:11:40.666849-03	t
0ee24af6-449b-4560-a5ae-f5bfedf66620	Paulo Murilo Alvares dos Santos	paulom@edu.teixeiradefreitas.ba.gov.br	$2b$12$J7H9fUAHvQz28wMdrIoAMeJ4b.WXzZ4sDaEvfxG2.08fmRWhq7WXm	PRODUCAO	2026-05-07 10:12:26.698386-03	2026-05-07 10:12:26.698386-03	t
4fe1b0cf-0e8e-48a4-b137-132b8d3ac4cb	Itamar Alves Rodrigues	itamar@pm.teixeiradefreitas.ba.gov.br	$2b$12$VVd8i0AHPDkVnkEvY57RFuSrE0NZkbTAYaS6OVZTHU7HdM6h7Dx/i	PRODUCAO	2026-05-07 10:10:27.47169-03	2026-05-07 10:56:53.804264-03	f
\.


--
-- Data for Name: vehicle_possession; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_possession (id, vehicle_id, driver_name, driver_document, driver_contact, start_date, end_date, observation, created_at, photo_path, photo_mime_type, photo_size_bytes, photo_captured_at, capture_latitude, capture_longitude, capture_accuracy_meters, document_path, document_name, document_mime_type, document_size_bytes, document_uploaded_at, driver_id, start_odometer_km, end_odometer_km, return_document_path, return_document_name, return_document_mime_type, return_document_size_bytes, return_document_uploaded_at) FROM stdin;
b9e4468b-0f73-4726-a10e-d0825b630d07	0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	ITAMAR ALVES RODRIGUES	042.515.165-40	7399900-2142	2026-05-02 11:10:00-03	2026-05-03 08:21:00-03	VIAGEM À PORTO SEGURO-BA EM 02/05/2026. \nVEÍCULO DEVOLVIDO EM 03/05/2021, SEM NENHUMA INTECORRÊNCIA.	2026-05-02 11:14:48.870979-03	\N	\N	\N	\N	\N	\N	\N	possession_documents/b9e4468b-0f73-4726-a10e-d0825b630d07.pdf	CCO_000118.pdf	application/pdf	102487	2026-05-02 11:46:38.492214-03	9f9fe2ce-81a1-4ba6-b9d7-74b5fe3cd75a	1803	2353	\N	\N	\N	\N	\N
\.


--
-- Data for Name: vehicle_possession_photos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_possession_photos (id, possession_id, photo_path, photo_mime_type, photo_size_bytes, photo_captured_at, capture_latitude, capture_longitude, capture_accuracy_meters, created_at) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicles (id, plate, brand, model, status, created_at, updated_at, chassis_number, ownership_type, vehicle_type) FROM stdin;
3b767a49-d988-4686-8351-ca04907e1be7	TOA5G32	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-16 11:22:51.468843-03	2026-04-16 11:22:51.468843-03	9BWAG5R14TT033231	LOCADO	HATCH
ef947a79-a1a0-42d5-977c-50cc43f016b6	TOA5G25	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-16 11:29:33.565033-03	2026-04-16 11:29:33.565033-03	9BWAG5R13TT033575	LOCADO	HATCH
07c1894c-d8aa-45f7-95e4-a44162c608c6	TOA5F48	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-16 11:30:32.016056-03	2026-04-16 11:30:32.016056-03	9BWAG5R17TT033370	LOCADO	HATCH
51a8d922-0382-4242-99b0-841b0c8e386a	TOA5F57	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-16 11:32:29.841531-03	2026-04-16 11:32:29.841531-03	9BWAG5R15TT033464	LOCADO	HATCH
0e9d959e-666d-4e9e-92ed-a15cff32db7a	TOA5G28	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-22 14:36:58.480425-03	2026-04-22 14:36:58.480425-03	9BWAG5R19TT033208	LOCADO	HATCH
405d91a7-fb9e-4789-9dc3-6f309431bfec	TOA5G11	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-22 14:41:58.938149-03	2026-04-22 14:41:58.938149-03	9BWAG5R1XTT033573	LOCADO	HATCH
6857365a-5a63-49ab-a171-ddfb98863a9d	TOA5F65	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-22 14:46:31.860949-03	2026-04-22 14:46:31.860949-03	9BWAG5R12TT033518	LOCADO	HATCH
487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	TOA5G37	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-23 14:54:05.450617-03	2026-04-23 14:54:05.450617-03	9BWAG5R15TT033321	LOCADO	HATCH
9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	VOLKSWAGEN	POLO TRACK MA	INATIVO	2026-04-15 21:02:19.626438-03	2026-04-23 17:12:05.105672-03	9BWAG5R10TT004230	LOCADO	HATCH
9c952d6a-cc65-4519-ac6c-369c7c59005a	TOA5G36	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-27 14:37:41.850423-03	2026-04-27 14:37:41.850423-03	9BWAG5R13TT033611	LOCADO	HATCH
7afbd3c5-090f-4cbf-aa05-ba72db81e50f	TOA5F96	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-27 14:39:35.359975-03	2026-04-27 14:39:35.359975-03	9BWAG5R1XTT033539	LOCADO	HATCH
1f1ccd7a-6e77-4ebe-8978-721246a664a0	TOA5F86	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-27 14:40:31.029674-03	2026-04-27 14:40:31.029674-03	9BWAG5R17TT033529	LOCADO	HATCH
7434a217-b23b-4696-99a7-30bb56ecbe87	TOA5F83	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-27 14:41:22.213155-03	2026-04-27 14:41:22.213155-03	9BWAG5R13TT033513	LOCADO	HATCH
a3f66399-34eb-4733-aca8-5de0402965dd	TOA5F51	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-27 14:57:51.552065-03	2026-04-27 14:57:51.552065-03	9BWAG5R14TT033424	LOCADO	HATCH
92c9ea0b-a61e-40f9-bea2-0e22815ea371	TOA5F46	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-27 15:01:04.30363-03	2026-04-27 15:01:04.30363-03	9BWAG5R14TT033326	LOCADO	HATCH
29beb9b9-c610-459f-96de-75028ed0bd29	TOA5F53	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-27 15:08:13.692254-03	2026-04-27 15:08:13.692254-03	9BWAG5R11TT033428	LOCADO	HATCH
8d97e270-d55a-45d2-ab45-8b1f00d7b45d	RPR8J49	FIAT	ARGO TREKKING	ATIVO	2026-04-27 16:07:40.862638-03	2026-04-27 16:07:40.862638-03	9BD358AGZPYM50057	PROPRIO	HATCH
76319288-44d8-4a0e-bde1-eaf71f7c78ff	RDN4B26	YAMAHA	XTZ150 CROSSER Z	ATIVO	2026-04-27 16:14:10.108415-03	2026-04-27 16:14:10.108415-03	9C6DG2580N0013160	PROPRIO	MOTOCICLETA
456486fe-e416-4b20-9e94-b5b9f5bbc877	RDN2D20	YAMAHA	XTZ150 CROSSER Z	ATIVO	2026-04-27 16:17:36.167767-03	2026-04-27 16:17:36.167767-03	9C6DG2580N0013151	PROPRIO	MOTOCICLETA
5383baa6-72ad-410b-b430-ec9def1fcc44	RPF9C78	RENAULT	KWID	ATIVO	2026-04-27 16:18:57.740704-03	2026-04-27 16:18:57.740704-03	93YRBB004PJ249712	PROPRIO	SEDAN
9a0ec055-a1ee-4fd4-99d5-5361b3843e01	PLT9G24	RENAULT	SANDERO	ATIVO	2026-04-27 16:31:37.176165-03	2026-04-27 16:31:37.176165-03	93Y5SRF84LJ843409	PROPRIO	HATCH
0b2614f6-7b2e-4cdc-b9fa-bde6eac614e7	TOA5G07	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-05-02 10:55:05.271458-03	2026-05-02 10:55:05.271458-03	9BWAG5R10TT033209	LOCADO	HATCH
9f48e3f5-ccc5-425b-909a-f9ee3c067b68	TGS2G58	VOLKSWAGEN	NEOBUS	ATIVO	2026-05-04 16:37:39.628895-03	2026-05-04 16:37:39.628895-03	953AD5TF4TR005350	PROPRIO	ONIBUS
86552253-01f8-43a2-adbc-cc6f93fbe211	TGR8A52	RENAULT	MASTER	ATIVO	2026-05-04 16:38:27.340487-03	2026-05-04 16:38:27.340487-03	93YF62009SJ064734	PROPRIO	MICRO_ONIBUS
be0a71b5-1dda-4a7b-8432-dfeb79724b42	TEV3G61	FIAT	STRADA	ATIVO	2026-05-04 16:43:17.498038-03	2026-05-04 16:43:17.498038-03	9BD281BKPSYH05662	PROPRIO	PICAPE
1786752f-e3ae-44e8-aaa7-f8592b61f280	SKS2D14	MERCEDES	JI MICRO	ATIVO	2026-05-04 16:44:30.993613-03	2026-05-04 16:44:30.993613-03	8AC907843SE256017	PROPRIO	MICRO_ONIBUS
c95ce3e6-ddbd-4005-90a7-4a4347c26802	SKL0F32	AGRALE	MARRUA	ATIVO	2026-05-04 16:46:55.780498-03	2026-05-04 16:46:55.780498-03	9BYMBCAKASC000104	PROPRIO	ONIBUS
64f8b5f2-5a27-4ea0-8d4c-bb0588593bb6	RPR9A34	FIAT	ARGO TREKKING	ATIVO	2026-05-04 16:49:02.492304-03	2026-05-04 16:49:02.492304-03	9BD358AGZPYM50464	PROPRIO	HATCH
98747d4a-8ab2-4c37-9e33-d425b2ee711f	RPR0D77	FIAT	CRONOS	ATIVO	2026-05-04 16:52:49.17403-03	2026-05-04 16:52:49.17403-03	8AP359AFPPU236374	PROPRIO	SEDAN
631fc463-0e98-4eac-8c04-a3e79a400b13	RPP8G47	CHEVROLET	SPIN	ATIVO	2026-05-04 16:56:51.405719-03	2026-05-04 16:56:51.405719-03	9BGJP7520PB217662	PROPRIO	SEDAN
7109a9d3-6639-4814-a38f-a0aefc48b4de	RPM5J88	MERCEDES	LO 916 ESC	ATIVO	2026-05-04 16:58:04.889896-03	2026-05-04 16:58:04.889896-03	9BM979282PB277325	PROPRIO	ONIBUS
b029e585-6b32-47fa-96c0-de67a6970963	RPG5I35	MERCEDES	LO 916 ESC	ATIVO	2026-05-04 16:59:00.859806-03	2026-05-04 16:59:00.859806-03	9BM979282PB268478	PROPRIO	ONIBUS
2b827cd4-988f-435f-b869-5f2e8a31b8e4	RPD5D07	MERCEDES	LO 916 ESC	ATIVO	2026-05-05 15:37:26.118601-03	2026-05-05 15:37:26.118601-03	9BM979277PB264347	PROPRIO	ONIBUS
9a6b1c3d-d9a9-4244-b08d-040d7debd465	RPD5C32	MERCEDES	LO 916 ESC	ATIVO	2026-05-05 15:38:14.123097-03	2026-05-05 15:38:14.123097-03	9BM979277PB261556	PROPRIO	ONIBUS
c7eda8b7-bd55-4970-8997-64b16b606b6f	RPD4I26	MERCEDES	LO 916 ESC	ATIVO	2026-05-05 15:39:29.091115-03	2026-05-05 15:39:29.091115-03	9BM979277PB264319	PROPRIO	ONIBUS
fb6a50e6-b181-4ef7-a769-36a388ea9c74	RPD2H45	MERCEDES	LO 916 ESC	ATIVO	2026-05-05 15:40:56.289894-03	2026-05-05 15:40:56.289894-03	9BM979277PB266139	PROPRIO	ONIBUS
5c661a09-3f3e-4fd5-a576-2b97177a9c90	RDQ7C68	MERCEDES	ACCELO	ATIVO	2026-05-05 15:43:50.223705-03	2026-05-05 15:43:50.223705-03	9BM979076MB216818	PROPRIO	ONIBUS
37a77c0a-745a-47fb-b441-1d5e0aaa2fc6	RCW9G31	IVECO	10-190E	ATIVO	2026-05-05 15:47:07.760079-03	2026-05-05 15:47:07.760079-03	93ZK01BDZM8938941	PROPRIO	ONIBUS
8cdf0237-d061-4f6b-9541-409c2bf795c0	RCW6D96	IVECO	10-190E	ATIVO	2026-05-05 15:47:53.124273-03	2026-05-05 15:47:53.124273-03	93ZK01BDZM8938939	PROPRIO	ONIBUS
1a474e84-42d7-4710-9b0c-7379c805041d	RCV3E37	MARCOPOLO	VOLARE	ATIVO	2026-05-05 15:50:44.761095-03	2026-05-05 15:50:44.761095-03	93PB58M10MC063635	PROPRIO	ONIBUS
7e7d9b74-4814-4296-af40-5c76dd905a56	RCV1A48	MARCOPOLO	VOLARE	ATIVO	2026-05-05 15:51:36.812135-03	2026-05-05 15:51:36.812135-03	93PB58M10MC063628	PROPRIO	ONIBUS
c3129621-9e62-4c33-8c78-88472a981c2e	RPO5C57	FIAT	CRONOS	ATIVO	2026-05-05 15:52:42.693588-03	2026-05-05 15:52:42.693588-03	8AP359AFPPU260739	PROPRIO	SEDAN
8111498b-930e-4ec9-ad53-91e7b2f6e4a5	RPO1J48	MERCEDES	LO 916 ESC	ATIVO	2026-05-05 15:53:37.926822-03	2026-05-05 15:53:37.926822-03	9BM979282PB286540	PROPRIO	ONIBUS
79daeec7-8cd2-415d-9dff-8133a4644d4e	PLM5H74	FIAT	STRADA	ATIVO	2026-05-05 15:54:24.30202-03	2026-05-05 15:54:24.30202-03	9BD57834FKY284368	PROPRIO	PICAPE
b137d4b0-9960-43a4-a9f8-916136fa73ee	PLD3395	FIAT	ARGO	ATIVO	2026-05-06 14:48:22.931624-03	2026-05-06 14:48:22.931624-03	9BD358A1NJYH86840	PROPRIO	HATCH
ec382e7b-22e2-41ca-9797-958ddf8128a3	PKH8362	IVECO	CITYCLASS	ATIVO	2026-05-06 14:50:31.747131-03	2026-05-06 14:50:31.747131-03	93ZL68C01E8456872	PROPRIO	ONIBUS
c5e6bea5-1489-42f2-aa5c-0966007bcd9f	PJU8904	VOLKSWAGEN	8.160 DRC	ATIVO	2026-05-06 14:52:04.251572-03	2026-05-06 14:52:04.251572-03	9531M52P4GR600604	PROPRIO	CAMINHAO
bc17f68a-a40e-4bcc-b044-c6efd267ad19	PJU1358	VOLKSWAGEN	8.160 DRC	ATIVO	2026-05-06 14:53:13.813737-03	2026-05-06 14:53:13.813737-03	9531M52P2GR601346	PROPRIO	CAMINHAO
2bac086f-7650-4aed-a915-7c853a0e727a	PJS9422	FIAT	STRADA	ATIVO	2026-05-06 14:55:56.300228-03	2026-05-06 14:55:56.300228-03	9BD57814UGB048539	PROPRIO	PICAPE
8b48d4ef-cdad-4489-9af7-db977571ed88	PJS3914	FIAT	STRADA	ATIVO	2026-05-06 14:57:10.39655-03	2026-05-06 14:57:10.39655-03	9BD57814UGB049318	PROPRIO	PICAPE
72b3a123-3335-476e-ade8-1cd2bf8e22d1	PJS3723	FIAT	PALIO	ATIVO	2026-05-06 15:10:28.664392-03	2026-05-06 15:10:28.664392-03	9BD17122ZG7574872	PROPRIO	HATCH
3b1d50ae-23f6-4a17-bf6a-f39752f95697	PJS3017	FIAT	STRADA	ATIVO	2026-05-06 15:15:04.138461-03	2026-05-06 15:15:51.027632-03	9BD57814UGB049302	PROPRIO	PICAPE
585dc2bb-c774-486a-8ad2-b12544d3d7d0	PJS1489	FIAT	PALIO FIRE	ATIVO	2026-05-06 15:19:57.728511-03	2026-05-06 15:19:57.728511-03	9BD17122ZG7574059	PROPRIO	SEDAN
62ed0519-240d-4611-9cb9-b8003be5b369	PJS0988	FIAT	PALIO FIRE	ATIVO	2026-05-06 15:25:18.970814-03	2026-05-06 15:25:18.970814-03	9BD17122ZG7574154	PROPRIO	HATCH
d758d9ab-084a-42e8-a474-f85ef8109ea6	PJS1032	FIAT	STRADA	ATIVO	2026-05-06 15:22:38.449086-03	2026-05-06 15:25:52.571443-03	9BD57814UGB048397	PROPRIO	PICAPE
25226f6b-6acc-4356-96f9-c3cd85b994b8	PJL9271	FIAT	PALIO FIRE WAY	ATIVO	2026-05-06 15:28:07.536243-03	2026-05-06 15:28:07.536243-03	9BD17144ZG7553966	PROPRIO	HATCH
befb7af5-986b-4685-bbd8-de53b159bfef	PJL2213	FIAT	PALIO FIRE WAY	ATIVO	2026-05-06 15:30:27.158505-03	2026-05-06 15:30:27.158505-03	9BD17144ZG7553747	PROPRIO	HATCH
4b8d5b8c-53e5-4662-9725-12e633182843	PJC5306	M.BENZ	OF 1519 R.ORE	ATIVO	2026-05-06 15:33:34.928813-03	2026-05-06 15:33:34.928813-03	9BM384069EB961259	PROPRIO	ONIBUS
b166fa01-6228-45a8-87ba-4575978ee8cf	OZQ7807	VW	15.190 EOD E.HD ORE	ATIVO	2026-05-06 15:36:18.675151-03	2026-05-06 15:36:18.675151-03	9532E82W4ER439422	PROPRIO	ONIBUS
ec530224-b28d-4883-8109-093950bd2650	OZQ4838	VW	15.190 EOD E.HD ORE	ATIVO	2026-05-06 15:37:50.193294-03	2026-05-06 15:37:50.193294-03	9532E82W5ER439140	PROPRIO	ONIBUS
4f6d1058-ebbd-4f81-96a0-ccdc19c9ed05	OZQ0183	VW	15.190 EOD E.HD ORE	ATIVO	2026-05-06 15:38:57.510394-03	2026-05-06 15:38:57.510394-03	9532E82W3ER439427	PROPRIO	ONIBUS
a54306d3-6b90-4c2a-9844-bebce0a32854	OUZ7074	MARCOPOLO	VOLARE V8L EO	ATIVO	2026-05-06 15:40:36.742414-03	2026-05-06 15:40:36.742414-03	93PB54M10EC049348	PROPRIO	ONIBUS
9d5d671d-9fd5-4fcd-a27a-c4d91704fbe6	OUZ5383	MARCOPOLO	VOLARE V8L EO	ATIVO	2026-05-06 15:48:58.7455-03	2026-05-06 15:48:58.7455-03	93PB55M1BEC049553	PROPRIO	MICRO_ONIBUS
53afecc8-8b0c-4372-9dc4-86e87d4d7aee	OUZ1639	MARCOPOLO	VOLARE	ATIVO	2026-05-07 08:39:05.693902-03	2026-05-07 08:39:05.693902-03	93PB55M10EC049550	PROPRIO	ONIBUS
c4bb98ae-b770-4303-80f2-6c969f85c205	OUX1811	MERCEDES	OF 1519 R.ORE	ATIVO	2026-05-07 08:49:34.884641-03	2026-05-07 08:49:34.884641-03	9BM384069EB923057	PROPRIO	ONIBUS
020650d7-65e4-4a3f-8086-b81627409e93	JSY6984	VOLSKWAGEN	8.150E DELIVERY	ATIVO	2026-05-07 09:00:50.90818-03	2026-05-07 09:00:50.90818-03	9531952P3AR018728	PROPRIO	CAMINHAO
3e5c4e1d-f72d-4146-bf05-78918e6093ee	NYJ9040	VOLSKWAGEN	KOMBI	ATIVO	2026-05-07 08:57:22.838143-03	2026-05-07 09:02:13.678316-03	9BWMF07XXBP012417	PROPRIO	VAN
e5ce2035-52de-4439-b2ff-946b14b16fc9	JSX-8119	VOLSKWAGEN	9.150E CUMMINS	ATIVO	2026-05-07 09:27:19.174835-03	2026-05-07 09:27:19.174835-03	9533A62R1AR008500	PROPRIO	CAMINHAO
52a0395e-da68-421f-885a-5a56cb279965	JSW8166	FIAT	UNO MILLE WAY ECON	ATIVO	2026-05-07 10:14:36.430233-03	2026-05-07 10:14:36.430233-03	9BD15844AA6398131	PROPRIO	HATCH
b626cbb5-9afe-41ba-a091-1c51af0c347f	JQJ4844	FIAT	UNO MILLE FIRE FLEX	ATIVO	2026-05-07 10:20:08.861582-03	2026-05-07 10:20:08.861582-03	9BD15822764695692	PROPRIO	HATCH
162ac9f5-14ed-4f2b-bdc5-356f108312ef	JOB-7263	MARCOPOLO	VOLARE LOTACAO	ATIVO	2026-05-07 10:22:10.133755-03	2026-05-07 10:22:10.133755-03	93PB02A2M2C007175	PROPRIO	ONIBUS
b01d4bc2-26b0-485a-ae91-e03f3de9af8e	TGZ5F58	IVECO	DAILY 55CS	ATIVO	2026-05-07 10:24:49.924243-03	2026-05-07 10:24:49.924243-03	93ZC653DZR8207554	PROPRIO	CAMINHAO
02c1c1be-cb8a-4e8a-8e76-3d2be467d44f	THA7J98	CHEVROLET	ONIX 10TAT HB	ATIVO	2026-05-07 10:30:55.482217-03	2026-05-07 10:30:55.482217-03	9BGEA48H0SG252197	PROPRIO	HATCH
847b4b9f-0737-4b1a-a917-4aed3f079beb	TMM2E05	VOLSKWAGEN	POLO TRACK MA	ATIVO	2026-05-07 10:37:19.286705-03	2026-05-07 10:37:19.286705-03	9BWAG5R19TP034383	PROPRIO	HATCH
5f48e555-5e61-47f4-afa1-aa7220e07d2f	JRV8415	VOLSKWAGEN	POLO SEDAN 1.6	ATIVO	2026-05-07 10:40:41.198821-03	2026-05-07 10:40:41.198821-03	9BWDB09N89P018203	PROPRIO	HATCH
bb065bfa-0fec-4912-866b-d8f83bc14808	TML4E34	CHEVROLET	SPIN 1.8L AT LTZ	ATIVO	2026-05-07 10:53:57.412157-03	2026-05-07 10:53:57.412157-03	9BGJC7520TB160873	PROPRIO	SUV
2d24caa9-0528-4a34-b542-fb139e4c25c8	TML-9I02	CHEVROLET	SPIN 1.8L AT LTZ	ATIVO	2026-05-07 10:32:57.722534-03	2026-05-07 10:56:01.765299-03	9BGJC7520TB160917	PROPRIO	SUV
c21808fa-1f48-41df-b18d-56de492b6105	TMM4H63	VOLSKWAGEN	POLO TRACK MA	ATIVO	2026-05-07 10:58:45.36138-03	2026-05-07 10:58:45.36138-03	9BWAG5R19TP031029	PROPRIO	HATCH
c2fe8306-0ba0-4919-b47e-2dda9615434d	SGP2G74	FIAT	TORO	ATIVO	2026-05-07 11:00:44.953278-03	2026-05-07 11:00:44.953278-03	01304931797	PROPRIO	PICAPE
dfaa49c3-e78e-426e-b24c-242ac7f3a741	TMM-3I71	VOLSKWAGEN	POLO TRACK MA	ATIVO	2026-05-07 11:01:02.396441-03	2026-05-07 11:01:02.396441-03	9BWAG5R15TP034932	PROPRIO	HATCH
9dde0e5f-b30d-4ea0-be4e-f962e56119e5	TMM-6A41	VOLSKWAGEN	POLO TRACK MA	ATIVO	2026-05-07 11:02:43.9266-03	2026-05-07 11:02:43.9266-03	9BWAG5R12TP034533	PROPRIO	HATCH
1cc10a16-c05a-49f1-aa9a-e41dc75a71ab	TMO3G39	FIAT	STRADA ENDURAN CS13	ATIVO	2026-05-07 11:04:40.866851-03	2026-05-07 11:04:40.866851-03	9BD281AJPTYBD9435	PROPRIO	PICAPE
a83cd43f-d0cf-48a0-8338-a5dad123dbef	PKU2611	FIAT	PALIO	ATIVO	2026-05-07 11:04:43.74397-03	2026-05-07 11:04:43.74397-03	01138901137	PROPRIO	HATCH
1d4d26b6-f2bc-46c7-91ef-ed40112872a5	PKU2414	FIAT	PALIO	ATIVO	2026-05-07 11:06:18.078955-03	2026-05-07 11:06:18.078955-03	01138904365	PROPRIO	HATCH
97f709fb-1dea-413e-8a76-8d0dbc556dab	TMM6B13	VOLSKWAGEN	POLO TRACK MA	ATIVO	2026-05-07 11:07:33.821582-03	2026-05-07 11:07:33.821582-03	9BWAG5R18TP034195	PROPRIO	HATCH
b676f18d-ad1f-4efd-a5c3-bcc49d3a67fc	PKU3846	FIAT	PALIO	ATIVO	2026-05-07 11:07:43.658968-03	2026-05-07 11:07:43.658968-03	01138899035	PROPRIO	HATCH
fa1c9c7d-97b2-44ae-9f81-e8512fbf629b	OZU0237	FIAT	DOBLO	ATIVO	2026-05-07 11:16:21.942509-03	2026-05-07 11:16:21.942509-03	01035410530	PROPRIO	PERUA_SW
46010cc1-0a0e-4bf7-8742-92d343ebff01	OZU1063	FIAT	DOBLO	ATIVO	2026-05-07 11:21:45.125117-03	2026-05-07 11:21:45.125117-03	01035712218	PROPRIO	PERUA_SW
d0801dc5-3768-4cf8-86e8-555e47f382ad	PKU5629	FIAT	PALIO	MANUTENCAO	2026-05-07 11:09:43.427932-03	2026-05-07 11:22:36.066023-03	01138904926	PROPRIO	HATCH
67549dd2-6f5f-4060-95d5-3e27cfb31d5e	OZU6658	FIAT	SIENA	ATIVO	2026-05-07 11:30:57.690671-03	2026-05-07 11:30:57.690671-03	01034595714	PROPRIO	SEDAN
7b3e5178-fdf9-41a8-ac1d-02f32e2c54f9	THF9F74	FIAT	STRADA	ATIVO	2026-05-07 11:34:38.806085-03	2026-05-07 11:34:38.806085-03	01455667908	PROPRIO	PICAPE
c5251949-6a19-4d2c-9a83-0c6fe7baf1f8	TMM3G09	HONDA	CG 160 STAR	ATIVO	2026-05-07 11:42:31.0588-03	2026-05-07 11:42:31.0588-03	01471530458	PROPRIO	MOTOCICLETA
7dffee07-fbfc-4ecd-a7fc-f3b39f9aea4a	TMM7H97	HONDA	CG 160 STAR	ATIVO	2026-05-07 14:21:41.817632-03	2026-05-07 14:21:41.817632-03	01472065880	PROPRIO	MOTOCICLETA
3249dd16-34ba-4066-9849-22418cb73ab8	TMQ9A59	RENAULT	MASTER TVAN	ATIVO	2026-05-07 14:22:12.879101-03	2026-05-07 14:22:12.879101-03	93YF62S02TJ512102	PROPRIO	MICRO_ONIBUS
2372e253-f9c6-42fa-bacc-c72736c42297	TMM3E51	HONDA	CG 160 STAR	ATIVO	2026-05-07 14:22:34.385635-03	2026-05-07 14:22:34.385635-03	01472261019	PROPRIO	MOTOCICLETA
dcdad9e1-ae16-47d3-90a2-364df75fd6fa	TMM7A65	HONDA	CG 160 STAR	ATIVO	2026-05-07 14:23:16.54674-03	2026-05-07 14:23:16.54674-03	01472259855	PROPRIO	MOTOCICLETA
82edf23e-e3e9-4cce-9fbf-73b8666d99a4	OZU 0307	HONDA	125 FAN ES	ATIVO	2026-05-07 14:27:09.347825-03	2026-05-07 14:27:09.347825-03	01035531140	PROPRIO	MOTOCICLETA
d4594709-2edd-49c0-9ef5-793fa00d0679	OZU 7466	HONDA	125 FAN ES	ATIVO	2026-05-07 14:28:00.103196-03	2026-05-07 14:28:00.103196-03	01035525051	PROPRIO	MOTOCICLETA
d16fe3df-dd43-4615-8dfc-04353dc30558	OZU 7622	HONDA	125 FAN ES	ATIVO	2026-05-07 14:28:47.906688-03	2026-05-07 14:28:47.906688-03	01035522826	PROPRIO	MOTOCICLETA
fc7d2025-da07-4d13-a50e-f4482ba86eb4	TMO1H35	FIAT	STRADA ENDURAN CS13	ATIVO	2026-05-07 14:29:32.257959-03	2026-05-07 14:29:32.257959-03	9BD281AJPTYBD8716	PROPRIO	PICAPE
4e889a19-42d1-4e8b-a0a9-a839f24c09bd	RPD5A72	FIAT	CRONOS	ATIVO	2026-05-07 14:30:13.773283-03	2026-05-07 14:30:13.773283-03	01298574673	PROPRIO	SEDAN
5b0cb3e0-428f-40af-8cc8-eb21d3838416	TMM6I18	HONDA	CG 160 START	ATIVO	2026-05-07 14:31:35.022112-03	2026-05-07 14:31:35.022112-03	9C2KC2500TR211698	PROPRIO	MOTOCICLETA
4eeb8891-d468-4299-8052-6204c49f8ad2	TML7G73	CHEV	SPIN 1.8L AT LTZ	ATIVO	2026-05-07 14:35:17.772998-03	2026-05-07 14:35:17.772998-03	9BGJC7520TB160794	PROPRIO	SEDAN
e5aa8a51-6018-4eb8-948d-e66a5bd2b8e3	TMN7C57	CHEV	ONIX 10TAT HB	ATIVO	2026-05-07 14:38:12.65109-03	2026-05-07 14:38:12.65109-03	9BGEA48H0TG105080	PROPRIO	HATCH
01fe46d0-c29b-4c8c-ae9b-fd85e5eeeedd	TMM0B49	HONDA	CG 160 START	ATIVO	2026-05-07 14:40:13.113543-03	2026-05-07 14:40:13.113543-03	9C2KC2500TR117406	PROPRIO	MOTOCICLETA
974b6e91-8c98-44d4-84b8-0d49ce8833a3	TMM9F25	HONDA	CG 160 START	ATIVO	2026-05-07 14:41:41.25006-03	2026-05-07 14:41:41.25006-03	9C2KC2500TR211971	PROPRIO	MOTOCICLETA
de1135a4-f534-40e7-b153-004e3f212742	TMM6I23	HONDA	CG 160 START	ATIVO	2026-05-07 14:43:30.425049-03	2026-05-07 14:43:30.425049-03	9C2KC2500TR211982	PROPRIO	MOTOCICLETA
7ab1872f-4613-4be0-bcb4-7c3689d4c803	TMM0F05	HONDA	CG 160 START	ATIVO	2026-05-07 14:44:51.841081-03	2026-05-07 14:44:51.841081-03	9C2KC2500TR211969	PROPRIO	MOTOCICLETA
25fec697-0605-4fed-82a9-63179025d466	TMM5A42	HONDA	CG 160 START	ATIVO	2026-05-07 14:47:17.915212-03	2026-05-07 14:47:17.915212-03	9C2KC2500TR211940	PROPRIO	MOTOCICLETA
dc999c35-28b0-47a8-97d4-5b37cd7289ff	TMM2E14	HONDA	CG 160 START	ATIVO	2026-05-07 14:48:43.921457-03	2026-05-07 14:48:43.921457-03	9C2KC2500TR116960	PROPRIO	MOTOCICLETA
44888801-13c0-4a70-8f0c-540b316ee675	TMM8I99	HONDA	CG 160 START	ATIVO	2026-05-07 14:51:37.811235-03	2026-05-07 14:51:37.811235-03	9C2KC2500TR116579	PROPRIO	MOTOCICLETA
3e19e069-02fc-448a-8e8d-8773fea67f01	TMM8J29	VW	POLO TRACK MA	ATIVO	2026-05-07 14:53:55.098133-03	2026-05-07 14:53:55.098133-03	9BWAG5R18TP034097	PROPRIO	HATCH
b964d75c-afae-4fb2-a1c9-974c41c2d995	TMN3C56	CHEV	ONIX 10TAT HB	ATIVO	2026-05-07 15:00:44.140793-03	2026-05-07 15:00:44.140793-03	9BGEA48H0TG124830	PROPRIO	HATCH
77b0f1ab-874e-4ddf-b2b2-6c5873c8906f	TMN8D21	CHEV	ONIX 10TAT HB	ATIVO	2026-05-07 15:02:34.564282-03	2026-05-07 15:02:34.564282-03	9BGEA48H0TG161821	PROPRIO	HATCH
d8a0948e-0c69-4193-877e-d0d81c97afe0	TMM2E09	VW	POLO TRACK MA	ATIVO	2026-05-07 15:11:42.1261-03	2026-05-07 15:11:42.1261-03	9BWAG5R11TP034281	PROPRIO	HATCH
50072ae4-d280-4b9e-b2d1-b22090b6d2c5	TMM8I03	VW	POLO TRACK MA	ATIVO	2026-05-07 15:16:34.342833-03	2026-05-07 15:16:34.342833-03	9BWAG5R13TP033245	PROPRIO	HATCH
fe1bc612-43dc-4d32-a369-14ed863ba554	TMM3F62	VW	POLO TRACK MA	ATIVO	2026-05-07 15:23:07.728787-03	2026-05-07 15:23:07.728787-03	9BWAG5R10TT022808	PROPRIO	HATCH
9cf59762-4171-4c1e-b552-4d7655935e6e	TMM7C41	VW	POLO TRACK MA	ATIVO	2026-05-07 15:24:36.689852-03	2026-05-07 15:24:36.689852-03	9BWAG5R19TP032939	PROPRIO	HATCH
123dc9e7-8bb6-4fbe-a632-31a95b0e181f	TMM0G98	VW	POLO TRACK MA	ATIVO	2026-05-07 15:26:25.76447-03	2026-05-07 15:26:25.76447-03	9BWAG5R13TP033469	PROPRIO	HATCH
097e3b6a-3a8d-45ff-91f4-999830e5da56	GTN8C49	CHEV	SPIN 18L AT PREMIER	ATIVO	2026-05-07 15:27:59.269238-03	2026-05-07 15:27:59.269238-03	9BGJP7520SB109004	PROPRIO	SEDAN
87ccee58-1d57-44aa-8ed1-ac8b14aa15f4	PLE5284	CITROEN	AIRCROSD	ATIVO	2026-05-07 15:33:57.802027-03	2026-05-07 15:33:57.802027-03	01162005960	PROPRIO	SUV
6d4b0667-a7b5-4e90-9b2e-9fed98054048	TMQ8A63	RENAULT	MASTER TVAN	ATIVO	2026-05-07 15:35:15.001318-03	2026-05-07 15:35:15.001318-03	93YF62S00TJ512101	PROPRIO	VAN
2dbdd1ef-e0fe-4b96-ad04-e89dec4f7159	GTN8C65	CHEVROLET	SPIN	ATIVO	2026-05-07 15:39:00.781396-03	2026-05-07 15:39:00.781396-03	01387925013	LOCADO	SUV
\.


--
-- Name: admin_notifications admin_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_notifications
    ADD CONSTRAINT admin_notifications_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: claims claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_pkey PRIMARY KEY (id);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: fines fines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fines
    ADD CONSTRAINT fines_pkey PRIMARY KEY (id);


--
-- Name: fleet_analytics_snapshots fleet_analytics_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_analytics_snapshots
    ADD CONSTRAINT fleet_analytics_snapshots_pkey PRIMARY KEY (id);


--
-- Name: fuel_station_users fuel_station_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_station_users
    ADD CONSTRAINT fuel_station_users_pkey PRIMARY KEY (id);


--
-- Name: fuel_stations fuel_stations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_stations
    ADD CONSTRAINT fuel_stations_pkey PRIMARY KEY (id);


--
-- Name: fuel_supplies fuel_supplies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supplies
    ADD CONSTRAINT fuel_supplies_pkey PRIMARY KEY (id);


--
-- Name: fuel_supply_orders fuel_supply_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_pkey PRIMARY KEY (id);


--
-- Name: location_history location_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_history
    ADD CONSTRAINT location_history_pkey PRIMARY KEY (id);


--
-- Name: maintenance_records maintenance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_pkey PRIMARY KEY (id);


--
-- Name: master_allocations master_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_allocations
    ADD CONSTRAINT master_allocations_pkey PRIMARY KEY (id);


--
-- Name: master_departments master_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_departments
    ADD CONSTRAINT master_departments_pkey PRIMARY KEY (id);


--
-- Name: master_organizations master_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_organizations
    ADD CONSTRAINT master_organizations_pkey PRIMARY KEY (id);


--
-- Name: fuel_station_users uq_fuel_station_users_user_station; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_station_users
    ADD CONSTRAINT uq_fuel_station_users_user_station UNIQUE (user_id, fuel_station_id);


--
-- Name: fuel_stations uq_fuel_stations_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_stations
    ADD CONSTRAINT uq_fuel_stations_name UNIQUE (name);


--
-- Name: master_allocations uq_master_allocations_department_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_allocations
    ADD CONSTRAINT uq_master_allocations_department_name UNIQUE (department_id, name);


--
-- Name: master_departments uq_master_departments_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_departments
    ADD CONSTRAINT uq_master_departments_org_name UNIQUE (organization_id, name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vehicle_possession_photos vehicle_possession_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_possession_photos
    ADD CONSTRAINT vehicle_possession_photos_pkey PRIMARY KEY (id);


--
-- Name: vehicle_possession vehicle_possession_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_possession
    ADD CONSTRAINT vehicle_possession_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: idx_admin_notifications_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_notifications_created_at ON public.admin_notifications USING btree (created_at);


--
-- Name: idx_admin_notifications_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_notifications_event_type ON public.admin_notifications USING btree (event_type);


--
-- Name: idx_admin_notifications_read_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_notifications_read_at ON public.admin_notifications USING btree (read_at);


--
-- Name: idx_claims_data; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_claims_data ON public.claims USING btree (data_ocorrencia);


--
-- Name: idx_claims_driver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_claims_driver ON public.claims USING btree (driver_id);


--
-- Name: idx_claims_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_claims_status ON public.claims USING btree (status);


--
-- Name: idx_claims_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_claims_vehicle ON public.claims USING btree (vehicle_id);


--
-- Name: idx_drivers_ativo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drivers_ativo ON public.drivers USING btree (ativo) WHERE (ativo = true);


--
-- Name: idx_drivers_documento; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drivers_documento ON public.drivers USING btree (documento);


--
-- Name: idx_drivers_nome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drivers_nome ON public.drivers USING btree (nome_completo);


--
-- Name: idx_fines_driver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fines_driver ON public.fines USING btree (driver_id);


--
-- Name: idx_fines_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fines_due_date ON public.fines USING btree (due_date);


--
-- Name: idx_fines_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fines_status ON public.fines USING btree (status);


--
-- Name: idx_fines_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fines_vehicle ON public.fines USING btree (vehicle_id);


--
-- Name: idx_fleet_analytics_snapshot_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fleet_analytics_snapshot_created ON public.fleet_analytics_snapshots USING btree (created_at);


--
-- Name: idx_fleet_analytics_snapshot_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fleet_analytics_snapshot_period ON public.fleet_analytics_snapshots USING btree (period_start, period_end);


--
-- Name: idx_fleet_analytics_snapshot_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fleet_analytics_snapshot_scope ON public.fleet_analytics_snapshots USING btree (vehicle_type, vehicle_id, driver_id);


--
-- Name: idx_fuel_station_users_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_station_users_active ON public.fuel_station_users USING btree (active);


--
-- Name: idx_fuel_station_users_station; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_station_users_station ON public.fuel_station_users USING btree (fuel_station_id);


--
-- Name: idx_fuel_station_users_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_station_users_user ON public.fuel_station_users USING btree (user_id);


--
-- Name: idx_fuel_stations_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_stations_active ON public.fuel_stations USING btree (active);


--
-- Name: idx_fuel_stations_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_stations_name ON public.fuel_stations USING btree (name);


--
-- Name: idx_fuel_supplies_anomaly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_anomaly ON public.fuel_supplies USING btree (is_consumption_anomaly);


--
-- Name: idx_fuel_supplies_driver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_driver ON public.fuel_supplies USING btree (driver_id);


--
-- Name: idx_fuel_supplies_fuel_station_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_fuel_station_id ON public.fuel_supplies USING btree (fuel_station_id);


--
-- Name: idx_fuel_supplies_organization; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_organization ON public.fuel_supplies USING btree (organization_id);


--
-- Name: idx_fuel_supplies_supplied_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_supplied_at ON public.fuel_supplies USING btree (supplied_at);


--
-- Name: idx_fuel_supplies_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_vehicle ON public.fuel_supplies USING btree (vehicle_id);


--
-- Name: idx_fuel_supply_orders_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supply_orders_expires_at ON public.fuel_supply_orders USING btree (expires_at);


--
-- Name: idx_fuel_supply_orders_fuel_station_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supply_orders_fuel_station_id ON public.fuel_supply_orders USING btree (fuel_station_id);


--
-- Name: idx_fuel_supply_orders_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supply_orders_organization_id ON public.fuel_supply_orders USING btree (organization_id);


--
-- Name: idx_fuel_supply_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supply_orders_status ON public.fuel_supply_orders USING btree (status);


--
-- Name: idx_fuel_supply_orders_validation_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_fuel_supply_orders_validation_code ON public.fuel_supply_orders USING btree (validation_code);


--
-- Name: idx_fuel_supply_orders_vehicle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supply_orders_vehicle_id ON public.fuel_supply_orders USING btree (vehicle_id);


--
-- Name: idx_maintenance_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maintenance_created_by ON public.maintenance_records USING btree (created_by);


--
-- Name: idx_maintenance_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maintenance_dates ON public.maintenance_records USING btree (start_date, end_date);


--
-- Name: idx_maintenance_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maintenance_vehicle ON public.maintenance_records USING btree (vehicle_id);


--
-- Name: idx_possession_driver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_possession_driver ON public.vehicle_possession USING btree (driver_name);


--
-- Name: idx_possession_photo_possession; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_possession_photo_possession ON public.vehicle_possession_photos USING btree (possession_id);


--
-- Name: idx_possession_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_possession_vehicle ON public.vehicle_possession USING btree (vehicle_id);


--
-- Name: ix_location_history_allocation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_location_history_allocation_id ON public.location_history USING btree (allocation_id);


--
-- Name: ix_location_history_vehicle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_location_history_vehicle_id ON public.location_history USING btree (vehicle_id);


--
-- Name: ix_master_allocations_department_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_master_allocations_department_id ON public.master_allocations USING btree (department_id);


--
-- Name: ix_master_departments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_master_departments_organization_id ON public.master_departments USING btree (organization_id);


--
-- Name: ix_master_organizations_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_master_organizations_name ON public.master_organizations USING btree (name);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_vehicle_possession_driver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_possession_driver_id ON public.vehicle_possession USING btree (driver_id);


--
-- Name: ix_vehicles_chassis_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_vehicles_chassis_number ON public.vehicles USING btree (chassis_number);


--
-- Name: ix_vehicles_plate; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_vehicles_plate ON public.vehicles USING btree (plate);


--
-- Name: uq_drivers_documento_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_drivers_documento_active ON public.drivers USING btree (documento) WHERE (ativo = true);


--
-- Name: uq_possession_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_possession_active ON public.vehicle_possession USING btree (vehicle_id) WHERE (end_date IS NULL);


--
-- Name: claims trg_claims_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_claims_updated_at BEFORE UPDATE ON public.claims FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: drivers trg_drivers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_drivers_updated_at BEFORE UPDATE ON public.drivers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fines trg_fines_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fines_updated_at BEFORE UPDATE ON public.fines FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fuel_station_users trg_fuel_station_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fuel_station_users_updated_at BEFORE UPDATE ON public.fuel_station_users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fuel_stations trg_fuel_stations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fuel_stations_updated_at BEFORE UPDATE ON public.fuel_stations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fuel_supplies trg_fuel_supplies_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fuel_supplies_updated_at BEFORE UPDATE ON public.fuel_supplies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fuel_supply_orders trg_fuel_supply_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fuel_supply_orders_updated_at BEFORE UPDATE ON public.fuel_supply_orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: maintenance_records trg_maintenance_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_maintenance_updated_at BEFORE UPDATE ON public.maintenance_records FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: master_allocations trg_master_allocations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_master_allocations_updated_at BEFORE UPDATE ON public.master_allocations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: master_departments trg_master_departments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_master_departments_updated_at BEFORE UPDATE ON public.master_departments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: master_organizations trg_master_organizations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_master_organizations_updated_at BEFORE UPDATE ON public.master_organizations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users trg_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: vehicles trg_vehicles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_vehicles_updated_at BEFORE UPDATE ON public.vehicles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: audit_logs audit_logs_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: claims claims_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: claims claims_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: claims claims_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: fines fines_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fines
    ADD CONSTRAINT fines_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: fines fines_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fines
    ADD CONSTRAINT fines_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: fines fines_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fines
    ADD CONSTRAINT fines_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: fuel_supplies fk_fuel_supplies_fuel_station_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supplies
    ADD CONSTRAINT fk_fuel_supplies_fuel_station_id FOREIGN KEY (fuel_station_id) REFERENCES public.fuel_stations(id) ON DELETE SET NULL;


--
-- Name: location_history fk_location_history_allocation; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_history
    ADD CONSTRAINT fk_location_history_allocation FOREIGN KEY (allocation_id) REFERENCES public.master_allocations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fleet_analytics_snapshots fleet_analytics_snapshots_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_analytics_snapshots
    ADD CONSTRAINT fleet_analytics_snapshots_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: fleet_analytics_snapshots fleet_analytics_snapshots_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_analytics_snapshots
    ADD CONSTRAINT fleet_analytics_snapshots_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: fuel_station_users fuel_station_users_fuel_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_station_users
    ADD CONSTRAINT fuel_station_users_fuel_station_id_fkey FOREIGN KEY (fuel_station_id) REFERENCES public.fuel_stations(id) ON DELETE CASCADE;


--
-- Name: fuel_station_users fuel_station_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_station_users
    ADD CONSTRAINT fuel_station_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fuel_supplies fuel_supplies_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supplies
    ADD CONSTRAINT fuel_supplies_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: fuel_supplies fuel_supplies_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supplies
    ADD CONSTRAINT fuel_supplies_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.master_organizations(id) ON DELETE SET NULL;


--
-- Name: fuel_supplies fuel_supplies_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supplies
    ADD CONSTRAINT fuel_supplies_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: fuel_supply_orders fuel_supply_orders_confirmed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_confirmed_by_user_id_fkey FOREIGN KEY (confirmed_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: fuel_supply_orders fuel_supply_orders_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: fuel_supply_orders fuel_supply_orders_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: fuel_supply_orders fuel_supply_orders_fuel_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_fuel_station_id_fkey FOREIGN KEY (fuel_station_id) REFERENCES public.fuel_stations(id) ON DELETE SET NULL;


--
-- Name: fuel_supply_orders fuel_supply_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.master_organizations(id) ON DELETE SET NULL;


--
-- Name: fuel_supply_orders fuel_supply_orders_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: location_history location_history_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_history
    ADD CONSTRAINT location_history_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: maintenance_records maintenance_records_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: maintenance_records maintenance_records_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: master_allocations master_allocations_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_allocations
    ADD CONSTRAINT master_allocations_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.master_departments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: master_departments master_departments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_departments
    ADD CONSTRAINT master_departments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.master_organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_possession vehicle_possession_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_possession
    ADD CONSTRAINT vehicle_possession_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: vehicle_possession_photos vehicle_possession_photos_possession_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_possession_photos
    ADD CONSTRAINT vehicle_possession_photos_possession_id_fkey FOREIGN KEY (possession_id) REFERENCES public.vehicle_possession(id) ON DELETE CASCADE;


--
-- Name: vehicle_possession vehicle_possession_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_possession
    ADD CONSTRAINT vehicle_possession_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict tSPxoXsmBYC1alAReylyajV1SOh4GEN8iI2lxz9gRx8BthHEBBk3dLOdwlxIH8a


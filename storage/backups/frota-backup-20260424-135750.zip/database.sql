--
-- PostgreSQL database dump
--

\restrict faXPsxGvt0boNEDOmgyc05rgOaFMGhHoEzt7mmvuROaoRVuO3UD7wiDNGO4bQdw

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: claim_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.claim_status AS ENUM (
    'ABERTO',
    'EM_ANALISE',
    'ENCERRADO'
);


--
-- Name: claim_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.claim_type AS ENUM (
    'COLISAO',
    'ROUBO',
    'FURTO',
    'AVARIA',
    'OUTRO'
);


--
-- Name: driver_license_category; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.driver_license_category AS ENUM (
    'A',
    'B',
    'C',
    'D',
    'E'
);


--
-- Name: fine_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.fine_status AS ENUM (
    'PENDENTE',
    'PAGA',
    'RECURSO'
);


--
-- Name: fuel_supply_order_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.fuel_supply_order_status AS ENUM (
    'OPEN',
    'EXPIRED',
    'COMPLETED',
    'CANCELLED'
);


--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role AS ENUM (
    'ADMIN',
    'PADRAO',
    'PRODUCAO',
    'POSTO'
);


--
-- Name: vehicle_ownership_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vehicle_ownership_type AS ENUM (
    'PROPRIO',
    'LOCADO',
    'CEDIDO'
);


--
-- Name: vehicle_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vehicle_status AS ENUM (
    'ATIVO',
    'MANUTENCAO',
    'INATIVO'
);


--
-- Name: vehicle_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.vehicle_type AS ENUM (
    'SEDAN',
    'HATCH',
    'PICAPE',
    'SUV',
    'PERUA_SW',
    'VAN',
    'MICRO_ONIBUS',
    'ONIBUS',
    'CAMINHAO',
    'MOTOCICLETA',
    'MAQUINA'
);


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            NEW.updated_at = NOW();
            RETURN NEW;
        END;
        $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(180) NOT NULL,
    message text NOT NULL,
    event_type character varying(80) NOT NULL,
    severity character varying(20) DEFAULT 'INFO'::character varying NOT NULL,
    payload jsonb,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_user_id uuid,
    actor_name character varying(150) NOT NULL,
    actor_email character varying(255),
    actor_role character varying(30),
    action character varying(30) NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id uuid NOT NULL,
    entity_label character varying(255) NOT NULL,
    details jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.claims (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    data_ocorrencia timestamp with time zone NOT NULL,
    tipo public.claim_type NOT NULL,
    descricao text NOT NULL,
    local character varying(200) NOT NULL,
    boletim_ocorrencia character varying(50),
    valor_estimado numeric(12,2),
    status public.claim_status DEFAULT 'ABERTO'::public.claim_status NOT NULL,
    justificativa_encerramento text,
    anexos jsonb,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_claims_valor_estimado_non_negative CHECK ((valor_estimado >= (0)::numeric))
);


--
-- Name: drivers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drivers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    nome_completo character varying(150) NOT NULL,
    documento character varying(20) NOT NULL,
    contato character varying(50),
    email public.citext,
    cnh_categoria public.driver_license_category NOT NULL,
    cnh_validade date,
    ativo boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fines (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    ticket_number character varying(50) NOT NULL,
    infraction_date date NOT NULL,
    due_date date,
    amount numeric(12,2) NOT NULL,
    description text NOT NULL,
    location character varying(200),
    status public.fine_status DEFAULT 'PENDENTE'::public.fine_status NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_fines_amount_non_negative CHECK ((amount >= (0)::numeric))
);


--
-- Name: fleet_analytics_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fleet_analytics_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    vehicle_id uuid,
    driver_id uuid,
    vehicle_type character varying(40) NOT NULL,
    scope character varying(30) DEFAULT 'VEHICLE'::character varying NOT NULL,
    total_km double precision DEFAULT 0 NOT NULL,
    total_liters double precision DEFAULT 0 NOT NULL,
    fuel_cost numeric(12,2) DEFAULT 0 NOT NULL,
    maintenance_cost numeric(12,2) DEFAULT 0 NOT NULL,
    fines_cost numeric(12,2) DEFAULT 0 NOT NULL,
    consumption_l_100km double precision,
    tco_cost_per_km double precision,
    driver_risk_score double precision,
    anomalies_count integer DEFAULT 0 NOT NULL,
    category_average_consumption double precision,
    category_average_tco double precision,
    market_benchmark_tco double precision,
    extra_payload jsonb,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fuel_station_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fuel_station_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    fuel_station_id uuid NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: fuel_stations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fuel_stations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(180) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    cnpj character varying(18),
    address character varying(255) NOT NULL
);


--
-- Name: fuel_supplies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fuel_supplies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    organization_id uuid,
    supplied_at timestamp with time zone DEFAULT now() NOT NULL,
    odometer_km double precision NOT NULL,
    liters double precision NOT NULL,
    total_amount numeric(12,2),
    fuel_station character varying(180),
    notes text,
    consumption_km_l double precision,
    is_consumption_anomaly boolean DEFAULT false NOT NULL,
    anomaly_details text,
    receipt_path character varying(255) NOT NULL,
    receipt_mime_type character varying(100) NOT NULL,
    receipt_size_bytes integer NOT NULL,
    receipt_uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    fuel_station_id uuid,
    CONSTRAINT ck_fuel_supplies_amount_non_negative CHECK (((total_amount IS NULL) OR (total_amount >= (0)::numeric))),
    CONSTRAINT ck_fuel_supplies_liters_positive CHECK ((liters > (0)::double precision)),
    CONSTRAINT ck_fuel_supplies_odometer_positive CHECK ((odometer_km > (0)::double precision))
);


--
-- Name: fuel_supply_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fuel_supply_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_id uuid,
    organization_id uuid,
    fuel_station_id uuid,
    status public.fuel_supply_order_status DEFAULT 'OPEN'::public.fuel_supply_order_status NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '48:00:00'::interval) NOT NULL,
    created_by_user_id uuid NOT NULL,
    confirmed_by_user_id uuid,
    requested_liters numeric(10,3),
    max_amount numeric(12,2),
    notes text,
    confirmed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    validation_code character varying(24) NOT NULL,
    CONSTRAINT ck_fuel_supply_orders_max_amount_non_negative CHECK (((max_amount IS NULL) OR (max_amount >= (0)::numeric))),
    CONSTRAINT ck_fuel_supply_orders_requested_liters_positive CHECK (((requested_liters IS NULL) OR (requested_liters > (0)::numeric)))
);


--
-- Name: location_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.location_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    department character varying(255) NOT NULL,
    start_date timestamp with time zone DEFAULT now() NOT NULL,
    end_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    allocation_id uuid,
    justification character varying(500)
);


--
-- Name: maintenance_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone,
    service_description text NOT NULL,
    parts_replaced text,
    total_cost numeric(12,2) NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_total_cost_non_negative CHECK ((total_cost >= (0)::numeric))
);


--
-- Name: master_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_allocations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    department_id uuid NOT NULL,
    name character varying(150) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_departments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    organization_id uuid NOT NULL,
    name character varying(150) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: master_organizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.master_organizations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(150) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(150) NOT NULL,
    email public.citext NOT NULL,
    password_hash character varying(255) NOT NULL,
    role public.user_role DEFAULT 'PADRAO'::public.user_role NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vehicle_possession; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_possession (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    vehicle_id uuid NOT NULL,
    driver_name character varying(150) NOT NULL,
    driver_document character varying(20),
    driver_contact character varying(50),
    start_date timestamp with time zone DEFAULT now() NOT NULL,
    end_date timestamp with time zone,
    observation text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    photo_path character varying(255),
    photo_mime_type character varying(100),
    photo_size_bytes integer,
    photo_captured_at timestamp with time zone,
    capture_latitude double precision,
    capture_longitude double precision,
    capture_accuracy_meters double precision,
    document_path character varying(255),
    document_name character varying(255),
    document_mime_type character varying(120),
    document_size_bytes integer,
    document_uploaded_at timestamp with time zone,
    driver_id uuid,
    start_odometer_km double precision,
    end_odometer_km double precision
);


--
-- Name: vehicle_possession_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_possession_photos (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    possession_id uuid NOT NULL,
    photo_path character varying(255) NOT NULL,
    photo_mime_type character varying(100) NOT NULL,
    photo_size_bytes integer NOT NULL,
    photo_captured_at timestamp with time zone,
    capture_latitude double precision,
    capture_longitude double precision,
    capture_accuracy_meters double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plate character varying(20) NOT NULL,
    brand character varying(50) NOT NULL,
    model character varying(50) NOT NULL,
    status public.vehicle_status DEFAULT 'ATIVO'::public.vehicle_status NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    chassis_number character varying(50),
    ownership_type public.vehicle_ownership_type DEFAULT 'PROPRIO'::public.vehicle_ownership_type NOT NULL,
    vehicle_type public.vehicle_type DEFAULT 'SEDAN'::public.vehicle_type NOT NULL
);


--
-- Data for Name: admin_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_notifications (id, title, message, event_type, severity, payload, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
0022_fuel_order_public_code
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, actor_user_id, actor_name, actor_email, actor_role, action, entity_type, entity_id, entity_label, details, created_at) FROM stdin;
9853c07f-8700-4e67-9ad3-1b7888857d53	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	CREATE	USER	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	jonatas.sousa@pm.teixeiradefreitas.ba.gov.br	{"name": "Jonatas da Silva Sousa", "role": "ADMIN", "email": "jonatas.sousa@pm.teixeiradefreitas.ba.gov.br"}	2026-04-09 15:51:27.86796-03
4fca3650-7f86-49bd-a177-3d241af3712b	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	USER	065b1e0b-527b-4b65-8a62-008851a22f96	naldorsantosfilho@gmail.com	{"after": {"name": "Arnaldo Rosa dos Santos Filho", "role": "ADMIN", "email": "naldorsantosfilho@gmail.com", "password_changed": true}, "before": {"name": "Arnaldo Rosa dos Santos Filho", "role": "ADMIN", "email": "arnaldo@frota.sirel.com.br"}}	2026-04-09 16:12:24.73918-03
2bf26fe8-7113-436f-8330-b01c6c427c33	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	25a32053-e488-4cfc-8584-deff13f3c926	ABC-1D23 - Joao Silva	{"event": "END_POSSESSION", "end_date": "2026-04-09T22:12:00+00:00", "observation": "Motorista designado para rota norte"}	2026-04-09 16:12:53.573145-03
1bc80d17-bfb1-4a2b-b23d-15817a283123	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas.sousa@pm.teixeiradefreitas.ba.gov.br	ADMIN	CREATE	USER	f2ba72df-6b24-41d5-9fa5-4d947672c8d7	carlos@h	{"name": "Carlos Henrique Cruz Honorato", "role": "PADRAO", "email": "carlos@h"}	2026-04-09 16:25:53.196853-03
715fb29a-bb80-4141-b029-5df08daf6ace	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	USER	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	jonatas@sousa	{"after": {"name": "Jonatas da Silva Sousa", "role": "ADMIN", "email": "jonatas@sousa", "password_changed": false}, "before": {"name": "Jonatas da Silva Sousa", "role": "ADMIN", "email": "jonatas.sousa@pm.teixeiradefreitas.ba.gov.br"}}	2026-04-09 16:37:31.621877-03
7df7e5a8-6a20-49b0-a0a8-d813bd53f144	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	USER	f2ba72df-6b24-41d5-9fa5-4d947672c8d7	carlos@h	{"after": {"name": "Carlos Henrique Cruz Honorato", "role": "PRODUCAO", "email": "carlos@h", "password_changed": false}, "before": {"name": "Carlos Henrique Cruz Honorato", "role": "PADRAO", "email": "carlos@h"}}	2026-04-09 16:37:50.448668-03
c7aa2845-6932-46a2-a456-c3d775b2e26c	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	POSSESSION	964bb112-ff1e-49ff-b133-021679ef8383	ABC-1D23 - Jonatas	{"start_date": "2026-04-10T15:07:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Testes", "driver_contact": "7312345678", "driver_document": "1234567890", "photo_mime_type": "image/jpeg", "photo_size_bytes": 242332, "photo_captured_at": "2026-04-10T12:07:55.653000+00:00", "capture_accuracy_meters": 11.880999565124512, "evidence_photo_attached": true}	2026-04-10 09:08:02.95233-03
ae5748d5-d7bc-4682-81ab-3e77c9ae559e	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	POSSESSION	30c39aae-142e-47c7-95b1-0b0cdf7a3af5	ABC-1D23 - Carlos	{"start_date": "2026-04-10T15:19:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Teste 02", "driver_contact": "7312345678", "driver_document": "1234567890", "photo_mime_type": "image/jpeg", "photo_size_bytes": 128052, "photo_captured_at": "2026-04-10T12:20:01.486000+00:00", "capture_accuracy_meters": 11.47700023651123, "evidence_photo_attached": true}	2026-04-10 09:20:07.322326-03
d0121a61-14f3-45d1-b923-f453a47662c3	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	POSSESSION	effade1b-30a9-4bb2-8070-fa2dfb4a1eeb	ABC-1D23 - Jonatas	{"event": "END_POSSESSION", "end_date": "2026-04-10T15:29:00+00:00", "observation": "teste 03"}	2026-04-10 09:29:33.193823-03
e0579395-a02e-4b64-b01f-74bd7cbdeba6	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	ORGANIZATION	9d68dcc7-a43b-4e27-9961-7929cf691b17	Secretaria de Infraestrutura e Serviços Urbanos	{"after": {"name": "Secretaria de Infraestrutura e Serviços Urbanos"}, "before": {"name": "Secretaria de Infraestrutura"}}	2026-04-10 14:41:14.397968-03
aaf303c2-3887-477c-bb73-af4441ebee4a	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	90332997-e801-44ba-be90-c2fa126053ea	Secretaria de Educacao	{"name": "Secretaria de Educacao"}	2026-04-10 14:41:36.159933-03
21640068-d4d0-4b31-95c9-4f7264875606	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	ORGANIZATION	90332997-e801-44ba-be90-c2fa126053ea	Secretaria de Educação	{"after": {"name": "Secretaria de Educação"}, "before": {"name": "Secretaria de Educacao"}}	2026-04-10 14:41:45.602737-03
3bd4e249-ae75-402f-a5fa-8c2957707ce7	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	ORGANIZATION	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Secretaria de Administração	{"after": {"name": "Secretaria de Administração"}, "before": {"name": "Secretaria de Administracao"}}	2026-04-10 14:41:52.177801-03
3bf7d60d-9cf7-45eb-a48b-99cd89f029fa	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	ORGANIZATION	891b49ea-abf4-4501-9ef6-23fb78c42d25	Secretaria de Saúde	{"after": {"name": "Secretaria de Saúde"}, "before": {"name": "Secretaria de Saude"}}	2026-04-10 14:41:59.519107-03
4882e942-a453-4931-8c74-31a8679cef8f	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	e6a79f0d-d2bf-4e00-bc6d-9294a5b0da7e	Controladoria Geral do Município	{"name": "Controladoria Geral do Município"}	2026-04-10 14:42:38.708471-03
f37d8b29-7635-4bd5-90b8-cd34fc962038	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	471860e8-fe57-4181-bb14-cf3098787905	Gabiente do Prefeito	{"name": "Gabiente do Prefeito"}	2026-04-10 14:42:45.400331-03
48323c9d-2f05-4ca9-8cec-bd161da90903	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	4fdeb45a-dca4-4dcf-93d0-08e24663e09a	Procuradoria Geral do Município	{"name": "Procuradoria Geral do Município"}	2026-04-10 14:43:01.690231-03
463deda4-9629-4a85-a416-e80e7c4b4ae4	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	dbae7e55-4e04-4c38-9128-a88c98b12160	Secretaria de Agricultura Pecuária e Abastecimento	{"name": "Secretaria de Agricultura Pecuária e Abastecimento"}	2026-04-10 14:43:19.225392-03
b4cf4f0f-ce53-4928-ae40-1f296619de6e	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	12375ce0-6f93-43b7-97df-787218d6ff37	Secretaria de Cultura e Turismo	{"name": "Secretaria de Cultura e Turismo"}	2026-04-10 14:43:37.811732-03
b0931fb1-5e30-47af-8dec-01dd2557e1e0	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	72c067bf-d9f7-4f8d-b8c0-ce45d1713025	Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia	{"name": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia"}	2026-04-10 14:44:01.635346-03
c4fc57fa-480c-46cd-b5fd-29af7f70cd45	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	c191b61f-81f7-45ef-825f-fe6a50de9be1	Secretaria de Esporte e Lazer	{"name": "Secretaria de Esporte e Lazer"}	2026-04-10 14:44:16.800864-03
75611c90-22ce-49ee-9f40-92dbc9ef55a4	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	f6dc3ca5-886b-4667-b0ca-536c4a0bfe97	Secretaria de Finanças	{"name": "Secretaria de Finanças"}	2026-04-10 14:44:25.083012-03
586aaf95-217a-4045-83b4-41e478f501d1	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	3b697c38-9278-4b7a-a653-ff985f47a2a6	Secretaria de Habitação	{"name": "Secretaria de Habitação"}	2026-04-10 14:44:44.853436-03
dd877d25-95b4-4864-b4e2-77ca709d521b	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	98a656ae-7517-408c-a997-454a7f7007d2	Secretaria de Meio Ambiente	{"name": "Secretaria de Meio Ambiente"}	2026-04-10 14:45:01.698856-03
1f3d2f06-8172-4be4-92be-5f5f297ea9d2	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	555db8bb-6f86-437e-bb3b-a047a826ac34	Secretaria de Projetos Estratégicos e Gerenciamento de Convênios	{"name": "Secretaria de Projetos Estratégicos e Gerenciamento de Convênios"}	2026-04-10 15:07:33.484142-03
d5b4c923-45ad-4a12-b27b-9c2a7b60fd0c	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	6acb9d5d-599a-4e3e-9f67-932c561cbacb	Secretaria de Promoção Social	{"name": "Secretaria de Promoção Social"}	2026-04-10 15:08:53.789257-03
51a161a1-63eb-4d79-8d4a-9ee8e269914f	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ORGANIZATION	02708937-9e4d-4387-851b-7a49957405e2	Secretaria de Segurança e Transporte	{"name": "Secretaria de Segurança e Transporte"}	2026-04-10 15:09:14.627433-03
d86a1620-8c99-43cb-a417-af07ef3d844c	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	DEPARTMENT	8f8b0bde-a014-47f9-a2b7-de616bcca58d	Departamento Administrativo	{"after": {"name": "Departamento Administrativo", "organization": "Secretaria de Administração"}, "before": {"name": "Gestao Administrativa", "organization": "Secretaria de Administração"}}	2026-04-10 16:57:52.211385-03
e4c55ab9-0cd7-4c5f-a0d0-f0dded9d4b1d	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	DEPARTMENT	9c5a3de4-107e-444f-a840-d7d2a528190f	Departamento Administrativo	{"after": {"name": "Departamento Administrativo", "organization": "Secretaria de Saúde"}, "before": {"name": "Transporte", "organization": "Secretaria de Saúde"}}	2026-04-10 16:58:21.905167-03
b6cfe597-360d-4cb3-bddf-27e5452c4faf	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	DEPARTMENT	dd141042-2a72-4d8e-b8f1-69eb11d83532	Departamento Administrativo	{"after": {"name": "Departamento Administrativo", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}, "before": {"name": "Oficina", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}}	2026-04-10 16:58:10.893833-03
c9274352-e75b-4c23-8618-e44f212da74e	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	VEHICLE	829c4a2b-db47-4541-bffe-c2443a2ffbdd	ABC-1D23	{"after": {"brand": "Ford", "model": "Ka", "plate": "ABC-1D23", "status": "ATIVO", "location": "Secretaria de Saúde - Departamento Administrativo - Patio Municipal", "chassis_number": "9BFZH55L0G1234567", "ownership_type": "PROPRIO"}, "before": {"brand": "Ford", "model": "Ka", "plate": "ABC-1D23", "status": "ATIVO", "location": "Secretaria de Administração - Departamento Administrativo - Garagem Central", "chassis_number": "9BFZH55L0G1234567", "ownership_type": "PROPRIO"}}	2026-04-10 17:05:40.513084-03
062dfc59-b65d-426e-a087-720328cecf77	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	CREATE	POSSESSION	359f97fa-26dd-40a2-9ac3-a42839d861e9	ABC-1D23 - Teste Documento	{"start_date": "2026-04-10T21:12:09.901595+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Teste com documento anexado", "driver_contact": "73999999999", "driver_document": "12345678900", "photo_mime_type": "image/png", "photo_size_bytes": 43867, "photo_captured_at": "2026-04-10T18:30:00+00:00", "signed_document_name": "termo-assinado.pdf", "capture_accuracy_meters": 12.0, "evidence_photo_attached": true, "signed_document_attached": true, "signed_document_mime_type": "application/pdf", "signed_document_size_bytes": 44}	2026-04-10 18:12:09.893927-03
f900c0f5-b571-4dd2-8164-14d8f2d9c309	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	CREATE	USER	08d425de-0052-42b1-95ab-b3178cde1e30	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	{"name": "WANDERSON SOUSA LIMAS", "role": "PRODUCAO", "email": "wanderson.limas@pm.teixeiradefreitas.ba.gov.br"}	2026-04-10 18:15:06.747474-03
362b3ca4-1807-4986-8bf7-b71a2ff45144	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	effade1b-30a9-4bb2-8070-fa2dfb4a1eeb	ABC-1D23 - Jonatas	{"after": {"end_date": "2026-04-10T15:29:00+00:00", "start_date": "2026-04-10T15:21:00+00:00", "driver_name": "Jonatas", "observation": "teste 03 | validacao-admin", "driver_contact": "7312345678", "driver_document": "1234567890"}, "event": "ADMIN_EDIT", "before": {"end_date": "2026-04-10T15:29:00+00:00", "start_date": "2026-04-10T15:21:00+00:00", "driver_name": "Jonatas", "observation": "teste 03", "driver_contact": "7312345678", "driver_document": "1234567890"}, "reason": "Validacao controlada da edicao administrativa"}	2026-04-10 18:54:08.949449-03
425cf7ca-9297-4af7-a5ab-bc7a2556e10b	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	effade1b-30a9-4bb2-8070-fa2dfb4a1eeb	ABC-1D23 - Jonatas	{"after": {"end_date": "2026-04-10T15:29:00+00:00", "start_date": "2026-04-10T15:21:00+00:00", "driver_name": "Jonatas", "observation": "teste 03", "driver_contact": "7312345678", "driver_document": "1234567890"}, "event": "ADMIN_EDIT", "before": {"end_date": "2026-04-10T15:29:00+00:00", "start_date": "2026-04-10T15:21:00+00:00", "driver_name": "Jonatas", "observation": "teste 03 | validacao-admin", "driver_contact": "7312345678", "driver_document": "1234567890"}, "reason": "Reversao da validacao administrativa"}	2026-04-10 18:54:09.155279-03
33175dfe-56a3-425b-85f9-08ed766d1d2a	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	CREATE	POSSESSION	e21d8e4d-a35a-48b8-8275-c7a8b269fd93	ABC-1D23 - Teste Multipla Evidencia	{"start_date": "2026-04-10T22:40:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Registro temporario de validacao automatizada.", "photo_count": 2, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10", "signed_document_name": null, "capture_accuracy_meters": [8.4, 7.1], "signed_document_attached": false, "signed_document_mime_type": null, "signed_document_size_bytes": null}	2026-04-10 19:36:56.47926-03
82d9af47-0a9c-4e11-9b44-c171bcf2d6a2	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	e21d8e4d-a35a-48b8-8275-c7a8b269fd93	ABC-1D23 - Teste Multipla Evidencia	{"after": {"end_date": null, "start_date": "2026-04-10T22:40:00+00:00", "driver_name": "Teste Multipla Evidencia", "observation": "Registro temporario de validacao automatizada com complemento admin.", "photo_count": 3, "document_name": "termo.pdf", "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "event": "ADMIN_EDIT", "before": {"end_date": null, "start_date": "2026-04-10T22:40:00+00:00", "driver_name": "Teste Multipla Evidencia", "observation": "Registro temporario de validacao automatizada.", "photo_count": 2, "document_name": null, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "reason": "Inclusao de documento e foto complementar para validar o fluxo novo.", "added_photo_count": 1, "document_replaced": true}	2026-04-10 19:36:56.700976-03
e137d7ff-816c-425e-b766-55f7dd481c14	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	CREATE	POSSESSION	9fe27b13-d763-4794-a7fd-f24e3d0d3228	ABC-1D23 - Teste Debug Fotos	{"start_date": "2026-04-10T22:50:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Registro temporario debug.", "photo_count": 2, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10", "signed_document_name": null, "capture_accuracy_meters": [8.4, 7.1], "signed_document_attached": false, "signed_document_mime_type": null, "signed_document_size_bytes": null}	2026-04-10 19:37:58.561549-03
daadb0cb-0115-496e-acf2-740eab6228d0	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	9fe27b13-d763-4794-a7fd-f24e3d0d3228	ABC-1D23 - Teste Debug Fotos	{"after": {"end_date": null, "start_date": "2026-04-10T22:50:00+00:00", "driver_name": "Teste Debug Fotos", "observation": "Registro temporario debug com foto extra.", "photo_count": 3, "document_name": null, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "event": "ADMIN_EDIT", "before": {"end_date": null, "start_date": "2026-04-10T22:50:00+00:00", "driver_name": "Teste Debug Fotos", "observation": "Registro temporario debug.", "photo_count": 2, "document_name": null, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "reason": "Debug de inclusao de foto extra.", "added_photo_count": 1, "document_replaced": false}	2026-04-10 19:37:58.747386-03
fa43b32d-f634-46ac-a75f-484f13a35b95	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	CREATE	POSSESSION	dd076146-c2b5-44fc-b3ed-35e5651e9c42	ABC-1D23 - Teste Multipla Evidencia	{"start_date": "2026-04-10T22:40:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "Registro temporario de validacao automatizada.", "photo_count": 2, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10", "signed_document_name": null, "capture_accuracy_meters": [8.4, 7.1], "signed_document_attached": false, "signed_document_mime_type": null, "signed_document_size_bytes": null}	2026-04-10 19:42:02.958933-03
0b98ed15-7e6c-44b0-8a41-3bc91781f6c6	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	UPDATE	POSSESSION	dd076146-c2b5-44fc-b3ed-35e5651e9c42	ABC-1D23 - Teste Multipla Evidencia	{"after": {"end_date": null, "start_date": "2026-04-10T22:40:00+00:00", "driver_name": "Teste Multipla Evidencia", "observation": "Registro temporario de validacao automatizada com complemento admin.", "photo_count": 3, "document_name": "termo.pdf", "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "event": "ADMIN_EDIT", "before": {"end_date": null, "start_date": "2026-04-10T22:40:00+00:00", "driver_name": "Teste Multipla Evidencia", "observation": "Registro temporario de validacao automatizada.", "photo_count": 2, "document_name": null, "driver_contact": "(73) 99999-0000", "driver_document": "123.456.789-10"}, "reason": "Inclusao de documento e foto complementar para validar o fluxo novo.", "added_photo_count": 1, "document_replaced": true}	2026-04-10 19:42:03.181509-03
3d5cf70f-d070-46c8-af07-912a6f7e1838	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	ORGANIZATION	50f5a088-91ef-4275-9c2f-c801e1a52445	Secretaria de Administracao	{"name": "Secretaria de Administracao"}	2026-04-10 20:52:34.902725-03
06e48263-4aff-4f2d-b93a-d5375ab1b137	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	ORGANIZATION	1cee06c5-4607-439f-8818-905b0188293c	Secretaria de Infraestrutura	{"name": "Secretaria de Infraestrutura"}	2026-04-10 20:52:52.255929-03
7d4cc717-b803-41ab-afa2-30e0aec99f03	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	ORGANIZATION	f35cb195-2742-486b-9ea9-cd2e020b00b9	Secretaria de Saude	{"name": "Secretaria de Saude"}	2026-04-10 20:53:04.216107-03
9f4e64e0-304f-4812-9320-f3af595c8247	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	VEHICLE	829c4a2b-db47-4541-bffe-c2443a2ffbdd	ABC-1D23	{"after": {"brand": "Ford", "model": "Ka", "plate": "ABC-1D23", "status": "ATIVO", "location": "Secretaria de Saúde - Departamento Administrativo - Patio Municipal", "chassis_number": "9BFZH55L0G1234567", "ownership_type": "CEDIDO"}, "before": {"brand": "Ford", "model": "Ka", "plate": "ABC-1D23", "status": "ATIVO", "location": "Secretaria de Saúde - Departamento Administrativo - Patio Municipal", "chassis_number": "9BFZH55L0G1234567", "ownership_type": "PROPRIO"}}	2026-04-11 08:33:32.760206-03
53b2b3c4-3ff2-463a-8e0a-7705dc649120	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	VEHICLE	9e484fae-5740-42fa-a72b-4a4e28c54665	DEF-4E56	{"brand": "Chevrolet", "model": "Onix", "status": "MANUTENCAO", "location": "Secretaria de Infraestrutura e Serviços Urbanos - Departamento Administrativo - Oficina Central", "chassis_number": "9BWZZZ377VT004251", "current_driver": null, "ownership_type": "PROPRIO"}	2026-04-13 08:57:55.273893-03
bdec56b6-b930-4688-a62f-3a9be3d0caa6	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	VEHICLE	81846f2c-bc53-4c92-9286-89e2c961583c	GHI-7F89	{"brand": "Toyota", "model": "Corolla", "status": "INATIVO", "location": "Secretaria de Saúde - Departamento Administrativo - Patio Municipal", "chassis_number": "8AWZZZ6K2VA012345", "current_driver": null, "ownership_type": "PROPRIO"}	2026-04-13 08:57:57.702438-03
cab43a16-aaa3-4f31-997a-484f399fda4f	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	VEHICLE	829c4a2b-db47-4541-bffe-c2443a2ffbdd	ABC-1D23	{"brand": "Ford", "model": "Ka", "status": "ATIVO", "location": "Secretaria de Saúde - Departamento Administrativo - Patio Municipal", "chassis_number": "9BFZH55L0G1234567", "current_driver": null, "ownership_type": "CEDIDO"}	2026-04-13 08:57:59.885126-03
b3b596cf-1c2a-4b7f-b304-9a0b1f24d660	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	DRIVER	b4b082f2-acb0-4f50-8365-3c48e35f6dad	Carlos Souza	{"documento": "456.123.789-55", "soft_delete": true, "linked_records": 0}	2026-04-13 08:58:10.318839-03
4db229de-1e06-4a44-91c8-d1a3ad807b26	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	DRIVER	5eb82eb3-3485-459e-8d93-679403f0867f	Joao Silva	{"documento": "123.456.789-00", "soft_delete": true, "linked_records": 0}	2026-04-13 08:58:12.613418-03
1b533785-4c36-401e-8c00-5e3f7e115978	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	DELETE	DRIVER	9acc4e58-e084-4089-9ec2-8dd99977870e	Maria Oliveira	{"documento": "987.654.321-00", "soft_delete": true, "linked_records": 0}	2026-04-13 08:58:14.389156-03
6811ac17-3b03-4df3-b740-f23b01871e75	065b1e0b-527b-4b65-8a62-008851a22f96	Arnaldo Rosa dos Santos Filho	naldorsantosfilho@gmail.com	ADMIN	CREATE	USER	9025070c-12e2-410f-8bb6-ae75fa3ae64e	davisr@pm.teixeiradefreitas.ba.gov.br	{"name": "DAVI SANTANA REGO", "role": "PRODUCAO", "email": "davisr@pm.teixeiradefreitas.ba.gov.br"}	2026-04-13 08:59:01.344115-03
5428c378-f71e-420f-a280-b38ea6c2d1fe	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	USER	065b1e0b-527b-4b65-8a62-008851a22f96	naldorsantosfilho@gmail.com	{"after": {"name": "ARNALDO ROSA DOS SANTOS FILHO", "role": "ADMIN", "email": "naldorsantosfilho@gmail.com", "password_changed": false}, "before": {"name": "Arnaldo Rosa dos Santos Filho", "role": "ADMIN", "email": "naldorsantosfilho@gmail.com"}}	2026-04-13 10:12:02.307678-03
7fc7aa45-8f4d-4be0-af1c-ff308f745581	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	USER	08d425de-0052-42b1-95ab-b3178cde1e30	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	{"after": {"name": "WANDERSON SOUSA LIMAS", "role": "ADMIN", "email": "wanderson.limas@pm.teixeiradefreitas.ba.gov.br", "password_changed": false}, "before": {"name": "WANDERSON SOUSA LIMAS", "role": "PRODUCAO", "email": "wanderson.limas@pm.teixeiradefreitas.ba.gov.br"}}	2026-04-13 11:45:32.125092-03
7973150e-4f7c-4dd9-8ea1-af7c8571834a	e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	ADMIN	DELETE	USER	f2ba72df-6b24-41d5-9fa5-4d947672c8d7	carlos@h	{"name": "Carlos Henrique Cruz Honorato", "role": "PRODUCAO"}	2026-04-13 15:59:49.256513-03
fb7230c6-87a4-4af0-b5f2-74cf8dce7db8	\N	Carlos Henrique Cruz Honorato	carlos@h	PRODUCAO	CREATE	POSSESSION	effade1b-30a9-4bb2-8070-fa2dfb4a1eeb	ABC-1D23 - Jonatas	{"start_date": "2026-04-10T15:21:00+00:00", "vehicle_id": "829c4a2b-db47-4541-bffe-c2443a2ffbdd", "observation": "teste 03", "driver_contact": "7312345678", "driver_document": "1234567890", "photo_mime_type": "image/jpeg", "photo_size_bytes": 19434, "photo_captured_at": "2026-04-10T12:21:51.160000+00:00", "capture_accuracy_meters": 178.0, "evidence_photo_attached": true}	2026-04-10 09:22:04.630277-03
94794388-5ebe-4b06-a1ef-0f57b8e7927b	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	USER	50fcc408-b540-480a-872e-0f42650871a1	producao@frota.local	{"after": {"name": "Usuario de Producao", "role": "PRODUCAO", "email": "producao@frota.local", "password_changed": true}, "before": {"name": "Usuario de Producao", "role": "PRODUCAO", "email": "producao@frota.local"}}	2026-04-13 16:43:09.67634-03
5bb604d1-5554-4182-a23e-86f45d973e2b	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	ORGANIZATION	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Secretaria de Administração	{"after": {"name": "Secretaria de Administração"}, "before": {"name": "Secretaria de Administração"}}	2026-04-15 20:46:53.365084-03
f8ce96d7-a7e8-426d-8f18-0041c56e4802	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	08c87c40-c5b3-4531-a561-2480d3d65c02	Gabinete do Secretário	{"name": "Gabinete do Secretário", "organization": "Secretaria de Administração"}	2026-04-15 20:48:27.51184-03
81074bcc-d977-4d2d-8cac-5e1d37d6f313	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	9b013e25-2dfb-4276-80ff-73c36923f68f	SESMT	{"name": "SESMT", "organization": "Secretaria de Administração"}	2026-04-15 20:48:42.565904-03
70558585-e1b7-46f5-afdd-c83148653bd1	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	3eac36c0-5ac6-43b7-bafc-2ce55213d70f	Almoxarifado Central	{"name": "Almoxarifado Central", "organization": "Secretaria de Administração"}	2026-04-15 20:48:54.869736-03
4d5c86bf-f089-4898-b2fc-511de8e16d05	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	8ff4e2f2-d4d9-4239-b5a4-2939c8db97f4	Patrimônio e Arquivos em Geral	{"name": "Patrimônio e Arquivos em Geral", "organization": "Secretaria de Administração"}	2026-04-15 20:49:18.680366-03
5eef81b2-08c4-4ad6-ae1d-c240d0090c93	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	6963629c-862f-49f1-b514-d0069096d0f6	Departamento de TI	{"name": "Departamento de TI", "organization": "Secretaria de Administração"}	2026-04-15 20:49:46.021639-03
d231c148-895e-41fb-90cf-4c613fe3e2bf	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	d2399f27-137d-4b0b-bccf-4adc5da83c9a	Secretaria de Administração - SESMT - SESMT	{"name": "SESMT", "department": "SESMT", "organization": "Secretaria de Administração"}	2026-04-15 20:59:11.378042-03
5879e277-e36f-4a58-964b-4407fdb703b1	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	DELETE	DEPARTMENT	dd141042-2a72-4d8e-b8f1-69eb11d83532	Departamento Administrativo	{"name": "Departamento Administrativo", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}	2026-04-15 21:01:38.541815-03
33c523d7-7229-4d9d-87a5-c22a4fd341f0	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	VEHICLE	9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}	2026-04-15 21:02:19.626438-03
73432624-6ba4-433b-9d00-ebf9aa0aacba	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DEPARTMENT	1a87c196-04c6-4a3d-939d-9f074fc0ef36	Departamento de Recursos Humanos	{"name": "Departamento de Recursos Humanos", "organization": "Secretaria de Administração"}	2026-04-15 20:55:52.752009-03
4a173b2f-53c3-488c-89ce-f6682d152932	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	f9034b11-e997-4d93-9af6-e38076cbcd03	Secretaria de Administração - Departamento de Recursos Humanos - Departamento de Recursos Humanos	{"name": "Departamento de Recursos Humanos", "department": "Departamento de Recursos Humanos", "organization": "Secretaria de Administração"}	2026-04-15 21:00:06.884083-03
33e2fdab-aaa3-400e-9d05-f79fd0926b8b	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	DELETE	ALLOCATION	438d6cb1-f722-4af4-b84b-1dba56c56676	Secretaria de Infraestrutura e Serviços Urbanos - Departamento Administrativo - Oficina Central	{"name": "Oficina Central", "department": "Departamento Administrativo", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}	2026-04-15 21:00:32.304473-03
c6f3d743-dc34-4fb0-a6b7-31b60204c862	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	4febca10-87f3-4f62-8d59-d6bb472dd502	Secretaria de Administração - Departamento Administrativo - Departamento Administrativo	{"name": "Departamento Administrativo", "department": "Departamento Administrativo", "organization": "Secretaria de Administração"}	2026-04-15 21:01:05.756829-03
a23784a2-d86b-4ddc-b838-0a85edc9abe9	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	b90c8744-a5d2-4751-923b-b4498764b756	Secretaria de Administração - Almoxarifado Central - Almoxarifado Central	{"name": "Almoxarifado Central", "department": "Almoxarifado Central", "organization": "Secretaria de Administração"}	2026-04-15 21:01:25.309254-03
cff4b80b-965e-434f-9a61-333f321c280b	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	171ac1a6-9eac-474a-a93a-675611aa783f	Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário	{"name": "Gabinete do Secretário", "department": "Gabinete do Secretário", "organization": "Secretaria de Administração"}	2026-04-15 20:58:48.993092-03
60daf0c7-a655-469c-ac27-c935ee0cb815	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	4129b656-4329-4bdc-af3e-a107f0467cdd	Secretaria de Administração - Patrimônio e Arquivos em Geral - Patrimônio e Arquivos em Geral	{"name": "Patrimônio e Arquivos em Geral", "department": "Patrimônio e Arquivos em Geral", "organization": "Secretaria de Administração"}	2026-04-15 20:59:36.630497-03
9bf79d6b-9ba7-4308-a488-7adb4a696724	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	DELETE	DEPARTMENT	9c5a3de4-107e-444f-a840-d7d2a528190f	Departamento Administrativo	{"name": "Departamento Administrativo", "organization": "Secretaria de Saúde"}	2026-04-15 21:01:33.367656-03
d1d76f54-0c26-4ccf-9cc3-a81b1f9ebee8	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	DRIVER	ffd5a632-b7af-4c27-a220-7a03ab17f563	ARNALDO ROSA DOS SANTOS FILHO	{"ativo": true, "email": "arnaldo@pm.teixeiradefreitas.ba.gov.br", "contato": "73999821745", "documento": "06668082521", "cnh_validade": "2034-04-10", "cnh_categoria": "B"}	2026-04-15 21:05:39.550156-03
0ceed2ef-3f9f-4180-bf5b-973ea8fea238	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	CREATE	ALLOCATION	66824306-6e4d-4eb8-a3d4-b80010731ca7	Secretaria de Administração - Departamento de TI - Departamento de TI	{"name": "Departamento de TI", "department": "Departamento de TI", "organization": "Secretaria de Administração"}	2026-04-15 20:59:51.030476-03
7309871b-929c-4fee-bc80-ac7e86adc2bb	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	DELETE	ALLOCATION	165ff7ef-b982-4bd5-a1b6-04b1296fd2c7	Secretaria de Saúde - Departamento Administrativo - Patio Municipal	{"name": "Patio Municipal", "department": "Departamento Administrativo", "organization": "Secretaria de Saúde"}	2026-04-15 21:00:27.809277-03
24c16847-f847-42a7-928e-5342c303fd76	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	DELETE	ALLOCATION	ef65fded-e6e0-4b66-b24a-8faafc15068c	Secretaria de Administração - Departamento Administrativo - Garagem Central	{"name": "Garagem Central", "department": "Departamento Administrativo", "organization": "Secretaria de Administração"}	2026-04-15 21:00:42.908963-03
c8c5665d-fac3-4cad-849a-d33a714e8b05	08d425de-0052-42b1-95ab-b3178cde1e30	WANDERSON SOUSA LIMAS	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	ADMIN	CREATE	DEPARTMENT	abceb99f-7796-46df-9166-4d59699a581a	SDE - SEDE	{"name": "SDE - SEDE", "organization": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia"}	2026-04-16 08:40:12.620772-03
072597ce-3c6e-4c56-a6f5-e4a849d01c86	08d425de-0052-42b1-95ab-b3178cde1e30	WANDERSON SOUSA LIMAS	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	ADMIN	CREATE	ALLOCATION	3265a02e-4d56-4cb0-aa6f-4b1103ea3911	Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia - SDE - SEDE - SDE - SEDE	{"name": "SDE - SEDE", "department": "SDE - SEDE", "organization": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia"}	2026-04-16 08:41:42.739476-03
5cd9bb56-1cfb-4a1b-bf19-702adc07dfd0	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	USER	9025070c-12e2-410f-8bb6-ae75fa3ae64e	davisr@pm.teixeiradefreitas.ba.gov.br	{"after": {"name": "DAVI SANTANA REGO", "role": "PRODUCAO", "email": "davisr@pm.teixeiradefreitas.ba.gov.br", "password_changed": true}, "before": {"name": "DAVI SANTANA REGO", "role": "PRODUCAO", "email": "davisr@pm.teixeiradefreitas.ba.gov.br"}}	2026-04-16 10:34:26.757569-03
4ad6422e-b142-42c3-898d-4adba70f4a9d	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	UPDATE	DEPARTMENT	abceb99f-7796-46df-9166-4d59699a581a	Desenvolvimento Econômico - SDE - SEDE	{"after": {"name": "Desenvolvimento Econômico - SDE - SEDE", "organization": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia"}, "before": {"name": "SDE - SEDE", "organization": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia"}}	2026-04-16 11:15:45.185015-03
97e680e7-145d-4b74-bfe8-c1869d8c5d54	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	3b767a49-d988-4686-8351-ca04907e1be7	TOA5G32	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Departamento de TI - Departamento de TI", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R14TT033231", "ownership_type": "LOCADO"}	2026-04-16 11:22:51.468843-03
025e60ce-08c7-4ebe-b971-0b454cd57fd6	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	8a66db72-23cb-45ba-8716-0dc2f89cdf25	Infraestrutura - SEINFRA	{"name": "Infraestrutura - SEINFRA", "organization": "Secretaria de Administração"}	2026-04-16 11:25:44.447855-03
18e69e2a-ce5a-4e26-8f00-2f9b4bfacec8	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	2395d84a-550a-4aac-aaf4-3c5c3ca79314	Secretaria de Administração - Infraestrutura - SEINFRA - Infraestrutura - SEINFRA	{"name": "Infraestrutura - SEINFRA", "department": "Infraestrutura - SEINFRA", "organization": "Secretaria de Administração"}	2026-04-16 11:26:32.003626-03
d35c0c87-b127-4503-a3fd-8b37816d0770	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	ec714e4f-d968-4790-aabd-9390944ad035	Departamento de Frotas	{"name": "Departamento de Frotas", "organization": "Secretaria de Administração"}	2026-04-16 11:28:15.16876-03
26d18e27-db61-4e96-ac21-0ad0c5b9862b	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	979b0bff-f532-4a64-a3c2-ad4a119da580	Secretaria de Administração - Departamento de Frotas - Departamento de Frotas	{"name": "Departamento de Frotas", "department": "Departamento de Frotas", "organization": "Secretaria de Administração"}	2026-04-16 11:28:32.527935-03
25fd52b3-bb92-4aa3-ab59-27215aeadd5e	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	ef947a79-a1a0-42d5-977c-50cc43f016b6	TOA5G25	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Infraestrutura - SEINFRA - Infraestrutura - SEINFRA", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R13TT033575", "ownership_type": "LOCADO"}	2026-04-16 11:29:33.565033-03
75fc8c42-7578-4d29-a86d-e7a4f1f5983a	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	07c1894c-d8aa-45f7-95e4-a44162c608c6	TOA5F48	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Departamento de Frotas - Departamento de Frotas", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R17TT033370", "ownership_type": "LOCADO"}	2026-04-16 11:30:32.016056-03
78dcb898-9569-488d-952a-c63fed8885f0	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	51bf2f46-2ff2-4eca-8ea7-f2364a5b2378	Agricultura - SEAGRI	{"name": "Agricultura - SEAGRI", "organization": "Secretaria de Administração"}	2026-04-16 11:31:41.91221-03
a4c7bbe7-4576-426b-8cc8-b4d22a3d8e76	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	5f9aad8a-fd3f-42fe-8444-8e7432ac3d96	Secretaria de Administração - Agricultura - SEAGRI - Agricultura - SEAGRI	{"name": "Agricultura - SEAGRI", "department": "Agricultura - SEAGRI", "organization": "Secretaria de Administração"}	2026-04-16 11:31:52.023926-03
6b718ee1-156b-4f0c-84fb-0df92a25062a	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	51a8d922-0382-4242-99b0-841b0c8e386a	TOA5F57	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Agricultura - SEAGRI - Agricultura - SEAGRI", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R15TT033464", "ownership_type": "LOCADO"}	2026-04-16 11:32:29.841531-03
80115a10-c730-4039-8aa3-5134aa162712	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	DEPARTMENT	6e0b0f1b-2f83-412e-a128-3fa682ea1190	Gabinete da Secretaria	{"name": "Gabinete da Secretaria", "organization": "Secretaria de Agricultura Pecuária e Abastecimento"}	2026-04-20 11:16:38.748208-03
57ff6943-0d13-4d72-8e9e-df7927a69401	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ALLOCATION	c7e7ff44-4673-4095-aa5e-a50d75656201	Secretaria de Agricultura Pecuária e Abastecimento - Gabinete da Secretaria - Gabinete	{"name": "Gabinete", "department": "Gabinete da Secretaria", "organization": "Secretaria de Agricultura Pecuária e Abastecimento"}	2026-04-20 11:17:02.027361-03
5cff8858-488d-4df3-bf50-30b7cc3bacae	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	DEPARTMENT	51bf2f46-2ff2-4eca-8ea7-f2364a5b2378	Agricultura - SEAGRI	{"name": "Agricultura - SEAGRI", "organization": "Secretaria de Administração"}	2026-04-20 11:17:13.44236-03
96ec98d1-cf4e-42e8-8abb-2cf21892e669	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	DEPARTMENT	8e91b226-caf7-4965-91a1-37adca8d3f30	Gabinete da Secretaria	{"name": "Gabinete da Secretaria", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}	2026-04-20 11:17:37.554567-03
748182c5-a61c-445f-a0cb-4734f721619e	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ALLOCATION	e4771d43-f38c-448a-b777-0feb3ad63194	Secretaria de Infraestrutura e Serviços Urbanos - Gabinete da Secretaria - Gabinete	{"name": "Gabinete", "department": "Gabinete da Secretaria", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}	2026-04-20 11:17:48.96919-03
1cb218b4-c48e-4c05-9828-a18757d06f40	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	DELETE	DEPARTMENT	8a66db72-23cb-45ba-8716-0dc2f89cdf25	Infraestrutura - SEINFRA	{"name": "Infraestrutura - SEINFRA", "organization": "Secretaria de Administração"}	2026-04-20 11:17:56.076836-03
5b7eebf1-adf3-4dc3-91f0-fd48d195ac3a	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	VEHICLE	51a8d922-0382-4242-99b0-841b0c8e386a	TOA5F57	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TOA5F57", "status": "ATIVO", "location": "Secretaria de Agricultura Pecuária e Abastecimento - Gabinete da Secretaria - Gabinete", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R15TT033464", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TOA5F57", "status": "ATIVO", "location": "Secretaria de Administração - Agricultura - SEAGRI - Agricultura - SEAGRI", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R15TT033464", "ownership_type": "LOCADO"}}	2026-04-20 11:18:53.931915-03
7b1ee018-0eb6-4a52-8eb0-ca5e9b6d9c55	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	VEHICLE	ef947a79-a1a0-42d5-977c-50cc43f016b6	TOA5G25	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TOA5G25", "status": "ATIVO", "location": "Secretaria de Infraestrutura e Serviços Urbanos - Gabinete da Secretaria - Gabinete", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R13TT033575", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TOA5G25", "status": "ATIVO", "location": "Secretaria de Administração - Infraestrutura - SEINFRA - Infraestrutura - SEINFRA", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R13TT033575", "ownership_type": "LOCADO"}}	2026-04-20 11:19:15.973684-03
ca91dd50-e188-4f4f-9533-f5e0a22bfd75	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ALLOCATION	7eb88421-435f-4919-9f66-c7e6b3191e64	Secretaria de Agricultura Pecuária e Abastecimento - Gabinete da Secretaria - SEDE	{"name": "SEDE", "department": "Gabinete da Secretaria", "organization": "Secretaria de Agricultura Pecuária e Abastecimento"}	2026-04-20 11:19:58.892797-03
d9ad12ec-98cd-4643-a26c-d84f11ff2935	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	CREATE	ALLOCATION	ca62c137-72ca-4cb8-9d2d-8cb57fd1a9f4	Secretaria de Infraestrutura e Serviços Urbanos - Gabinete da Secretaria - SEDE	{"name": "SEDE", "department": "Gabinete da Secretaria", "organization": "Secretaria de Infraestrutura e Serviços Urbanos"}	2026-04-20 11:20:17.915014-03
a467347a-c5b8-41bc-9485-d5cd2e9e915f	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	71e67d56-af08-4ef2-9077-c6b7ad79a099	Chefia de Governo	{"name": "Chefia de Governo", "organization": "Secretaria de Administração"}	2026-04-22 14:30:03.639504-03
e6d2b497-24e6-44dd-8079-5b506bd33d0d	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	c6c9136b-b07e-4256-a46b-f4d4bdcb7b48	Secretaria de Administração - Chefia de Governo - Chefia de Governo	{"name": "Chefia de Governo", "department": "Chefia de Governo", "organization": "Secretaria de Administração"}	2026-04-22 14:30:25.60732-03
633ca184-69f1-45ce-be0a-93972c75505c	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	0e9d959e-666d-4e9e-92ed-a15cff32db7a	TOA5G28	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Chefia de Governo - Chefia de Governo", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R19TT033208", "ownership_type": "LOCADO"}	2026-04-22 14:36:58.480425-03
95609a4b-c84d-4541-84ff-ca004e2e5024	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	405d91a7-fb9e-4789-9dc3-6f309431bfec	TOA5G11	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Chefia de Governo - Chefia de Governo", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R1XTT033573", "ownership_type": "LOCADO"}	2026-04-22 14:41:58.938149-03
264b5ef6-bdb6-45d3-8805-4af0edf03c3a	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	6857365a-5a63-49ab-a171-ddfb98863a9d	TOA5F65	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Administração - Chefia de Governo - Chefia de Governo", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R12TT033518", "ownership_type": "LOCADO"}	2026-04-22 14:46:31.860949-03
1edb8454-bb52-422d-9956-541cebecd8cd	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	VEHICLE	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	TOA5G37	{"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "status": "ATIVO", "location": "Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia - Desenvolvimento Econômico - SDE - SEDE - SDE - SEDE", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R15TT033321", "ownership_type": "LOCADO"}	2026-04-23 14:54:05.450617-03
eb743fc8-4430-49dd-a3f5-eadc014c6b77	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	1adcb869-29ac-4973-8d65-93e1c76bac64	Educação	{"name": "Educação", "organization": "Secretaria de Educação"}	2026-04-23 15:34:39.098836-03
6472b40b-f7b9-4f5b-bb9b-abb0a7361e22	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	462c5c47-1e0a-47e4-b319-b5e58f829d3c	Secretaria de Educação - Educação - Educação	{"name": "Educação", "department": "Educação", "organization": "Secretaria de Educação"}	2026-04-23 15:34:49.546513-03
84759117-7ac4-4973-8ebf-690037ace153	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	DEPARTMENT	f319cfe4-e444-4349-806a-6597a2a56534	Transporte Escolar	{"name": "Transporte Escolar", "organization": "Secretaria de Educação"}	2026-04-23 15:35:03.095258-03
06aa1ea0-433c-4464-b859-288d67120741	9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	PRODUCAO	CREATE	ALLOCATION	8866c574-cd7f-4374-99fb-32a6884b36a5	Secretaria de Educação - Transporte Escolar - Transporte Escolar	{"name": "Transporte Escolar", "department": "Transporte Escolar", "organization": "Secretaria de Educação"}	2026-04-23 15:35:17.167032-03
8e45f6e6-9e12-435b-9772-4a93bf0fa262	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	VEHICLE	9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "ATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "ATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}}	2026-04-23 17:11:45.155835-03
8baac8eb-2225-42e4-bae9-13721c353b54	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	VEHICLE	9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "INATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "ATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}}	2026-04-23 17:12:05.105672-03
6b1d5b9f-0757-42f7-ba9e-4235b65f09a1	2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	ADMIN	UPDATE	VEHICLE	9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "INATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "INATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "reason": "Veículo devolvido à locadora."}	2026-04-23 18:05:30.074668-03
db24634e-7fd1-47f5-960b-4fd12c23545b	065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	ADMIN	UPDATE	VEHICLE	9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	{"after": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "INATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "before": {"brand": "VOLKSWAGEN", "model": "POLO TRACK MA", "plate": "TEE0D81", "status": "INATIVO", "location": "Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário", "vehicle_type": "HATCH", "chassis_number": "9BWAG5R10TT004230", "ownership_type": "LOCADO"}, "reason": "VEÍCULO RESERVA DEVOLVIDO EM 23/04/2026, À EMPRESA LOCALIZA S/A, POR SER VEÍCULO RESERVA DO VEÍCULO SYK9F47, TAMBÉM DEVOLVIDO."}	2026-04-23 19:12:08.399553-03
\.


--
-- Data for Name: claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.claims (id, vehicle_id, driver_id, data_ocorrencia, tipo, descricao, local, boletim_ocorrencia, valor_estimado, status, justificativa_encerramento, anexos, created_by, created_at, updated_at) FROM stdin;
7d503a56-245b-4384-bee5-520ea1821320	eb9a600f-ec93-496f-80a6-0e81355e6739	\N	2026-04-22 11:20:27.244382-03	AVARIA	Avaria registrada durante deslocamento para oficina, com dano lateral e necessidade de avaliacao tecnica.	Avenida Principal, proximo ao patio municipal	BO-2026-001	1850.00	EM_ANALISE	\N	["foto-lateral.jpg"]	e0b3d114-290f-4989-8157-c0819ec33156	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
\.


--
-- Data for Name: drivers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drivers (id, nome_completo, documento, contato, email, cnh_categoria, cnh_validade, ativo, created_at, updated_at) FROM stdin;
b4b082f2-acb0-4f50-8365-3c48e35f6dad	Carlos Souza	456.123.789-55	(11) 97777-6666	\N	C	\N	f	2026-04-10 20:43:50.711053-03	2026-04-13 08:58:10.318839-03
5eb82eb3-3485-459e-8d93-679403f0867f	Joao Silva	123.456.789-00	(11) 99999-8888	joao.silva@pmtf.local	B	2027-05-15	f	2026-04-10 20:43:50.711053-03	2026-04-13 08:58:12.613418-03
9acc4e58-e084-4089-9ec2-8dd99977870e	Maria Oliveira	987.654.321-00	(11) 98888-7777	maria.oliveira@pmtf.local	D	2026-12-06	f	2026-04-10 20:43:50.711053-03	2026-04-13 08:58:14.389156-03
ffd5a632-b7af-4c27-a220-7a03ab17f563	ARNALDO ROSA DOS SANTOS FILHO	06668082521	73999821745	arnaldo@pm.teixeiradefreitas.ba.gov.br	B	2034-04-10	t	2026-04-15 21:05:39.550156-03	2026-04-15 21:05:39.550156-03
\.


--
-- Data for Name: fines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fines (id, vehicle_id, driver_id, ticket_number, infraction_date, due_date, amount, description, location, status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fleet_analytics_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fleet_analytics_snapshots (id, period_start, period_end, vehicle_id, driver_id, vehicle_type, scope, total_km, total_liters, fuel_cost, maintenance_cost, fines_cost, consumption_l_100km, tco_cost_per_km, driver_risk_score, anomalies_count, category_average_consumption, category_average_tco, market_benchmark_tco, extra_payload, notes, created_at) FROM stdin;
0f34636e-8cfc-4c63-9c76-4044de0b0c8f	2026-03-16 21:00:00-03	2026-04-15 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-15 21:03:18.268927-03
bf2230ba-8106-488a-8601-e56d7f698592	2026-03-16 21:00:00-03	2026-04-15 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-15 21:03:18.276705-03
7ae1e8e4-1766-42c2-9bc2-0526379ee1f8	2026-03-16 21:00:00-03	2026-04-15 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-15 21:03:18.275994-03
539eed48-2136-4065-b3ef-d1da7f85bd8c	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.551807-03
52a525bb-d2a8-4b54-97b6-ef49ac7c038e	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.551807-03
621327ec-94ac-4d17-9508-ea8378dd207a	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.551807-03
87ea25bf-8249-4e41-987a-f24c752935e5	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.551807-03
dc9f3015-5500-4ba2-be0d-6f80a495c242	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.551807-03
ed2ec384-02bf-45bf-a87a-80914bd85ffa	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-17 18:39:17.551807-03
7bc9c1ba-b921-4592-8a47-a6509b06983c	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.550556-03
d82fb851-9d4b-4213-b9b7-72a71e7f9228	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.550556-03
7bfdf03e-7199-4db6-b605-c6d306fd4b6f	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.550556-03
11de2c16-3ed1-404d-b0bb-b73a88abd312	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.550556-03
e02fc08e-1efc-459a-b460-e2edf966b0e2	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-17 18:39:17.550556-03
8fe93182-101c-40e9-b6c4-e72a82be9b09	2026-03-17 21:00:00-03	2026-04-16 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-17 18:39:17.550556-03
597fe91d-dfd9-4592-8a1c-dc3a6c0f86f5	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
10be06da-c3b5-48f0-b32a-472692abf85d	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
3bb84374-5423-4a13-9326-d7f7a1a2e5c8	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
43204523-1889-4f44-89ca-d50d93447e46	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
f48c0ece-3a2c-4af8-9d23-9e05c8c40944	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
8c9b06de-7d6d-4691-bc98-e1e173a7548b	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
079c5c4e-1dfe-4f3a-8d46-ae7cca87edf3	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
bc23e3a6-f8e0-4fc4-a6c3-4d87c798a799	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.710849-03
ce68857e-0bac-4410-b7cf-5495b5654820	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-22 15:03:42.710849-03
afceba72-75bb-437b-8ce0-c48459d69a46	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.360272-03
a02cbad8-dca1-4abf-b368-6b605c657923	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.360272-03
8f03a34f-c7f4-45ef-a12c-a03b191d6324	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.360272-03
bf1ef6c3-a1cc-4833-bce8-ac5bf78cf2e8	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.360272-03
9be532c4-3d6e-4053-915e-ae5f7ab61a57	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.360272-03
218836b4-bc20-46be-bba9-77247b25fec6	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-18 08:15:44.360272-03
c5081ee4-e1c5-4b55-96c0-7aa75450159b	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.449114-03
5140d914-282f-4f48-9814-5edfab534aea	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.449114-03
b6bbcbe6-fbbf-478c-9d50-2a937341070e	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.449114-03
84ec71b0-90fd-421c-a34d-64783f5d4c9c	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.449114-03
8670f7f7-fdc7-494f-8283-5096f82378d5	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-18 08:15:44.449114-03
b19c3d97-b917-4dbb-afa2-f28cfc136500	2026-03-18 21:00:00-03	2026-04-17 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-18 08:15:44.449114-03
df65fa2f-5c79-49df-8458-b998ddca8213	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.328923-03
4b960de6-a6b3-4446-9fee-a6f25e7d7657	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.328923-03
e34e007c-9b51-4715-b3c9-fc158d138467	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.328923-03
64c28f82-4437-46be-bde6-e1ed59930427	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.328923-03
d4497ffa-9a32-4f86-9976-481fd2b4a754	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.328923-03
0da3b9f4-a0f0-452b-9424-66d64a24b5a8	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:45.328923-03
1e5087c1-e31e-4e35-b29a-ffa10a6497a1	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.330249-03
60e4fc3a-7848-4a90-968b-6e93e1a3005f	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.33511-03
65e73118-2ed8-40d3-8da4-19e1bbac1ba3	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.330249-03
9900e3c9-f30a-4f5e-bb9a-2445f4702593	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.33511-03
98962d19-bd15-4f02-83c8-f7a5aeedade5	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.330249-03
64048029-18eb-477b-be69-fea7b65d6c0f	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.33511-03
2f9e86a2-9ee2-484c-bac7-2c35fec20f5d	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.330249-03
6e3e3c60-6e6c-46c6-8053-0cab4dc74c45	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.356158-03
c41897b0-8ab6-492d-81e2-d8d7a6854b30	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.356158-03
0dcd960e-4c97-4337-a05f-73e002be5fd0	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.356158-03
e414d7fb-1a47-4dbd-b590-91c3c96b25a5	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.356158-03
ce52e458-2ebf-4a19-aaec-4d84192a8d36	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.356158-03
7f4c2166-0a4c-4987-9212-c54f7614e211	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:53.356158-03
95f79b53-1233-4ae2-985a-a38e5977e889	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.358162-03
77398e54-48cd-49dc-9cdd-47a4647ed7e6	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.358162-03
4b301747-2eab-4b93-9453-fdc14e15d4a7	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.358162-03
e89319c9-6a49-493a-8b38-35a5447dc8f0	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.358162-03
13b345a8-b925-4910-a621-9abeb025297a	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.358162-03
8d9888fb-459e-41f7-95af-1862d6a56d1e	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:53.358162-03
032f2c51-21c7-4824-9f82-301c31fe9c19	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.832852-03
5c85f98b-5cc2-4a22-8e94-e501739fe5b7	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.832852-03
c683612b-29f0-4115-8e0d-b6dcb92980d7	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.832852-03
f2ef3d61-e0b4-4b66-980d-39efab262bc1	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.832852-03
2d775360-7a0b-46e0-a3da-590640dd65c1	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.832852-03
1c823c6a-e44d-40fa-b269-a2a3aee07a1d	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.33511-03
a0fbaea6-aafa-4e13-afa9-7eb8c2bf120e	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.33511-03
a9613afa-35d0-4575-8e2c-f7f5e7f22867	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:45.33511-03
b793ec9b-58c9-45c5-aa3a-66064517fcde	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.363609-03
b4b61147-15ab-4afe-a66a-c17d03fea65b	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.363609-03
26c6129f-8829-446a-9898-6b54fd3bdf1c	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.363609-03
6fc77d43-2c58-4fb8-af15-0125ea5fbe16	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.363609-03
5aa22a8d-8be1-4f75-89df-e3e19f123abf	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.363609-03
3bfcba77-5ae9-4828-b0fa-39f6fe37272d	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:53.363609-03
7bd6decd-ad32-46fe-b212-313deec33b38	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.83366-03
b2bef32b-134a-4e5a-8f9d-968fc3c3b264	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.83366-03
3809cdc5-6271-412d-b185-2c620fa1d7c3	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.83366-03
2ac273e2-6cf0-4615-90eb-04cc4e77f136	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.83366-03
ee0c41d9-1e0d-4914-8e7f-a2ebc3087700	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.83366-03
f00c4c06-915c-4ba7-aaba-bcd82a2d4bf3	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:56.83366-03
fe2fdc30-1bda-4969-a43a-41efda719eb3	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 19:34:18.962055-03
f8634058-53d5-4d0e-90a6-dae2c4ee9a6f	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 19:34:18.962055-03
5ef21b07-3265-4f34-a4df-431dbeaa8f41	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 19:34:18.962055-03
8554b1b5-4b76-4279-aeb8-7db9b7133f4d	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 19:34:18.962055-03
2e52667d-e26f-4e37-b24c-b19014a02bdc	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 19:34:18.962055-03
7f689732-0358-4392-983f-59d5ea35c5ce	2026-03-20 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 19:34:18.962055-03
6861c8a3-c0a3-401c-92a8-b2716af4a711	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:45.330249-03
8cb5e3c7-6bdd-4351-9beb-e885b30195c8	2026-04-12 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:45.330249-03
8d8eb23a-1bcd-4f7d-8e1e-5ea7f9d6f8e2	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.364468-03
0d8303ab-38fc-4d46-a3c8-6614d41ed8a6	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.364468-03
5c6721da-09b3-4025-9df5-1d085b97d85a	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.364468-03
e3f067ca-2f5f-413e-86a2-de14de8fcc82	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.364468-03
78f8b19d-51c4-4b05-9bb1-be0ae5ec2ba4	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:53.364468-03
9d9cae04-d4c2-4743-9519-d7a95265f68d	2026-01-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:53.364468-03
14708080-175d-4eec-b14d-8ea26c6618a3	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.053019-03
c8c4cb43-22af-452d-8304-4c59c712a9c9	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.053019-03
d5537fb6-c69c-4acf-b7d1-8cfa6a3d12c0	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.053019-03
d113665f-14e8-4eb0-9ab2-2e8ebb595d8f	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.053019-03
b57aa901-aee5-46e2-aae7-ec25fe6b9b21	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.053019-03
9e0e6261-bf4c-4105-ab00-8c225bd39ff7	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:44:00.053019-03
ed796a15-2c62-4420-b0fb-9b01243e28ee	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
db0a1b71-2e65-4e44-8b18-3a49c77b5b75	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
2bb9f469-e0a1-48ce-8367-1c0c9853360d	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
d97a614d-019b-4860-a3fc-86050be13298	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
7df0dbea-c206-4459-a95b-82ddfa58b36f	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
23b5b2ed-f486-4492-8ca5-1f78bf632d25	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
7327527d-ac12-4bd4-b995-9957a95917b0	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
48a01cdd-102f-4adb-af83-8fb99ac5dad8	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-22 15:03:42.703458-03
77fe4e49-b691-419d-9dbf-7b23b47647bc	2026-03-22 21:00:00-03	2026-04-21 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-22 15:03:42.703458-03
4ea0998d-5c65-4844-bfe4-70d8d038ed65	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
4f867c47-2a59-4193-921c-27c3a0febf3b	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
20b86b8d-9fe8-4680-b765-2770915b3438	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
26a583e5-fff6-4f74-b3cb-5da7e8441bb3	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
8d475db8-39a5-4a0b-a90b-bb989393497e	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
b9f50d3e-9fb9-4a7b-a0d9-f91626b62280	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
a02fb431-832d-49fd-9318-9a5d9179be52	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
432dea7c-3b46-41c7-bb00-53393ad76986	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-23 20:00:39.93517-03
623c05af-9eb0-431f-be36-2d22539b5b26	2026-03-23 21:00:00-03	2026-04-22 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-23 20:00:39.93517-03
a9d541bd-7be2-4742-bc88-c30e6498a2b8	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:56.832852-03
e8755715-3c96-48d1-92ab-78e06eac0f1b	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.837451-03
4800e259-cfef-4171-936c-b92ed6475929	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.836152-03
2387b91f-7fa4-4903-b61a-f739526209d5	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.837451-03
1defc4fd-7838-430e-88d1-4ba9a60d3762	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.836152-03
5ab2badf-4fc0-43cb-98e3-11b6c20cfcb4	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.837451-03
5c9b060c-e579-48bc-986e-b32be75f70e4	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.836152-03
ae3dbd1e-8626-4bf6-87a5-85cc8e8790ec	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.837451-03
d3b16cc8-c088-41f0-a7e7-525248e57d89	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.836152-03
aab7e201-fb20-4d28-8978-13a12dfb568c	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.837451-03
906f2727-79a0-40c9-8cfe-48740f01d443	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:43:56.836152-03
2de5e3c4-3ece-495f-9cfd-59c291a73cae	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:56.837451-03
32ecf7f8-6b33-424c-8066-aa96283119f7	2025-10-21 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:43:56.836152-03
26699ed2-c1b0-49b2-9360-e8db9f3ed246	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.048624-03
ab0b6ced-de1f-4063-b404-29323df73954	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.048624-03
bec6164a-2a01-45c0-be9c-3f0cf8d6a38e	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.048624-03
25a1a95d-10e3-425b-9c87-f1e764560ee4	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	9d93506e-947a-4f64-ba85-ed50f29af283	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.049576-03
d8d1e481-64b7-4e02-8203-31bde84bcd7e	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.048624-03
ef7d2fa4-7b9d-47aa-9ec7-f511422e04b0	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.049576-03
852010f7-8ad1-46f1-aa9c-f6ed82f0a357	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.048624-03
a99c6367-fa55-44ee-a670-849ce555fa39	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.049576-03
885cef2f-f12b-4063-8321-b6d80a626afe	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:44:00.048624-03
23608e5c-6109-4523-b591-3cbaa0226393	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.049576-03
bffdf0c4-15ff-4a8b-97b1-66cbf3292bf5	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-20 12:44:00.049576-03
878bf35b-3892-428a-8d4d-fc3c2e08ed10	2025-04-19 21:00:00-03	2026-04-19 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-20 12:44:00.049576-03
0c28e24d-2c47-4b9c-9583-a39abfe94b7e	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	3b767a49-d988-4686-8351-ca04907e1be7	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 11:44:55.407115-03
5cd8d442-8350-40ce-9231-61e64a0e714f	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	ef947a79-a1a0-42d5-977c-50cc43f016b6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 11:44:55.407115-03
c730c719-f1be-4f7f-8d4b-f37e49b96a8b	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	07c1894c-d8aa-45f7-95e4-a44162c608c6	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 11:44:55.407115-03
ef045012-2e35-4dbd-8323-d7b46582dca7	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	51a8d922-0382-4242-99b0-841b0c8e386a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 11:44:55.407115-03
6d9495da-c575-4d1d-8a05-16f39305b773	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	0e9d959e-666d-4e9e-92ed-a15cff32db7a	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 11:44:55.407115-03
1f17c7e2-590a-42fa-b30b-c7c9e0ffe1f7	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	405d91a7-fb9e-4789-9dc3-6f309431bfec	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 11:44:55.407115-03
3caba5fc-29be-4106-9555-a50623f12980	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	6857365a-5a63-49ab-a171-ddfb98863a9d	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 11:44:55.407115-03
cce437e5-2e51-4519-9d82-df2bcde30d5e	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	\N	HATCH	VEHICLE	0	0	0.00	0.00	0.00	\N	\N	\N	0	\N	\N	1.2	\N	\N	2026-04-24 11:44:55.407115-03
3c862b89-d64e-446a-a296-be35787589f2	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	8cfde2d0-1d84-4e04-b152-a22cd87dd69c	\N	SEDAN	VEHICLE	0	0	0.00	285.50	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-04-24 11:44:55.407115-03
3e85fbb1-34c4-411a-8196-b54ccc3c6b29	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	eb9a600f-ec93-496f-80a6-0e81355e6739	\N	SEDAN	VEHICLE	0	0	0.00	420.00	0.00	\N	\N	\N	0	\N	\N	1.35	\N	\N	2026-04-24 11:44:55.407115-03
f40cbada-b74f-4a2e-95b5-987d2f9034e1	2026-03-24 21:00:00-03	2026-04-23 21:00:00-03	\N	ffd5a632-b7af-4c27-a220-7a03ab17f563	N/A	DRIVER	0	0	0.00	0.00	0.00	\N	\N	0	0	\N	\N	\N	{"raw_score": 0.0, "fines_count": 0, "claims_count": 0, "anomalies_count": 0}	ARNALDO ROSA DOS SANTOS FILHO	2026-04-24 11:44:55.407115-03
\.


--
-- Data for Name: fuel_station_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fuel_station_users (id, user_id, fuel_station_id, active, created_at, updated_at) FROM stdin;
3cd89051-6a6d-44fa-91fe-2311a35f5941	1692cea5-2f4e-4bff-9283-880e13767ed6	377dde01-11ff-49e2-98fa-f552c4d427b6	t	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
\.


--
-- Data for Name: fuel_stations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fuel_stations (id, name, active, created_at, updated_at, cnpj, address) FROM stdin;
377dde01-11ff-49e2-98fa-f552c4d427b6	Posto Centro	t	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03	12.345.678/0001-90	Avenida Principal, 1000 - Centro
\.


--
-- Data for Name: fuel_supplies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fuel_supplies (id, vehicle_id, driver_id, organization_id, supplied_at, odometer_km, liters, total_amount, fuel_station, notes, consumption_km_l, is_consumption_anomaly, anomaly_details, receipt_path, receipt_mime_type, receipt_size_bytes, receipt_uploaded_at, created_at, updated_at, fuel_station_id) FROM stdin;
\.


--
-- Data for Name: fuel_supply_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fuel_supply_orders (id, vehicle_id, driver_id, organization_id, fuel_station_id, status, expires_at, created_by_user_id, confirmed_by_user_id, requested_liters, max_amount, notes, confirmed_at, created_at, updated_at, validation_code) FROM stdin;
fbbbfd33-02f6-4d34-9d52-76bae62186fe	8cfde2d0-1d84-4e04-b152-a22cd87dd69c	5eb82eb3-3485-459e-8d93-679403f0867f	1d91b699-2c60-498c-a6e6-32c19ab2ed55	377dde01-11ff-49e2-98fa-f552c4d427b6	OPEN	2026-04-24 19:20:27.251587-03	e0b3d114-290f-4989-8157-c0819ec33156	\N	45.000	320.00	Ordem inicial de abastecimento para validacao local do fluxo de posto.	\N	2026-04-24 11:20:26.904725-03	2026-04-24 12:06:47.928164-03	OA-07C36E1F35E9
\.


--
-- Data for Name: location_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.location_history (id, vehicle_id, department, start_date, end_date, created_at, allocation_id, justification) FROM stdin;
5f707a38-50c2-4879-ad3b-3fa08b469738	9d93506e-947a-4f64-ba85-ed50f29af283	Secretaria de Administração - Gabinete do Secretário - Gabinete do Secretário	2026-04-15 21:02:19.626438-03	\N	2026-04-15 21:02:19.626438-03	171ac1a6-9eac-474a-a93a-675611aa783f	\N
e82752de-a623-4faa-ad1f-81f7cdfd1c79	3b767a49-d988-4686-8351-ca04907e1be7	Secretaria de Administração - Departamento de TI - Departamento de TI	2026-04-16 11:22:51.468843-03	\N	2026-04-16 11:22:51.468843-03	66824306-6e4d-4eb8-a3d4-b80010731ca7	\N
306e752a-bec7-497e-b785-e68883921f5e	07c1894c-d8aa-45f7-95e4-a44162c608c6	Secretaria de Administração - Departamento de Frotas - Departamento de Frotas	2026-04-16 11:30:32.016056-03	\N	2026-04-16 11:30:32.016056-03	979b0bff-f532-4a64-a3c2-ad4a119da580	\N
ba9c5791-2103-4edd-b607-bb955f654029	51a8d922-0382-4242-99b0-841b0c8e386a	Secretaria de Administração - Agricultura - SEAGRI - Agricultura - SEAGRI	2026-04-16 11:32:29.841531-03	2026-04-20 11:18:54.125232-03	2026-04-16 11:32:29.841531-03	\N	\N
459b0cbe-a765-4643-bb46-c36493eca2ce	51a8d922-0382-4242-99b0-841b0c8e386a	Secretaria de Agricultura Pecuária e Abastecimento - Gabinete da Secretaria - Gabinete	2026-04-20 11:18:53.931915-03	\N	2026-04-20 11:18:53.931915-03	c7e7ff44-4673-4095-aa5e-a50d75656201	\N
ecea2e85-011a-4978-a022-3c51bfd26500	ef947a79-a1a0-42d5-977c-50cc43f016b6	Secretaria de Administração - Infraestrutura - SEINFRA - Infraestrutura - SEINFRA	2026-04-16 11:29:33.565033-03	2026-04-20 11:19:15.980648-03	2026-04-16 11:29:33.565033-03	\N	\N
badc8837-5ddc-4e5e-b115-edf59934e64a	ef947a79-a1a0-42d5-977c-50cc43f016b6	Secretaria de Infraestrutura e Serviços Urbanos - Gabinete da Secretaria - Gabinete	2026-04-20 11:19:15.973684-03	\N	2026-04-20 11:19:15.973684-03	e4771d43-f38c-448a-b777-0feb3ad63194	\N
697a7720-73cb-44aa-9d6b-f44074fee3a8	0e9d959e-666d-4e9e-92ed-a15cff32db7a	Secretaria de Administração - Chefia de Governo - Chefia de Governo	2026-04-22 14:36:58.480425-03	\N	2026-04-22 14:36:58.480425-03	c6c9136b-b07e-4256-a46b-f4d4bdcb7b48	\N
5e43f0fa-fadf-4174-9b3c-cdf395ee71ee	405d91a7-fb9e-4789-9dc3-6f309431bfec	Secretaria de Administração - Chefia de Governo - Chefia de Governo	2026-04-22 14:41:58.938149-03	\N	2026-04-22 14:41:58.938149-03	c6c9136b-b07e-4256-a46b-f4d4bdcb7b48	\N
ad6a803d-5638-47b9-9806-47bcd6daa681	6857365a-5a63-49ab-a171-ddfb98863a9d	Secretaria de Administração - Chefia de Governo - Chefia de Governo	2026-04-22 14:46:31.860949-03	\N	2026-04-22 14:46:31.860949-03	c6c9136b-b07e-4256-a46b-f4d4bdcb7b48	\N
e8b5e6a5-61cc-4430-a3eb-b486bf1113ae	487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia - Desenvolvimento Econômico - SDE - SEDE - SDE - SEDE	2026-04-23 14:54:05.450617-03	\N	2026-04-23 14:54:05.450617-03	3265a02e-4d56-4cb0-aa6f-4b1103ea3911	\N
b1ab496b-66bb-4275-9d41-c64ebd8c4d1d	8cfde2d0-1d84-4e04-b152-a22cd87dd69c	Secretaria de Administracao - Gestao Administrativa - Garagem Central	2026-04-24 11:20:26.904725-03	\N	2026-04-24 11:20:26.904725-03	981ea424-04bc-4a19-85d3-72d07750dbbc	\N
5ffbc2e0-a6dc-4c90-ba78-742858284ca8	eb9a600f-ec93-496f-80a6-0e81355e6739	Secretaria de Infraestrutura - Oficina - Oficina Central	2026-04-24 11:20:26.904725-03	\N	2026-04-24 11:20:26.904725-03	138c2ed7-852c-4e67-8cbc-e70e66ed2ab5	\N
f1ec75e1-0979-40d6-b723-5d98007e2189	56533289-c9ee-416e-a3c1-de9ad2c101c4	Secretaria de Saude - Transporte - Patio Municipal	2026-04-24 11:20:26.904725-03	\N	2026-04-24 11:20:26.904725-03	a9f9b874-e66e-4bed-89b2-eedf7c40490c	\N
\.


--
-- Data for Name: maintenance_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_records (id, vehicle_id, start_date, end_date, service_description, parts_replaced, total_cost, created_by, created_at, updated_at) FROM stdin;
ee6252ab-6811-4787-a0c2-346fc28dc52d	8cfde2d0-1d84-4e04-b152-a22cd87dd69c	2026-04-14 11:20:27.233382-03	2026-04-17 11:20:27.233382-03	Troca de oleo e filtros	Filtro de oleo, filtro de ar, oleo 5W30	285.50	e0b3d114-290f-4989-8157-c0819ec33156	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
96ddfbc6-fe87-41cc-850a-a4481fc831b8	eb9a600f-ec93-496f-80a6-0e81355e6739	2026-04-21 11:20:27.233382-03	\N	Revisao de freios em andamento	Pastilhas de freio dianteiras	420.00	e0b3d114-290f-4989-8157-c0819ec33156	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
\.


--
-- Data for Name: master_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_allocations (id, department_id, name, created_at, updated_at) FROM stdin;
171ac1a6-9eac-474a-a93a-675611aa783f	08c87c40-c5b3-4531-a561-2480d3d65c02	Gabinete do Secretário	2026-04-15 20:58:48.993092-03	2026-04-15 20:58:48.993092-03
d2399f27-137d-4b0b-bccf-4adc5da83c9a	9b013e25-2dfb-4276-80ff-73c36923f68f	SESMT	2026-04-15 20:59:11.378042-03	2026-04-15 20:59:11.378042-03
4129b656-4329-4bdc-af3e-a107f0467cdd	8ff4e2f2-d4d9-4239-b5a4-2939c8db97f4	Patrimônio e Arquivos em Geral	2026-04-15 20:59:36.630497-03	2026-04-15 20:59:36.630497-03
66824306-6e4d-4eb8-a3d4-b80010731ca7	6963629c-862f-49f1-b514-d0069096d0f6	Departamento de TI	2026-04-15 20:59:51.030476-03	2026-04-15 20:59:51.030476-03
f9034b11-e997-4d93-9af6-e38076cbcd03	1a87c196-04c6-4a3d-939d-9f074fc0ef36	Departamento de Recursos Humanos	2026-04-15 21:00:06.884083-03	2026-04-15 21:00:06.884083-03
4febca10-87f3-4f62-8d59-d6bb472dd502	8f8b0bde-a014-47f9-a2b7-de616bcca58d	Departamento Administrativo	2026-04-15 21:01:05.756829-03	2026-04-15 21:01:05.756829-03
b90c8744-a5d2-4751-923b-b4498764b756	3eac36c0-5ac6-43b7-bafc-2ce55213d70f	Almoxarifado Central	2026-04-15 21:01:25.309254-03	2026-04-15 21:01:25.309254-03
3265a02e-4d56-4cb0-aa6f-4b1103ea3911	abceb99f-7796-46df-9166-4d59699a581a	SDE - SEDE	2026-04-16 08:41:42.739476-03	2026-04-16 08:41:42.739476-03
979b0bff-f532-4a64-a3c2-ad4a119da580	ec714e4f-d968-4790-aabd-9390944ad035	Departamento de Frotas	2026-04-16 11:28:32.527935-03	2026-04-16 11:28:32.527935-03
c7e7ff44-4673-4095-aa5e-a50d75656201	6e0b0f1b-2f83-412e-a128-3fa682ea1190	Gabinete	2026-04-20 11:17:02.027361-03	2026-04-20 11:17:02.027361-03
e4771d43-f38c-448a-b777-0feb3ad63194	8e91b226-caf7-4965-91a1-37adca8d3f30	Gabinete	2026-04-20 11:17:48.96919-03	2026-04-20 11:17:48.96919-03
7eb88421-435f-4919-9f66-c7e6b3191e64	6e0b0f1b-2f83-412e-a128-3fa682ea1190	SEDE	2026-04-20 11:19:58.892797-03	2026-04-20 11:19:58.892797-03
ca62c137-72ca-4cb8-9d2d-8cb57fd1a9f4	8e91b226-caf7-4965-91a1-37adca8d3f30	SEDE	2026-04-20 11:20:17.915014-03	2026-04-20 11:20:17.915014-03
c6c9136b-b07e-4256-a46b-f4d4bdcb7b48	71e67d56-af08-4ef2-9077-c6b7ad79a099	Chefia de Governo	2026-04-22 14:30:25.60732-03	2026-04-22 14:30:25.60732-03
462c5c47-1e0a-47e4-b319-b5e58f829d3c	1adcb869-29ac-4973-8d65-93e1c76bac64	Educação	2026-04-23 15:34:49.546513-03	2026-04-23 15:34:49.546513-03
8866c574-cd7f-4374-99fb-32a6884b36a5	f319cfe4-e444-4349-806a-6597a2a56534	Transporte Escolar	2026-04-23 15:35:17.167032-03	2026-04-23 15:35:17.167032-03
981ea424-04bc-4a19-85d3-72d07750dbbc	0093febc-e750-466e-be19-be85945c2472	Garagem Central	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
138c2ed7-852c-4e67-8cbc-e70e66ed2ab5	2d368b1c-61eb-4a2b-88eb-20c879024c69	Oficina Central	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
a9f9b874-e66e-4bed-89b2-eedf7c40490c	562c0db6-c943-48b4-ba5c-812e6a622ab8	Patio Municipal	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
\.


--
-- Data for Name: master_departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_departments (id, organization_id, name, created_at, updated_at) FROM stdin;
8f8b0bde-a014-47f9-a2b7-de616bcca58d	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Departamento Administrativo	2026-04-10 13:45:38.76231-03	2026-04-10 16:57:52.211385-03
08c87c40-c5b3-4531-a561-2480d3d65c02	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Gabinete do Secretário	2026-04-15 20:48:27.51184-03	2026-04-15 20:48:27.51184-03
9b013e25-2dfb-4276-80ff-73c36923f68f	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	SESMT	2026-04-15 20:48:42.565904-03	2026-04-15 20:48:42.565904-03
3eac36c0-5ac6-43b7-bafc-2ce55213d70f	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Almoxarifado Central	2026-04-15 20:48:54.869736-03	2026-04-15 20:48:54.869736-03
8ff4e2f2-d4d9-4239-b5a4-2939c8db97f4	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Patrimônio e Arquivos em Geral	2026-04-15 20:49:18.680366-03	2026-04-15 20:49:18.680366-03
6963629c-862f-49f1-b514-d0069096d0f6	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Departamento de TI	2026-04-15 20:49:46.021639-03	2026-04-15 20:49:46.021639-03
1a87c196-04c6-4a3d-939d-9f074fc0ef36	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Departamento de Recursos Humanos	2026-04-15 20:55:52.752009-03	2026-04-15 20:55:52.752009-03
abceb99f-7796-46df-9166-4d59699a581a	72c067bf-d9f7-4f8d-b8c0-ce45d1713025	Desenvolvimento Econômico - SDE - SEDE	2026-04-16 08:40:12.620772-03	2026-04-16 11:15:45.185015-03
ec714e4f-d968-4790-aabd-9390944ad035	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Departamento de Frotas	2026-04-16 11:28:15.16876-03	2026-04-16 11:28:15.16876-03
6e0b0f1b-2f83-412e-a128-3fa682ea1190	dbae7e55-4e04-4c38-9128-a88c98b12160	Gabinete da Secretaria	2026-04-20 11:16:38.748208-03	2026-04-20 11:16:38.748208-03
8e91b226-caf7-4965-91a1-37adca8d3f30	9d68dcc7-a43b-4e27-9961-7929cf691b17	Gabinete da Secretaria	2026-04-20 11:17:37.554567-03	2026-04-20 11:17:37.554567-03
71e67d56-af08-4ef2-9077-c6b7ad79a099	4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Chefia de Governo	2026-04-22 14:30:03.639504-03	2026-04-22 14:30:03.639504-03
1adcb869-29ac-4973-8d65-93e1c76bac64	90332997-e801-44ba-be90-c2fa126053ea	Educação	2026-04-23 15:34:39.098836-03	2026-04-23 15:34:39.098836-03
f319cfe4-e444-4349-806a-6597a2a56534	90332997-e801-44ba-be90-c2fa126053ea	Transporte Escolar	2026-04-23 15:35:03.095258-03	2026-04-23 15:35:03.095258-03
0093febc-e750-466e-be19-be85945c2472	1d91b699-2c60-498c-a6e6-32c19ab2ed55	Gestao Administrativa	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
2d368b1c-61eb-4a2b-88eb-20c879024c69	4b94a9c9-0535-476b-98eb-da99c2bbae5c	Oficina	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
562c0db6-c943-48b4-ba5c-812e6a622ab8	74cb27a4-7d6e-4219-a9cc-75b0b0e34413	Transporte	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
\.


--
-- Data for Name: master_organizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.master_organizations (id, name, created_at, updated_at) FROM stdin;
9d68dcc7-a43b-4e27-9961-7929cf691b17	Secretaria de Infraestrutura e Serviços Urbanos	2026-04-10 13:45:38.76231-03	2026-04-10 14:41:14.397968-03
90332997-e801-44ba-be90-c2fa126053ea	Secretaria de Educação	2026-04-10 14:41:36.159933-03	2026-04-10 14:41:45.602737-03
4d81cd3c-eddd-4b4a-a37e-2b2be5a8c02d	Secretaria de Administração	2026-04-10 13:45:38.76231-03	2026-04-10 14:41:52.177801-03
891b49ea-abf4-4501-9ef6-23fb78c42d25	Secretaria de Saúde	2026-04-10 13:45:38.76231-03	2026-04-10 14:41:59.519107-03
e6a79f0d-d2bf-4e00-bc6d-9294a5b0da7e	Controladoria Geral do Município	2026-04-10 14:42:38.708471-03	2026-04-10 14:42:38.708471-03
471860e8-fe57-4181-bb14-cf3098787905	Gabiente do Prefeito	2026-04-10 14:42:45.400331-03	2026-04-10 14:42:45.400331-03
4fdeb45a-dca4-4dcf-93d0-08e24663e09a	Procuradoria Geral do Município	2026-04-10 14:43:01.690231-03	2026-04-10 14:43:01.690231-03
dbae7e55-4e04-4c38-9128-a88c98b12160	Secretaria de Agricultura Pecuária e Abastecimento	2026-04-10 14:43:19.225392-03	2026-04-10 14:43:19.225392-03
12375ce0-6f93-43b7-97df-787218d6ff37	Secretaria de Cultura e Turismo	2026-04-10 14:43:37.811732-03	2026-04-10 14:43:37.811732-03
72c067bf-d9f7-4f8d-b8c0-ce45d1713025	Secretaria de Desenvolvimento Econômico, Ciência e Tecnologia	2026-04-10 14:44:01.635346-03	2026-04-10 14:44:01.635346-03
c191b61f-81f7-45ef-825f-fe6a50de9be1	Secretaria de Esporte e Lazer	2026-04-10 14:44:16.800864-03	2026-04-10 14:44:16.800864-03
f6dc3ca5-886b-4667-b0ca-536c4a0bfe97	Secretaria de Finanças	2026-04-10 14:44:25.083012-03	2026-04-10 14:44:25.083012-03
3b697c38-9278-4b7a-a653-ff985f47a2a6	Secretaria de Habitação	2026-04-10 14:44:44.853436-03	2026-04-10 14:44:44.853436-03
98a656ae-7517-408c-a997-454a7f7007d2	Secretaria de Meio Ambiente	2026-04-10 14:45:01.698856-03	2026-04-10 14:45:01.698856-03
555db8bb-6f86-437e-bb3b-a047a826ac34	Secretaria de Projetos Estratégicos e Gerenciamento de Convênios	2026-04-10 15:07:33.484142-03	2026-04-10 15:07:33.484142-03
6acb9d5d-599a-4e3e-9f67-932c561cbacb	Secretaria de Promoção Social	2026-04-10 15:08:53.789257-03	2026-04-10 15:08:53.789257-03
02708937-9e4d-4387-851b-7a49957405e2	Secretaria de Segurança e Transporte	2026-04-10 15:09:14.627433-03	2026-04-10 15:09:14.627433-03
1d91b699-2c60-498c-a6e6-32c19ab2ed55	Secretaria de Administracao	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
4b94a9c9-0535-476b-98eb-da99c2bbae5c	Secretaria de Infraestrutura	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
74cb27a4-7d6e-4219-a9cc-75b0b0e34413	Secretaria de Saude	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, password_hash, role, created_at, updated_at) FROM stdin;
e0b3d114-290f-4989-8157-c0819ec33156	Administrador	admin@frota.local	$2b$12$dlweF7CXlWbVONjdgbuzN.iGDCxRLgZz9CI/81CHHU3AXYJy8nlbu	ADMIN	2026-04-07 09:49:57.38354-03	2026-04-07 09:49:57.38354-03
0af328cb-2b03-4abb-a363-666f82f826bd	Usuário Padrão	padrao@frota.local	$2b$12$lFBij5/aGvYva3rS2gEa8.rJhfZqRqyZTyUxIearPWvxDanQf42qq	PADRAO	2026-04-07 09:49:57.38354-03	2026-04-07 09:49:57.38354-03
2bab65d7-a21d-4f35-8e1c-f5dfcd2f8a3d	Jonatas da Silva Sousa	jonatas@sousa	$2b$12$vZQOhZLjSNd8ixdiqsFZW.2beLDO.crYXUdE5ihEO47L57j5g1GGC	ADMIN	2026-04-09 15:51:27.86796-03	2026-04-09 16:37:31.621877-03
065b1e0b-527b-4b65-8a62-008851a22f96	ARNALDO ROSA DOS SANTOS FILHO	naldorsantosfilho@gmail.com	$2b$12$hOqr7E7oKB.GSmO9Y/2uGeLgB5dywk64cuO9uiFPRfXBg3q4S1ckW	ADMIN	2026-04-09 11:59:41.218041-03	2026-04-13 10:12:02.307678-03
08d425de-0052-42b1-95ab-b3178cde1e30	WANDERSON SOUSA LIMAS	wanderson.limas@pm.teixeiradefreitas.ba.gov.br	$2b$12$Z82Ah9eA4qFCn8t425vpnuICyhnwzgTAW/T55A7SDbhcg.T/gNhsu	ADMIN	2026-04-10 18:15:06.747474-03	2026-04-13 11:45:32.125092-03
50fcc408-b540-480a-872e-0f42650871a1	Usuario de Producao	producao@frota.local	$2b$12$ODkGPadZDKDwdECoFkxCxuXYHs7CX0Fz.JWv3uP9.qFLYc88JJdIa	PRODUCAO	2026-04-09 15:40:09.928335-03	2026-04-13 16:43:09.67634-03
9025070c-12e2-410f-8bb6-ae75fa3ae64e	DAVI SANTANA REGO	davisr@pm.teixeiradefreitas.ba.gov.br	$2b$12$PSRLQBYWWJrTzjNJ1vjGTe0xbcASiF27zapOD0umXk2x04ins/Z/G	PRODUCAO	2026-04-13 08:59:01.344115-03	2026-04-16 10:34:26.757569-03
1692cea5-2f4e-4bff-9283-880e13767ed6	Operador de Posto	posto@frota.local	$2b$12$8nwvjVQQzuSn0Hs/LpbKsuePqbg9l3R8c.O2D5313DpUprpFOBjxi	POSTO	2026-04-24 11:20:26.904725-03	2026-04-24 11:21:34.386245-03
\.


--
-- Data for Name: vehicle_possession; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_possession (id, vehicle_id, driver_name, driver_document, driver_contact, start_date, end_date, observation, created_at, photo_path, photo_mime_type, photo_size_bytes, photo_captured_at, capture_latitude, capture_longitude, capture_accuracy_meters, document_path, document_name, document_mime_type, document_size_bytes, document_uploaded_at, driver_id, start_odometer_km, end_odometer_km) FROM stdin;
47a0b13c-766c-4396-ac5a-61772af6d0fd	8cfde2d0-1d84-4e04-b152-a22cd87dd69c	Joao Silva	123.456.789-00	(11) 99999-8888	2026-04-24 11:20:26.904725-03	\N	Motorista designado para rota norte	2026-04-24 11:20:26.904725-03	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	5eb82eb3-3485-459e-8d93-679403f0867f	\N	\N
1ff81907-bd87-4f8e-82ba-5b2cfe8ec8d5	56533289-c9ee-416e-a3c1-de9ad2c101c4	Maria Oliveira	987.654.321-00	(11) 98888-7777	2026-04-24 11:20:26.904725-03	2026-04-19 11:20:27.239383-03	Posse temporaria para treinamento	2026-04-24 11:20:26.904725-03	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	9acc4e58-e084-4089-9ec2-8dd99977870e	\N	\N
\.


--
-- Data for Name: vehicle_possession_photos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_possession_photos (id, possession_id, photo_path, photo_mime_type, photo_size_bytes, photo_captured_at, capture_latitude, capture_longitude, capture_accuracy_meters, created_at) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicles (id, plate, brand, model, status, created_at, updated_at, chassis_number, ownership_type, vehicle_type) FROM stdin;
3b767a49-d988-4686-8351-ca04907e1be7	TOA5G32	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-16 11:22:51.468843-03	2026-04-16 11:22:51.468843-03	9BWAG5R14TT033231	LOCADO	HATCH
ef947a79-a1a0-42d5-977c-50cc43f016b6	TOA5G25	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-16 11:29:33.565033-03	2026-04-16 11:29:33.565033-03	9BWAG5R13TT033575	LOCADO	HATCH
07c1894c-d8aa-45f7-95e4-a44162c608c6	TOA5F48	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-16 11:30:32.016056-03	2026-04-16 11:30:32.016056-03	9BWAG5R17TT033370	LOCADO	HATCH
51a8d922-0382-4242-99b0-841b0c8e386a	TOA5F57	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-16 11:32:29.841531-03	2026-04-16 11:32:29.841531-03	9BWAG5R15TT033464	LOCADO	HATCH
0e9d959e-666d-4e9e-92ed-a15cff32db7a	TOA5G28	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-22 14:36:58.480425-03	2026-04-22 14:36:58.480425-03	9BWAG5R19TT033208	LOCADO	HATCH
405d91a7-fb9e-4789-9dc3-6f309431bfec	TOA5G11	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-22 14:41:58.938149-03	2026-04-22 14:41:58.938149-03	9BWAG5R1XTT033573	LOCADO	HATCH
6857365a-5a63-49ab-a171-ddfb98863a9d	TOA5F65	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-22 14:46:31.860949-03	2026-04-22 14:46:31.860949-03	9BWAG5R12TT033518	LOCADO	HATCH
487d90ff-fb9f-4cd8-8f6c-8d340ac58bbd	TOA5G37	VOLKSWAGEN	POLO TRACK MA	ATIVO	2026-04-23 14:54:05.450617-03	2026-04-23 14:54:05.450617-03	9BWAG5R15TT033321	LOCADO	HATCH
9d93506e-947a-4f64-ba85-ed50f29af283	TEE0D81	VOLKSWAGEN	POLO TRACK MA	INATIVO	2026-04-15 21:02:19.626438-03	2026-04-23 17:12:05.105672-03	9BWAG5R10TT004230	LOCADO	HATCH
8cfde2d0-1d84-4e04-b152-a22cd87dd69c	ABC-1D23	Ford	Ka	ATIVO	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03	9BFZH55L0G1234567	PROPRIO	SEDAN
eb9a600f-ec93-496f-80a6-0e81355e6739	DEF-4E56	Chevrolet	Onix	MANUTENCAO	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03	9BWZZZ377VT004251	LOCADO	SEDAN
56533289-c9ee-416e-a3c1-de9ad2c101c4	GHI-7F89	Toyota	Corolla	INATIVO	2026-04-24 11:20:26.904725-03	2026-04-24 11:20:26.904725-03	8AWZZZ6K2VA012345	CEDIDO	SEDAN
\.


--
-- Name: admin_notifications admin_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_notifications
    ADD CONSTRAINT admin_notifications_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: claims claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_pkey PRIMARY KEY (id);


--
-- Name: drivers drivers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drivers
    ADD CONSTRAINT drivers_pkey PRIMARY KEY (id);


--
-- Name: fines fines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fines
    ADD CONSTRAINT fines_pkey PRIMARY KEY (id);


--
-- Name: fleet_analytics_snapshots fleet_analytics_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_analytics_snapshots
    ADD CONSTRAINT fleet_analytics_snapshots_pkey PRIMARY KEY (id);


--
-- Name: fuel_station_users fuel_station_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_station_users
    ADD CONSTRAINT fuel_station_users_pkey PRIMARY KEY (id);


--
-- Name: fuel_stations fuel_stations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_stations
    ADD CONSTRAINT fuel_stations_pkey PRIMARY KEY (id);


--
-- Name: fuel_supplies fuel_supplies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supplies
    ADD CONSTRAINT fuel_supplies_pkey PRIMARY KEY (id);


--
-- Name: fuel_supply_orders fuel_supply_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_pkey PRIMARY KEY (id);


--
-- Name: location_history location_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_history
    ADD CONSTRAINT location_history_pkey PRIMARY KEY (id);


--
-- Name: maintenance_records maintenance_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_pkey PRIMARY KEY (id);


--
-- Name: master_allocations master_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_allocations
    ADD CONSTRAINT master_allocations_pkey PRIMARY KEY (id);


--
-- Name: master_departments master_departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_departments
    ADD CONSTRAINT master_departments_pkey PRIMARY KEY (id);


--
-- Name: master_organizations master_organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_organizations
    ADD CONSTRAINT master_organizations_pkey PRIMARY KEY (id);


--
-- Name: fuel_station_users uq_fuel_station_users_user_station; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_station_users
    ADD CONSTRAINT uq_fuel_station_users_user_station UNIQUE (user_id, fuel_station_id);


--
-- Name: fuel_stations uq_fuel_stations_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_stations
    ADD CONSTRAINT uq_fuel_stations_name UNIQUE (name);


--
-- Name: master_allocations uq_master_allocations_department_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_allocations
    ADD CONSTRAINT uq_master_allocations_department_name UNIQUE (department_id, name);


--
-- Name: master_departments uq_master_departments_org_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_departments
    ADD CONSTRAINT uq_master_departments_org_name UNIQUE (organization_id, name);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vehicle_possession_photos vehicle_possession_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_possession_photos
    ADD CONSTRAINT vehicle_possession_photos_pkey PRIMARY KEY (id);


--
-- Name: vehicle_possession vehicle_possession_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_possession
    ADD CONSTRAINT vehicle_possession_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: idx_admin_notifications_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_notifications_created_at ON public.admin_notifications USING btree (created_at);


--
-- Name: idx_admin_notifications_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_notifications_event_type ON public.admin_notifications USING btree (event_type);


--
-- Name: idx_admin_notifications_read_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_admin_notifications_read_at ON public.admin_notifications USING btree (read_at);


--
-- Name: idx_claims_data; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_claims_data ON public.claims USING btree (data_ocorrencia);


--
-- Name: idx_claims_driver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_claims_driver ON public.claims USING btree (driver_id);


--
-- Name: idx_claims_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_claims_status ON public.claims USING btree (status);


--
-- Name: idx_claims_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_claims_vehicle ON public.claims USING btree (vehicle_id);


--
-- Name: idx_drivers_ativo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drivers_ativo ON public.drivers USING btree (ativo) WHERE (ativo = true);


--
-- Name: idx_drivers_documento; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drivers_documento ON public.drivers USING btree (documento);


--
-- Name: idx_drivers_nome; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_drivers_nome ON public.drivers USING btree (nome_completo);


--
-- Name: idx_fines_driver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fines_driver ON public.fines USING btree (driver_id);


--
-- Name: idx_fines_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fines_due_date ON public.fines USING btree (due_date);


--
-- Name: idx_fines_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fines_status ON public.fines USING btree (status);


--
-- Name: idx_fines_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fines_vehicle ON public.fines USING btree (vehicle_id);


--
-- Name: idx_fleet_analytics_snapshot_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fleet_analytics_snapshot_created ON public.fleet_analytics_snapshots USING btree (created_at);


--
-- Name: idx_fleet_analytics_snapshot_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fleet_analytics_snapshot_period ON public.fleet_analytics_snapshots USING btree (period_start, period_end);


--
-- Name: idx_fleet_analytics_snapshot_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fleet_analytics_snapshot_scope ON public.fleet_analytics_snapshots USING btree (vehicle_type, vehicle_id, driver_id);


--
-- Name: idx_fuel_station_users_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_station_users_active ON public.fuel_station_users USING btree (active);


--
-- Name: idx_fuel_station_users_station; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_station_users_station ON public.fuel_station_users USING btree (fuel_station_id);


--
-- Name: idx_fuel_station_users_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_station_users_user ON public.fuel_station_users USING btree (user_id);


--
-- Name: idx_fuel_stations_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_stations_active ON public.fuel_stations USING btree (active);


--
-- Name: idx_fuel_stations_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_stations_name ON public.fuel_stations USING btree (name);


--
-- Name: idx_fuel_supplies_anomaly; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_anomaly ON public.fuel_supplies USING btree (is_consumption_anomaly);


--
-- Name: idx_fuel_supplies_driver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_driver ON public.fuel_supplies USING btree (driver_id);


--
-- Name: idx_fuel_supplies_fuel_station_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_fuel_station_id ON public.fuel_supplies USING btree (fuel_station_id);


--
-- Name: idx_fuel_supplies_organization; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_organization ON public.fuel_supplies USING btree (organization_id);


--
-- Name: idx_fuel_supplies_supplied_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_supplied_at ON public.fuel_supplies USING btree (supplied_at);


--
-- Name: idx_fuel_supplies_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supplies_vehicle ON public.fuel_supplies USING btree (vehicle_id);


--
-- Name: idx_fuel_supply_orders_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supply_orders_expires_at ON public.fuel_supply_orders USING btree (expires_at);


--
-- Name: idx_fuel_supply_orders_fuel_station_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supply_orders_fuel_station_id ON public.fuel_supply_orders USING btree (fuel_station_id);


--
-- Name: idx_fuel_supply_orders_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supply_orders_organization_id ON public.fuel_supply_orders USING btree (organization_id);


--
-- Name: idx_fuel_supply_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supply_orders_status ON public.fuel_supply_orders USING btree (status);


--
-- Name: idx_fuel_supply_orders_validation_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_fuel_supply_orders_validation_code ON public.fuel_supply_orders USING btree (validation_code);


--
-- Name: idx_fuel_supply_orders_vehicle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_fuel_supply_orders_vehicle_id ON public.fuel_supply_orders USING btree (vehicle_id);


--
-- Name: idx_maintenance_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maintenance_created_by ON public.maintenance_records USING btree (created_by);


--
-- Name: idx_maintenance_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maintenance_dates ON public.maintenance_records USING btree (start_date, end_date);


--
-- Name: idx_maintenance_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_maintenance_vehicle ON public.maintenance_records USING btree (vehicle_id);


--
-- Name: idx_possession_driver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_possession_driver ON public.vehicle_possession USING btree (driver_name);


--
-- Name: idx_possession_photo_possession; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_possession_photo_possession ON public.vehicle_possession_photos USING btree (possession_id);


--
-- Name: idx_possession_vehicle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_possession_vehicle ON public.vehicle_possession USING btree (vehicle_id);


--
-- Name: ix_location_history_allocation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_location_history_allocation_id ON public.location_history USING btree (allocation_id);


--
-- Name: ix_location_history_vehicle_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_location_history_vehicle_id ON public.location_history USING btree (vehicle_id);


--
-- Name: ix_master_allocations_department_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_master_allocations_department_id ON public.master_allocations USING btree (department_id);


--
-- Name: ix_master_departments_organization_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_master_departments_organization_id ON public.master_departments USING btree (organization_id);


--
-- Name: ix_master_organizations_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_master_organizations_name ON public.master_organizations USING btree (name);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_vehicle_possession_driver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vehicle_possession_driver_id ON public.vehicle_possession USING btree (driver_id);


--
-- Name: ix_vehicles_chassis_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_vehicles_chassis_number ON public.vehicles USING btree (chassis_number);


--
-- Name: ix_vehicles_plate; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_vehicles_plate ON public.vehicles USING btree (plate);


--
-- Name: uq_drivers_documento_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_drivers_documento_active ON public.drivers USING btree (documento) WHERE (ativo = true);


--
-- Name: uq_possession_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_possession_active ON public.vehicle_possession USING btree (vehicle_id) WHERE (end_date IS NULL);


--
-- Name: claims trg_claims_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_claims_updated_at BEFORE UPDATE ON public.claims FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: drivers trg_drivers_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_drivers_updated_at BEFORE UPDATE ON public.drivers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fines trg_fines_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fines_updated_at BEFORE UPDATE ON public.fines FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fuel_station_users trg_fuel_station_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fuel_station_users_updated_at BEFORE UPDATE ON public.fuel_station_users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fuel_stations trg_fuel_stations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fuel_stations_updated_at BEFORE UPDATE ON public.fuel_stations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fuel_supplies trg_fuel_supplies_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fuel_supplies_updated_at BEFORE UPDATE ON public.fuel_supplies FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: fuel_supply_orders trg_fuel_supply_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_fuel_supply_orders_updated_at BEFORE UPDATE ON public.fuel_supply_orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: maintenance_records trg_maintenance_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_maintenance_updated_at BEFORE UPDATE ON public.maintenance_records FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: master_allocations trg_master_allocations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_master_allocations_updated_at BEFORE UPDATE ON public.master_allocations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: master_departments trg_master_departments_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_master_departments_updated_at BEFORE UPDATE ON public.master_departments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: master_organizations trg_master_organizations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_master_organizations_updated_at BEFORE UPDATE ON public.master_organizations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users trg_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: vehicles trg_vehicles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_vehicles_updated_at BEFORE UPDATE ON public.vehicles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: audit_logs audit_logs_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: claims claims_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: claims claims_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: claims claims_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.claims
    ADD CONSTRAINT claims_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: fines fines_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fines
    ADD CONSTRAINT fines_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: fines fines_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fines
    ADD CONSTRAINT fines_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: fines fines_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fines
    ADD CONSTRAINT fines_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: fuel_supplies fk_fuel_supplies_fuel_station_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supplies
    ADD CONSTRAINT fk_fuel_supplies_fuel_station_id FOREIGN KEY (fuel_station_id) REFERENCES public.fuel_stations(id) ON DELETE SET NULL;


--
-- Name: location_history fk_location_history_allocation; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_history
    ADD CONSTRAINT fk_location_history_allocation FOREIGN KEY (allocation_id) REFERENCES public.master_allocations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fleet_analytics_snapshots fleet_analytics_snapshots_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_analytics_snapshots
    ADD CONSTRAINT fleet_analytics_snapshots_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: fleet_analytics_snapshots fleet_analytics_snapshots_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_analytics_snapshots
    ADD CONSTRAINT fleet_analytics_snapshots_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: fuel_station_users fuel_station_users_fuel_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_station_users
    ADD CONSTRAINT fuel_station_users_fuel_station_id_fkey FOREIGN KEY (fuel_station_id) REFERENCES public.fuel_stations(id) ON DELETE CASCADE;


--
-- Name: fuel_station_users fuel_station_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_station_users
    ADD CONSTRAINT fuel_station_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: fuel_supplies fuel_supplies_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supplies
    ADD CONSTRAINT fuel_supplies_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: fuel_supplies fuel_supplies_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supplies
    ADD CONSTRAINT fuel_supplies_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.master_organizations(id) ON DELETE SET NULL;


--
-- Name: fuel_supplies fuel_supplies_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supplies
    ADD CONSTRAINT fuel_supplies_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: fuel_supply_orders fuel_supply_orders_confirmed_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_confirmed_by_user_id_fkey FOREIGN KEY (confirmed_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: fuel_supply_orders fuel_supply_orders_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: fuel_supply_orders fuel_supply_orders_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON DELETE SET NULL;


--
-- Name: fuel_supply_orders fuel_supply_orders_fuel_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_fuel_station_id_fkey FOREIGN KEY (fuel_station_id) REFERENCES public.fuel_stations(id) ON DELETE SET NULL;


--
-- Name: fuel_supply_orders fuel_supply_orders_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.master_organizations(id) ON DELETE SET NULL;


--
-- Name: fuel_supply_orders fuel_supply_orders_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fuel_supply_orders
    ADD CONSTRAINT fuel_supply_orders_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON DELETE CASCADE;


--
-- Name: location_history location_history_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.location_history
    ADD CONSTRAINT location_history_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: maintenance_records maintenance_records_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE RESTRICT;


--
-- Name: maintenance_records maintenance_records_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_records
    ADD CONSTRAINT maintenance_records_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: master_allocations master_allocations_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_allocations
    ADD CONSTRAINT master_allocations_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.master_departments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: master_departments master_departments_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.master_departments
    ADD CONSTRAINT master_departments_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.master_organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_possession vehicle_possession_driver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_possession
    ADD CONSTRAINT vehicle_possession_driver_id_fkey FOREIGN KEY (driver_id) REFERENCES public.drivers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: vehicle_possession_photos vehicle_possession_photos_possession_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_possession_photos
    ADD CONSTRAINT vehicle_possession_photos_possession_id_fkey FOREIGN KEY (possession_id) REFERENCES public.vehicle_possession(id) ON DELETE CASCADE;


--
-- Name: vehicle_possession vehicle_possession_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_possession
    ADD CONSTRAINT vehicle_possession_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict faXPsxGvt0boNEDOmgyc05rgOaFMGhHoEzt7mmvuROaoRVuO3UD7wiDNGO4bQdw

